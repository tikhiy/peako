/**
 * ScotchJS
 *
 * (c) 2017 SILENT.
 * Released under the MIT license.
 */

;(function (window, document, undefined) {

"use strict";

var max = Math.max,
    floor = Math.floor,

    array_prototype = Array.prototype,
    push = array_prototype.push,
    slice = array_prototype.slice,

    R_NOT_WHITE_SPACES = /\S+/g,
    R_ONE_SELECTOR = /^(?:#([\w-]+)|([\w-]+)|\.([\w-]+))$/g,
    R_FILENAME = /^(\S*\.\w+)$/,

    support__addEventListener = !!(window.addEventListener && window.removeEventListener),

    event_list = [],

    _init,


_ = window._ = function (selector) {
  return new _init(selector);
},


_extend = _.extend = function () {
  var target = arguments[0],
      deep = true,
      i = 1, length = arguments.length,
      expander, keys, key, value, source, j, k;

  if (typeof target == "boolean") {
    deep = target;
    target = arguments[i++];
  }

  if (!target || typeof target != "object" && typeof target != "function") {
    throw new TypeError("target is not an Object");
  }

  for ( ; i < length; ++i) {
    expander = arguments[i];

    if (!expander || typeof expander != "object" && typeof expander != "function") {
      throw new TypeError("expander is not an Object");
    }

    keys = Object.keys(expander);

    for (j = 0, k = keys.length; j < k; ++j) {
      key = keys[j];
      value = expander[key];

      if (deep && value && value !== expander && typeof value == "object") {
        source = target[key];
        target[key] = _extend(deep, source && typeof source == "object" ? source : {}, value);
      }

      else {
        target[key] = value;
      }
    }
  }

  return target;
};


_extend(_, {
  isHTMLElement : function (i) {
    return HTMLElement ? i instanceof HTMLElement : !!(i && typeof i == "object" && i.nodeType === 1 && typeof i.nodeName == "string");
  },

  isNumber : function (i) {
    return typeof i == "number" && !isNaN(parseFloat(i)) && isFinite(i);
  },

  isArrayLike : function (i) {
    return !!i && typeof i == "object" && (
      i.constructor === _ ||
      i.constructor === Array ||
      i.constructor === NodeList ||
      i.constructor === HTMLCollection);
  },

  clone : function (object, deep) {
    if (object && typeof object == "object") {
      var copy = Object.create(object),
          keys = Object.keys(object),
          i = keys.length - 1, value;

      deep = typeof deep != "boolean" || deep;

      for ( ; i >= 0; --i) {
        value = object[keys[i]];

        copy[keys[i]] = deep && value && value !== object && typeof value == "object" ? _.clone(value, deep) : value;
      }

      return copy;
    }

    throw new TypeError(object + " is not an Object");
  },

  get : function (url, async) {
    if (typeof url != "string") {
      throw new Error(url + " is not a String");
    }

    if (!url.match(R_FILENAME)) {
      throw new Error(url + " is incorrect file URL");
    }

    var ajax = new XMLHttpRequest(),
        data = null,
        timer = 1000 * 60;

    ajax.open("GET", url, typeof async == "boolean" && async);

    ajax.onload = function () {
      if (this.readyState == 4 && this.status == 200) {
        window.clearTimeout(timer);

        data = this.responseText;
      }
    };

    timer = window.setTimeout(ajax.abort, timer);

    ajax.send(null);

    return data;
  },

  clamp : function (i, min, max) {
    return i > max ? max : i < min ? min : i;
  }
});


_extend(_, support__addEventListener ? {
  on : function (element, type, callback, useCapture) {
    element.addEventListener(type, callback, useCapture);
  },

  off : function (element, type, callback, useCapture) {
    element.removeEventListener(type, callback, useCapture);
  }
} : {
  /**
   * Based on Jonathan Neal addEventListener() polyfill.
   * https://gist.github.com/jonathantneal/3748027
   */
  on : function (element, type, callback) {
    if (typeof type != "string") {
      throw new TypeError(type + " is not a String");
    }

    if (typeof callback != "function") {
      throw new TypeError(callback + " is not a Function");
    }

    event_list.unshift([element, type, callback, function (event) {
      event = event || window.event;

      event.currentTarget = this;
      event.target = event.srcElement || this;

      event.preventDefault = function () { this.returnValue = false; };
      event.stopPropagation = function () { this.cancelBubble = true; };

      callback.call(this, event);
    }.bind(element)]);

    element.attachEvent("on" + type, event_list[0][3]);
  },

  off : function (element, type, callback) {
    for (var i = 0, o = event_list.length, event; i < o; ++i) {
      event = event_list[i];

      if (event[0] === element && event[1] === type && event[2] === callback) {
        element.detachEvent("on" + type, event_list.splice(i, 1)[0][3]);

        break;
      }
    }
  }
});


_.fn = _.prototype = {
  constructor : _,

  length : 0,

  init : function (selector) {
    var i, match, list = selector === window || _.isHTMLElement(selector) ? [selector] : _.isArrayLike(selector) ? selector : typeof selector != "string" ? null : !(match = R_ONE_SELECTOR.exec(selector)) ? document.querySelectorAll(selector) : match[1] ? [document.getElementById(match[1])] : match[2] ? document.getElementsByTagName(match[2]) : document.getElementsByClassName(match[3]);

    if (list && typeof list == "object") {
      this.length = ~~list.length;

      for (i = this.length - 1; i >= 0; --i) {
        this[i] = list[i];
      }
    }
  },

  push : function () {
    push.apply(this, arguments);

    return this;
  },

  each : function (callback) {
    if (typeof callback != "function") {
      throw new TypeError(callback + " is not a Function");
    }

    for (var i = 0, o = this.length; i < o; ++i) {
      if (callback.call(this[i], i, this) === false) { break; }
    }

    return this;
  },

  get : function (i) {
    return i == null ? slice.call(this) : this[i < 0 ? i + this.length : i];
  },

  parent : function () {
    var list = [],
        element,
        i = 0, o = this.length;

    for ( ; i < o; ++i) {
      element = this[i].parentElement;

      list.some(function (parent) {
        return parent === element;
      }) || list.push(element);
    }

    return new _init(list);
  },

  siblings : function () {
    var siblings = [],
        elements,
        element,
        i = 0, o = this.length, j, k;

    for ( ; i < o; ++i) {
      elements = this[i].parentElement.children;

      for (j = 0, k = elements.length; j < k; ++j) {
        element = elements[j];

        if (element === this[i]) { continue; }

        siblings.some(function (sibling) {
          return sibling === element;
        }) || siblings.push(element);
      }
    }

    return new _init(siblings);
  },

  children : function () {
    var children = [],
        i = 0, o = this.length;

    for ( ; i < o; ++i) {
      push.apply(children, this[i].children);
    }

    return new _init(children);
  },

  style : function (key, value) {
    var i = this.length - 1;

    if (typeof key == "string") {
      if (value == null) {
        return window.getComputedStyle(this[0])[key];
      }

      for (; i >= 0; --i) {
        this[i].style[key] = value;
      }
    }

    else if (key && typeof key == "object") {
      var keys = Object.keys(key),
          j, k = keys.length;

      for (; i >= 0; --i) {
        for (j = 0; j < k; ++j) {
          this[i].style[keys[j]] = key[keys[j]];
        }
      }
    }

    else { throw new TypeError(key + " is not a String or Object"); }

    return this;
  },

  html : function (html) {
    if (html == null) { return this[0].innerHTML; }

    for (var i = this.length - 1; i >= 0; --i) {
      this[i].innerHTML = html;
    }

    return this;
  },

  text : function (text) {
    if (text == null) { return this[0].textContent; }

    for (var i = this.length - 1; i >= 0; --i) {
      this[i].textContent = text;
    }

    return this;
  },

  value : function (value) {
    if (value == null) { return _(this[0]).attr("value"); }

    for (var i = this.length - 1; i >= 0; --i) {
      _(this[i]).attr("value", value);
    }

    return this;
  },

  attr : function (key, value) {
    var type_key = typeof key,
        type_value = typeof value,
        i = this.length - 1;

    if (type_key == "string") {
      if (value == null) {
        return this[0].getAttribute(key);
      }
      
      for (; i >= 0; --i) {
        this[i].setAttribute(key, type_value == "function" ? value(i, this[i].getAttribute(key)) : value);
      }
    }

    else if (key && type_key == "object") {
      var keys = Object.keys(keys),
          j, k = keys.length;

      for (; i >= 0; --i) {
        for (j = 0; j < k; ++j) {
          this[i].setAttribute(key[keys[j]], type_value == "function" ? value(i, this[i].getAttribute(key[keys[j]])) : value);
        }
      }
    }

    else { throw new TypeError(value + " is not a String or Object"); }

    return this;
  },

  removeAttr : function (keys) {
    if (typeof keys != "string") {
      throw new TypeError(value + " is not a String");
    }

    if (!(keys = keys.match(/[^,\s][^,]*[^,\s]*/gi))) {
      return this;
    }

    var element,
        i = this.length - 1,
        j, k = keys.length;

    for ( ; i >= 0; --i) {
      element = this[i];

      for (j = 0; j < k; ++j) {
        element.removeAttribute(keys[j]);
      }
    }

    return this;
  },

  addClass : function (value) {
    var class_name,
        i = this.length - 1, j, k;

    if (typeof value == "function") {
      for ( ; i >= 0; --i) {
        _(this[i]).addClass(value.call(this[i], i, this[i].className));
      }
    }

    else if (typeof value == "string") {
      if (!(value = value.match(R_NOT_WHITE_SPACES))) {
        return this;
      }

      k = value.length;

      for ( ; i >= 0; --i) {
        class_name = " " + (this[i].className.match(R_NOT_WHITE_SPACES) || []).join(" ") + " ";

        for (j = 0; j < k; ++j) {
          if (class_name.indexOf(" " + value[j] + " ") < 0) {
            class_name += value[j] + " ";
          }
        }

        this[i].className = class_name.trim();
      }
    }

    else { throw new TypeError(value + " is not a String or Function"); }

    return this;
  },

  removeClass : function (value) {
    var class_name,
        i = this.length - 1, j, k;

    if (value == null) {
      for ( ; i >= 0; --i) {
        this[i].className = "";
      }
    }

    else if (typeof value == "function") {
      for ( ; i >= 0; --i) {
        _(this[i]).removeClass(value.call(this[i], i, this[i].className));
      }
    }

    else if (typeof value == "string") {
      if (!(value = value.match(R_NOT_WHITE_SPACES))) {
        return this;
      }

      k = value.length;

      for ( ; i >= 0; --i) {
        class_name = " " + (this[i].className.match(R_NOT_WHITE_SPACES) || []).join(" ") + " ";

        for (j = 0; j < k; ++j) {
          class_name = class_name.replace(new RegExp(" " + value[j] + " ", "gi"), " ");
        }

        this[i].className = class_name.trim();
      }
    }

    else { throw new TypeError(value + " is not a String, Function or null"); }

    return this;
  },

  toggleClass : function (value, state) {
    if (typeof state == "boolean") {
      return this[state ? "addClass" : "removeClass"](value);
    }

    var element,
        class_name,
        i = this.length - 1, j, k;

    if (typeof value == "function") {
      for ( ; i >= 0; --i) {
        _(element = this[i]).toggleClass(value.call(element, i, element.className));
      }
    }

    else if (typeof value == "string") {
      if (!(value = value.match(R_NOT_WHITE_SPACES))) {
        return this;
      }

      k = value.length;

      for ( ; i >= 0; --i) {
        element = _(this[i]);
        class_name = " " + (this[i].className.match(R_NOT_WHITE_SPACES) || []).join(" ") + " ";

        for (j = 0; j < k; ++j) {
          element[~class_name.indexOf(" " + value[j] + " ") ? "addClass" : "removeClass"](value[j]);
        }
      }
    }

    else { throw new TypeError(value + " is not a String or Function"); }

    return this;
  },

  hasClass : function (value) {
    if (typeof value != "string") { throw new TypeError(value + " is not a String"); }

    if (!(value = value.match(R_NOT_WHITE_SPACES))) {
      return false;
    }

    var class_name,
        i = this.length - 1,
        j, k = value.length;

    for ( ; i >= 0; --i) {
      class_name = " " + (this[i].className.match(R_NOT_WHITE_SPACES) || []).join(" ") + " ";

      for (j = 0; j < k; ++j) {
        if (class_name.indexOf(" " + value[j] + " ") > -1) {
          return true;
        }
      }
    }

    return false;
  },

  offset : function (options) {
    var type = typeof options,
        offset;

    if (options == null) {
      var root = document.documentElement,
          body = document.body;

      offset = this[0].getBoundingClientRect();

      return {
        top : floor(offset.top + (window.pageYOffset || root.scrollTop || body.scrollTop) - (root.clientTop || body.clientTop || 0)),
        left : floor(offset.left + (window.pageXOffset || root.scrollLeft || body.scrollLeft) - (root.clientLeft || body.clientLeft || 0))
      };
    }

    else if (type == "object" || type == "function") {
      var getStyle = window.getComputedStyle,
          i = this.length - 1,
          element;

      for ( ; i >= 0; --i) {
        element = this[i];

        offset = type == "function" ? options(i, _(element).offset()) : options;

        element.style.top = offset.top + "px";
        element.style.left = offset.left + "px";

        if (getStyle(element).position == "static") {
          element.style.position = "relative";
        }
      }

      return this;
    }

    else { throw new TypeError(""); }
  },

  on : function (types, callback, useCapture) {
    if (typeof types != "string") {
      throw new TypeError(types + " is not a String");
    }

    if (!(types = types.match(R_NOT_WHITE_SPACES))) {
      return this;
    }

    var i = this.length - 1,
        j, k = types.length;

    for ( ; i >= 0; --i) {
      for (j = 0; j < k; ++j) {
        _.on(this[i], types[j], callback, useCapture);
      }
    }

    return this;
  },

  off : function (types, callback, useCapture) {
    if (typeof types != "string") {
      throw new TypeError(types + " is not a String");
    }

    if (!(types = types.match(R_NOT_WHITE_SPACES))) {
      return this;
    }

    var i = this.length - 1,
        j, k = types.length;

    for ( ; i >= 0; --i) {
      for (j = 0; j < k; ++j) {
        _.off(this[i], types[j], callback, useCapture);
      }
    }

    return this;
  },

  width : function (w) {
    if (w == null) {
      return this[0] === window ? max(document.documentElement.clientWidth, window.innerWidth || 0) : this[0].clientWidth;
    }

    return this;
  },

  height : function (h) {
    if (h == null) {
      return this[0] === window ? max(document.documentElement.clientHeight, window.innerHeight || 0) : this[0].clientHeight;
    }

    return this;
  }
};


_init = _.fn.init;
_init.prototype = _.fn;

})(window, document);
