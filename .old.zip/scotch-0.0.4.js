/**
 * ScotchJS (c) 2017 SILENT.
 * Released under the MIT License.
 */

;(function (window, undefined) {

"use strict";

var document = window.document,
    body = document.createElement("body"),

    obj = Object.prototype,
    str = String.prototype,
    arr = Array.prototype,
    fn = Function.prototype,

    hasOwnProperty = obj.hasOwnProperty,
    toString = obj.toString,

    slice = arr.slice,
    push = arr.push,
    sort = arr.sort,

    call = fn.call,

    floor = Math.floor,
    round = Math.round,
    rand = Math.random,
    max = Math.max,
    min = Math.min,

    MAX_SAFE_INT = 9007199254740991,
    MIN_SAFE_INT = -MAX_SAFE_INT,
    MAX_LENGTH = 4294967295,

    RE_SIMPLE_SELECTOR = /^(?:#([\w-]+)|([\w-]+)|\.([\w-]+))$/,
    RE_NOT_WHITESPACES = /[^\s\uFEFF\xA0]+/g,
    RE_HTML = /^(<([\w-]+)><\/[\w-]+>|<([\w-]+)(\s*\/)?>)$/,

    RE_TRIM_START = /^[\s\uFEFF\xA0]+/,
    RE_TRIM_END = /[\s\uFEFF\xA0]+$/,
    RE_TRIM = RegExp(RE_TRIM_START.source + "|" + RE_TRIM_END.source),

    ERR_INVALID_ARGS = "Invalid arguments",
    ERR_NOT_FUNCTION = "Expected a function",
    ERR_NOT_OBJECT = "Expected an object",
    ERR_NOT_STRING = "Expected a string",
    ERR_CONVERT_TO_OBJECT = "Cannot convert undefined or null to object",

    TAGS = {};

var support = {
  getElementsByClassName: toString.call(document.getElementsByClassName) == "[object Function]",
  defineGetter: toString.call(obj.defineGetter) == "[object Function]",

  defineProperty: function () {
    if ("defineProperty" in Object && "defineProperties" in Object) {
      try {
        return "a" in Object.defineProperty({}, "a", {}) && 2;
      } catch (e) {
        return 1;
      }
    } else {
      return 0;
    }
  }()
};

var isNumber = function (n) {
  return n === 0 || !!n && (
    typeof n == "number" ||
    toString.call(n) == "[object Number]");
};

var isString = function (n) {
  return n != null && (
    typeof n == "string" ||
    toString.call(n) == "[object String]");
};

var isBoolean = function (n) {
  return n != null && (
    n === true ||
    n === false ||
    toString.call(n) == "[object Boolean]");
};

var isUndefined = function (n) {
  return n === undefined;
};

var isFunction = function (n) {
  return !!n &&
    typeof n == "function" &&
    toString.call(n) == "[object Function]";
};

var isObject = function (n) {
  return !!n && typeof n == "object";
};

var isPrimitive = function (n) {
  var type;

  return n == null || ( type = typeof n ) != "object" && type != "function";
};

var isNaN = function (n) {
  return n != n;
};

var isFinite = function (n) {
  return isNumber(n) && window.isFinite(n);
};

var isSafeInteger = function (n) {
  return isFinite(n) &&
    n <= MAX_SAFE_INT &&
    n >= MIN_SAFE_INT &&
    n % 1 == 0;
};

var isArray = Array.isArray || function (n) {
  return !!n &&
    typeof n == "object" &&
    "length" in n &&
    toString.call(n) == "[object Array]";
};

var isArrayLike = function (n) {
  var length;

  return !!n &&
    n.window !== n &&
    typeof n == "object" &&
    typeof ( length = n.length ) == "number" &&
    length >= 0 &&
    length <= MAX_LENGTH &&
    length % 1 == 0;
};

var isHTMLElement = ~toString.call(body).indexOf("HTML") ?

// With ( <String>.indexOf() x 2 ) faster then <RegExp>.test()
function (n) {
  var type;

  return isObject(n) &&
    ( type = toString.call(n) ).indexOf("HTML") > 0 &&
    type.indexOf("Element") > 0;
} :

function (n) {
  var name;

  return isObject(n) &&
    n.nodeType === 1 &&
    n.nodeName === ( name = n.tagName ) &&
    typeof name == "string";
};

// BUG: In IE8 isPlainObject( <HTMLBodyElement> ) == true
var isPlainObject = function () {
  var fnToString = fn.toString,
      fnObject = fnToString.call(Object);

  return function (n) {
    var prototype;

    return _type(n) == "object" && (
      ( prototype = _getPrototypeOf(n) ) === null ||
      hasOwnProperty.call(prototype, "constructor") &&
      fnToString.call(prototype.constructor) == fnObject);
  };
}();

var _type = function (n) {
  var type, tag;

  return n === null ?
    "null" : n === undefined ?
    "undefined" : ( type = typeof n ) == "object" || type == "function" ?
    TAGS[tag = toString.call(n)] || ( TAGS[tag] = tag.slice(8, -1).toLowerCase() ) : type;
};

var _noConflict = function () {
  var __ = window._,
      _Scotch = window.Scotch;

  return function (full) {
    return window._ === this && ( window._ = __ ),
      full && window.Scotch === this && ( window.Scotch = _Scotch ), this;
  };
}();

var _clone = function (deep, target) {
  if ( !isBoolean(deep) ) {
    target = deep;
    deep = true;
  }

  if (target == null) {
    throw TypeError(ERR_CONVERT_TO_OBJECT);
  }

  var clone = _create( target = Object(target) ),
      keys = _keys(target),
      length = keys.length,
      i = 0,
      value, key;

  for ( ; i < length; ++i) {
    value = target[key = keys[i]];

    clone[key] = deep &&
      value !== target &&
      isObject(value) ?
      _clone(deep, value) : value;
  }

  return clone;
};

var _mixin = function (target) {
  var deep = true,
      length = arguments.length,
      i = 1,
      expander, keys, key, value, source, j, k, a;

  if ( isBoolean(target) ) {
    deep = target;
    target = arguments[i++];
  }

  if (target == null) {
    throw TypeError(ERR_CONVERT_TO_OBJECT);
  }

  target = Object(target);

  for ( ; i < length; ++i) {
    expander = arguments[i];

    if (expander == null) {
      throw TypeError(ERR_CONVERT_TO_OBJECT);
    }

    expander = Object(expander);
    keys = _keys(expander);
    j = 0;
    k = keys.length;

    for ( ; j < k; ++j) {
      key = keys[j];
      value = expander[key];

      if ( deep && value != null && value !== expander && ( ( a = isArray(value) ) || isPlainObject(value) ) ) {
        source = target[key];

        if (a) {
          if ( !isArray(source) ) {
            source = [];
          }
        } else {
          if ( !isPlainObject(source) ) {
            source = {};
          }
        }

        target[key] = _mixin(deep, source, value);
      } else {
        target[key] = value;
      }
    }
  }

  return target;
};

var _clamp = function (n, lower, upper) {
  return arguments.length < 3 ?
    n > lower ? lower : n :
    n > upper ? upper : n < lower ? lower : n;
};

var _toArray = function (n) {
  if ( typeof n != "string" && !isArrayLike(n) ) {
    return [n];
  }

  var i = n.length,
      a = Array(i--);

  for ( ; i >= 0; --i) if (i in n) {
    a[i] = n[i];
  }

  return a;
};

var _random = function (floating, lower, upper) {
  if ( !isBoolean(floating) ) {
    upper = lower;
    lower = floating;
    floating = false;
  }

  if (upper == null) {
    upper = lower == null ? 1 : lower;
    lower = 0;
  }

  var n = lower + rand() * (upper - lower);

  return floating ? n : round(n);
};

var _get = function (path, async) {
  if ( !isString(path) || !/^\S*\.\w+$/.test(path) ) {
    throw TypeError(ERR_INVALID_ARGS);
  }

  var ajax = new XMLHttpRequest(),
      data = null,
      id;

  ajax.open("GET", path, isBoolean(async) && async);

  ajax.onload = function () {
    if (this.readyState === 4 && this.status === 200) {
      window.clearTimeout(id);

      data = this.responseText;
    }
  };

  id = window.setTimeout(function () {
    ajax.abort();
  }, 6e4);

  ajax.send(null);

  return data;
};

var _include = function (path) {
  var code = _get(path, false);

  return code !== null &&
    document.body.appendChild(
      new init( document.createElement("script") )
        .attr("type", "text/javascript")
        .text(code)[0] ), true;
};

var _findValue = function (object, key) {
  var k, e,
      isFunction = typeof key == "function";

  if ( isPrimitive(object) ) {
    throw TypeError(ERR_NOT_OBJECT);
  }

  for (k in object) if ( hasOwnProperty.call(object, k) ) {
    e = object[k];

    if (isFunction ? key(e, k, key) : k === key) {
      return [true, e];
    }

    if ( e !== object && !isPrimitive(e) && ( e = _findValue(e, key) )[0] ) {
      return e;
    }
  }

  return [false];
};

var _slice = function (n, start, end) {
  if ( typeof n != "string" && !isArrayLike(n) ) {
    return [n];
  }

  var length = n.length,
      l = arguments.length,
      i = ( end = l < 3 ? length : min(length, ( end = floor(end) ) < 0 ? length + end : end) ) - ( l < 2 ? 0 : ( start = floor(start) ) < 0 ? max(0, length + start) : start ),
      a = Array(i--);

  for ( ; i >= 0; --i) if (i in n) {
    a[i] = n[--end];
  }

  return a;
};

var _times = function (n, callback) {
  var i = 0,
      a = Array(n = arguments.length < 2 ? ( callback = n, 1 ) : n >>> 0 || 1);

  for ( ; i < n; ++i) {
    a[i] = callback(i);
  }

  return a;
};

var _each = function (target, callback, context) {
  if (target == null) {
    throw TypeError("each called on null or undefined");
  }

  var keys, key, element, returned,
      n = isArrayLike( target = Object(target) ),
      i = 0,
      length = n ? target.length : ( keys = _keys(target) ).length;

  for ( ; i < length; ++i) if (!n || i in target) {
    returned = n ?
      callback.call(element = target[i], i, element) : callback.call(element = target[key = keys[i]], key, element);

    if ( isBoolean(returned) && !returned ) {
      break;
    }
  }

  return target;
};

var _values = function () {
  var values = function (key) {
    return this[key];
  };

  return function (target) {
    return _map(_keys(target), values, target);
  };
};

var _invert = function (target) {
  var temp = {},
      value;

  _forEach(_keys(target), function (key) {
    if ( ( value = target[key] ) != null ) {
      temp["" + value] = key;
    }
  });

  return temp;
};

var _takeValue = function (target, defaultValue, key) {
  var length = arguments.length,
      keys;

  if (length < 3) {
    key = defaultValue;
    defaultValue = undefined;

    if (length < 2) {
      key = isArrayLike(target) ?
        _random(false, 0, target.length - 1) : ( keys = _keys(target) )[_random(false, 0, keys.length - 1)];
    }
  }

  return length < 2 || key in target ?
    target[key] : defaultValue;
};

var _bind = call.bind ? call.bind(call.bind) : function (target, context) {
  if (typeof target != "function") {
    throw TypeError(ERR_NOT_FUNCTION);
  }

  var args = slice.call(arguments, 2);

  return function () {
    return target.apply( context, args.concat( slice.call(arguments) ) );
  };
};

// BUG: In IE8 Object( "0" )[0] === undefined
var _indexOf = arr.indexOf ? _bind(call, arr.indexOf) : function (target, element, i) {
  if (target == null) {
    throw TypeError("indexOf called on null or undefined");
  }

  var argsLength = arguments.length,
      length = ( target = Object(target) ).length >>> 0;

  if (argsLength < 2 || length == 0) {
    return -1;
  }

  i = argsLength > 2 ?
    ( i = floor(i) ) < 0 ? max(0, length + i) : i : 0;

  for ( ; i < length; ++i) if (i in target && target[i] === element) {
    return i;
  }

  return -1;
};

var _lastIndexOf = arr.lastIndexOf ? _bind(call, arr.lastIndexOf) : function (target, element, i) {
  if (target == null) {
    throw TypeError("lastIndexOf called on null or undefined");
  }

  var argsLength = arguments.length,
      length = ( target = Object(target) ).length >>> 0;

  if (argsLength < 2 || length == 0) {
    return -1;
  }

  i = argsLength > 2 ?
    min(length - 1, ( i = floor(i) ) < 0 ? length + i : i) : length - 1;

  for ( ; i >= 0; --i) if (i in target && target[i] === element) {
    return i;
  }

  return -1;
};

var _every = arr.every ? _bind(call, arr.every) : function (target, callback, context) {
  if (target == null) {
    throw TypeError("every called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0,
      i = 0;

  for ( ; i < length; ++i) {
    if ( i in target && !callback.call(context, target[i], i, target) ) {
      return false;
    }
  }

  return true;
};

var _some = arr.some ? _bind(call, arr.some) : function (target, callback, context) {
  if (target == null) {
    throw TypeError("some called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0,
      i = 0;

  for ( ; i < length; ++i) {
    if ( i in target && callback.call(context, target[i], i, target) ) {
      return true;
    }
  }

  return false;
};

var _forEach = arr.forEach ? _bind(call, arr.forEach) : function (target, callback, context) {
  if (target == null) {
    throw TypeError("forEach called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0,
      i = 0;

  for ( ; i < length; ++i) if (i in target) {
    callback.call(context, target[i], i, target);
  }
};

var _map = arr.map ? _bind(call, arr.map) : function (target, callback, context) {
  if (target == null) {
    throw TypeError("map called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0,
      i = 0,
      temp = [];

  for ( ; i < length; ++i) if (i in target) {
    temp[i] = callback.call(context, target[i], i, target);
  }

  return temp;
};

var _filter = arr.filter ? _bind(call, arr.filter) : function (target, callback, context) {
  if (target == null) {
    throw TypeError("filter called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0,
      i = 0,
      temp = [],
      element;

  for ( ; i < length; ++i) {
    if ( i in target && callback.call(context, element = target[i], i, target) ) {
      temp.push(element);
    }
  }

  return temp;
};

var _reduce = arr.reduce ? _bind(call, arr.reduce) : function (target, callback, value) {
  if (target == null) {
    throw TypeError("reduce called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0,
      i = 0;

  if (arguments.length < 3) {
    while ( i < length && !(i in target) ) {
      ++i;
    }

    if (i == length) {
      throw TypeError("Reduce of empty array with no initial value");
    }

    value = target[i++];
  }

  for ( ; i < length; ++i) if (i in target) {
    value = callback(value, target[i], i, target);
  }

  return value;
};

var _reduceRight = arr.reduceRight ? _bind(call, arr.reduceRight) : function (target, callback, value) {
  if (target == null) {
    throw TypeError("reduceRight called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0,
      i = length - 1;

  if (arguments.length < 3) {
    while ( i >= 0 && !(i in target) ) {
      --i;
    }

    if (!~i) {
      throw TypeError("Reduce of empty array with no initial value");
    }

    value = target[i--];
  }

  for ( ; i >= 0; --i) if (i in target) {
    value = callback(value, target[i], i, target);
  }

  return value;
};

var _fill = function (target, value, start, end) {
  if (target == null) {
    throw TypeError("reduceRight called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0;

  start = isFinite(start) ?
    ( start = floor(start) ) < 0 ? max(0, length + start) : min(length, start) : 0;

  end = isFinite(end) ?
    ( end = floor(end) ) < 0 ? max(0, length + end) : min(length, end) : length;

  while (start < end) {
    target[start++] = value;
  }

  return target;
};

var _shuffle = function () {
  var shuffle = function () {
    return rand() - rand();
  };

  return function (n) {
    return sort.call( _toArray(n), shuffle );
  };
}();

var baseMerge = function (target, expander) {
  var i = 0,
      length = expander.length;

  for ( ; i < length; ++i) if (i in expander) {
    push.call(target, expander[i]);
  }

  return target;
};

var _merge = function (target) {
  if (target == null) {
    throw TypeError(ERR_CONVERT_TO_OBJECT);
  }

  var i = 1,
      length = arguments.length,
      expander;

  target = Object(target);

  for ( ; i < length; ++i) {
    expander = arguments[i];

    if ( isArrayLike(expander) ) {
      baseMerge(target, expander);
    } else {
      push.call(target, expander);
    }
  }

  return target;
};

var _compact = function () {
  var isDefined = function (n) {
    return n !== undefined;
  };

  return function (target) {
    return _filter(target, isDefined);
  };
}();

var _unique = function () {
  var unique = function (element, i, target) {
    return _indexOf(target, element) == i;
  };

  return function (target) {
    return _filter(target, unique);
  };
}();

var _without = function () {
  var a = function (value) {
    return value !== this;
  };

  var without = function (element) {
    return _every(this, a, element);
  };

  return function (target) {
    return _filter( target, without, slice.call(arguments, 1) );
  };
}();

var _reverse = function (target) {
  return _toArray(target).reverse();
};

var _defineProperty = support.defineProperty === 2 ?
  Object.defineProperty :

function () {
  if (support.defineGetter) {
    var defineGetter = obj.__defineGetter__,
        defineSetter = obj.__sefineGetter__;
  }

  return function (object, key, descriptor) {
    if ( isPrimitive(object) ) {
      throw TypeError("defineProperty called on non-object");
    }

    if ( isPrimitive(descriptor) ) {
      throw TypeError("Property description must be an object: " + descriptor);
    }

    if (support.defineProperty === 1) try {
      return Object.defineProperty(object, key, descriptor);
    } catch (e) {}

    var hasValue = "value" in descriptor,
        hasGetter = "get" in descriptor,
        hasSetter = "set" in descriptor,
        get = descriptor.get,
        set = descriptor.set;

    if (hasGetter || hasSetter)  {
      if (typeof get != "function") {
        throw TypeError("Getter must be a function: " + get);
      }

      if (typeof set != "function") {
        throw TypeError("Setter must be a function: " + set);
      }

      if ("writable" in descriptor) {
        throw TypeError("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute, #<Object>");
      }

      if (support.defineGetter) {
        hasGetter && defineGetter.call(object, key, get);
        hasSetter && defineSetter.call(object, key, set);
      }
    } else {
      hasValue ?
        object[key] = descriptor.value : key in object || ( object[key] = undefined );
    }

    return object;
  };
}();

var _defineProperties = support.defineProperty ?
  Object.defineProperties :

function (object, descriptors) {
  if ( isPrimitive(object) ) {
    throw TypeError("defineProperties called on non-object");
  }

  if ( isPrimitive(descriptors) ) {
    throw TypeError("Property description must be an object: " + descriptors);
  }

  return _each(descriptors, function (key, descriptor) {
    _defineProperty(object, key, descriptor);
  }), object;
};

var _create = Object.create || function () {
  var Constructor = function () {};

  return function (prototype, descriptors) {
    if ( prototype !== null && isPrimitive(prototype) ) {
      throw TypeError("Object prototype may only be an Object or null: " + prototype);
    }

    var object = ( Constructor.prototype = prototype, new Constructor() );

    Constructor.prototype = null;

    if (prototype === null) {
      _setPrototypeOf(object, null);
    }

    return arguments.length > 1 ?
      _defineProperties(object, descriptors) : object;
  };
}();

var _keys = Object.keys || function () {
  var hasEnumBug = !{ toString: null }.propertyIsEnumerable("toString"),

  nonEnums = [
    "toString",
    // "toJSON", ?
    "toLocaleString",
    "valueOf",
    "hasOwnProperty",
    "isPrototypeOf",
    "propertyIsEnumerable",
    "constructor"
  ];

  return function (n) {
    if ( isPrimitive(n) ) {
      throw TypeError(ERR_NOT_OBJECT);
    }

    var keys = [],
        key;

    for (key in n) if ( hasOwnProperty.call(n, key) ) {
      keys.push(key);
    }

    return hasEnumBug ?
      keys.concat( _filter(nonEnums, function (key) {
        return !~_indexOf(keys, key) && hasOwnProperty.call(n, key);
      }) ) : keys;
  };
}();

var _getPrototypeOf = Object.getPrototypeOf || function (n) {
  if (n == null) {
    throw TypeError("setPrototypeOf called on null or undefined");
  }

  var prototype = n.__proto__,
      constructor;

  return prototype !== undefined ?
    prototype : isFunction(constructor = n.constructor) ?
    constructor.prototype : n instanceof Object ?
    obj : null;
};

var _setPrototypeOf = Object.setPrototypeOf || function (n, prototype) {
  if (n == null) {
    throw TypeError("setPrototypeOf called on null or undefined");
  }

  if (prototype === undefined) {
    throw TypeError(ERR_INVALID_ARGS);
  }

  return "__proto__" in n &&
    ( n.__proto__ = prototype ), n;
};

var _assign = Object.assign || function (target) {
  if (target == null) {
    throw TypeError(ERR_CONVERT_TO_OBJECT);
  }

  target = Object(target);

  var i = 1,
      length = arguments.length,
      source, key;

  for ( ; i < length; ++i) {
    source = arguments[i];

    if (source != null) {
      for (key in source) {
        if ( hasOwnProperty.call(source, key) ) {
          target[key] = source[key];
        }
      }
    }
  }

  return target;
};

var baseReplace = function (regexp, name) {
  name += " called on null or undefined";

  return function (target) {
    if (target == null) {
      throw TypeError(name);
    }

    return ("" + target).replace(regexp, "");
  };
};

var _trim = str.trim ?
  _bind(call, str.trim) : baseReplace(RE_TRIM, "trim");

var _trimStart = str.trimStart ?
  _bind(call, str.trimStart) : baseReplace(RE_TRIM_START, "trimStart");

var _trimEnd = str.trimEnd ?
  _bind(call, str.trimEnd) : baseReplace(RE_TRIM_END, "trimEnd");

var _now = Date.now || function () {
  return new Date().getTime();
};

var Event = function (source, options) {
  if ( isObject(source) ) {
    this.originalEvent = source;
    this.type = source.type;

    this.target = source.target &&
      source.target.nodeType === 3 ?
        source.target.parentNode : source.target;

    this.currentTarget = source.currentTarget;
    this.relatedTarget = source.relatedTarget;
  } else if ( isString(source) ) {
    this.type = source;
  } else {
    throw TypeError(ERR_INVALID_ARGS);
  }

  if ( isObject(options) ) {
    _mixin(this, options);
  }

  this.timeStamp = (source && source.timeStamp) || _now();
};

Event.prototype = {
  constructor: Event,

  preventDefault: function () {
    var event = this.originalEvent;

    if (event) {
      if (event.preventDefault) {
        event.preventDefault();
      } else {
        event.returnValue = false;
      }
    }
  },

  stopPropagation: function () {
    var event = this.originalEvent;

    if (event) {
      if (event.stopPropagation) {
        event.stopPropagation();
      } else {
        event.cancelBubble = true;
      }
    }
  }
};

/**
 * Based on Jonathan Neal addEventListener() polyfill.
 * https://gist.github.com/jonathantneal/3748027
 */
var EventListener = new function () {
  if (window.addEventListener) {
    // In IE <Window>.addEventListener !== <HTMLElement>.addEventListener,
    // so _bind(call, window.addEventListener) will not work.
    this.add = function (target, type, listener, useCapture) {
      target.addEventListener(type, listener, useCapture);
    };

    this.remove = function (target, type, listener, useCapture) {
      target.removeEventListener(type, listener, useCapture);
    };

    return this;
  }

  var list = {};

  this.add = function (target, type, listener, useCapture) {
    if (typeof listener != "function") {
      return;
    }

    if (useCapture == null) {
      useCapture = false;
    }

    var wrapper = function (event) {
      if (type === "DOMContentLoaded" && target.readyState !== "complete") {
        return;
      }

      listener.call( target, ( ( event = new Event(event) ).type = type, event ) );
    };

    ( list[type] || ( list[type] = [] ) ).push([target, listener, useCapture, wrapper]);

    target.attachEvent(type === "DOMContentLoaded" ?
      "onreadystatechange" : "on" + type, wrapper);
  };

  this.remove = function (target, type, listener, useCapture) {
    var filtered = list[type],
        i, item;

    if (!filtered) {
      return;
    }

    if (useCapture == null) {
      useCapture = false;
    }

    i = filtered.length;

    type = type === "DOMContentLoaded" ?
      "onreadystatechange" : "on" + type;

    for ( ; i >= 0; --i) {
      item = filtered[i];

      if (item[0] === target &&
        item[1] === listener &&
        item[2] === useCapture) {

        list.splice( i. i + 1 );

        return target.detachEvent(type, item[3]);
      }
    }
  };
}();

/**
 * Jonathan Neal getComputedStyle() polyfill.
 * https://github.com/jonathantneal/polyfill/blob/master/polyfills/getComputedStyle/polyfill.js
 *
 * Small fixes and formatting from ScotchJS.
 */
var getComputedStyle = window.getComputedStyle || function () {
  var noop = function () {},
      camelCase = function (m) { return m.charAt(1).toUpperCase(); },
      unCamelCase = function (m) { return "-" + m.toLowerCase(); };

  var getComputedStylePixel = function (element, property, fontSize) {
    // Internet Explorer sometimes struggles to read currentStyle until the element's document is accessed.
    var value = element.document && element.currentStyle[property].match(/([\d.]+)(em|%|cm|in|mm|pc|pt|)/) || [0, 0, ""],
        size = value[1],
        suffix = value[2],
        rootSize, parent;

    fontSize = fontSize !== null ?
      fontSize : ( parent = element.parentElement ) && /%|em/.test(suffix) ?
      getComputedStylePixel(parent, "fontSize", null) : 16;

    rootSize = property == "fontSize" ?
      fontSize : /width/i.test(property) ?
      element.clientWidth : element.clientHeight;

    return suffix == "em" ?
      size * fontSize : suffix == "%" ?
      size / 100 * rootSize : suffix == "cm" ?
      size * 0.3937 * 96 : suffix == "in" ?
      size * 96 : suffix == "mm" ?
      size * 0.3937 * 96 / 10 : suffix == "pc" ?
      size * 12 * 96 / 72 : suffix == "pt" ?
      size * 96 / 72 : size;
  };

  var setShortStyleProperty = function (style, property) {
    var borderSuffix = property == "border" ? "Width" : "",
        t = property + "Top" + borderSuffix,
        r = property + "Right" + borderSuffix,
        b = property + "Bottom" + borderSuffix,
        l = property + "Left" + borderSuffix;

    style[property] = (style[t] == style[r] && style[t] == style[b] && style[t] == style[l] ?
      [style[t]] : style[t] == style[b] && style[l] == style[r] ?
      [style[t], style[r]] : style[l] == style[r] ?
      [style[t], style[r], style[b]] : [style[t], style[r], style[b], style[l]]).join(" ");
  };

  var CSSStyleDeclaration = function (element) {
    var style = this,
        currentStyle = element.currentStyle,
        fontSize = getComputedStylePixel(element, "fontSize");

    _forEach(_keys(currentStyle), function (property) {
      push.call( style, property == "styleFloat" ? "float" : property.replace(/[A-Z]/, unCamelCase) );

      if (property == "styleFloat") {
        style["float"] = currentStyle[property];
      } else if ( /^outline/.test(property) ) {
        try {
          // errors on checking outline
          style[property] = currentStyle[property];
        } catch (e) {
          style.outline = [
            style.outlineColor = currentStyle.color,
                              // curentStyle?
            style.outlineStyle = style.outlineStyle || "none",
            style.outlineWidth = style.outlineWidth || "0px"
          ].join(" ");
        }
      } else {
        style[property] = property == "width" ?
          element.offsetWidth + "px{" : property == "height" ?
          element.offsetHeight + "px" : /* curentStyle? */ style[property] != "auto" && /(margin|padding|border).+W/.test(property) ?
          round( getComputedStylePixel(element, property, fontSize) ) + "px" : currentStyle[property];
      }
    });

    setShortStyleProperty(style, "margin");
    setShortStyleProperty(style, "padding");
    setShortStyleProperty(style, "border");

    style.fontSize = round(fontSize) + "px";
  };

  CSSStyleDeclaration.prototype = {
    constructor: CSSStyleDeclaration,

    getPropertyValue: function (property) {
      return this[~property.indexOf("-") ?
        property.replace(/-\w/g, camelCase) : property] || "";
    },

    item: function (i) {
      return this[i];
    },

    getPropertyPriority: noop,
    getPropertyCSSValue: noop,
    removeProperty: noop,
    setProperty: noop
  };

  return function (element) {
    return new CSSStyleDeclaration(element);
  };
}();

/**
 * Based on Erik Möller requestAnimationFrame() polyfill:
 *
 * Adapted from https://gist.github.com/paulirish/1579671 which derived from
 * http://paulirish.com/2011/requestanimationframe-for-smart-animating/
 * http://my.opera.com/emoller/blog/2011/12/20/requestanimationframe-for-smart-er-animating
 *
 * requestAnimationFrame polyfill by Erik Möller.
 * Fixes from Paul Irish, Tino Zijdel, Andrew Mao, Klemen Slavič, Darius Bacon.
 *
 * MIT license
 */
var animation = new function () {
  var suffix = "AnimationFrame",

  request = window["request" + suffix] ||
    window["webkitRequest" + suffix] ||
    window["mozRequest" + suffix],

  cancel = window["cancel" + suffix] ||
    window["webkitCancel" + suffix] ||
    window["webkitCancelRequest" + suffix] ||
    window["mozCancel" + suffix] ||
    window["mozCancelRequest" + suffix];

  // iOS6 is buggy
  if (!/iP(ad|hone|od).*OS\s6/.test(window.navigator.userAgent) && request && cancel) {
    this.request = function (callback) {
      return request.call(window, callback);
    };

    this.cancel = function (id) {
      return cancel.call(window, id);
    };
  } else {
    var lastTime = 0,
        frameDuration = 1000 / 60;

    this.request = function (callback) {
      var now = _now(),
          nextTime = max(lastTime + frameDuration, now);

      return window.setTimeout(function () {
        callback( lastTime = nextTime );
      }, nextTime - now);
    };

    this.cancel = window.clearTimeout;
  }
}();

var matches = ( window.Element && (
  Element.prototype.matches ||
  Element.prototype.oMatchesSelector ||
  Element.prototype.msMatchesSelector ||
  Element.prototype.mozMatchesSelector ||
  Element.prototype.webkitMatchesSelector) ) ||

function (selector) {
  if ( !isString(selector) ) {
    throw TypeError(ERR_NOT_STRING);
  }

  var element = this,
      elements = (element.document || element.ownerDocument).querySelectorAll(selector),
      i = elements.length - 1;

  for ( ; i >= 0 && elements[i] !== element; --i) {}

  return !!~i;
};

var closest = (window.Element && Element.prototype.closest) || function (selector) {
  for (var element = this; element; element = element.parentElement) {
    if ( matches.call(element, selector) ) {
      return element;
    }
  }

  return null;
};

var parseHTML = function (data) {
  var match = RE_HTML.exec(data),
      temp = match ? match[2] || match[3] : false;

  return temp ?
    [document.createElement(temp)] : ( ( temp = document.createElement("body") ).innerHTML = data, temp.children );
};

var isSomething = function (n) {
  var type;

  return !!n &&
    typeof n == "object" &&
    (n.window === n || ( type = n.nodeType ) === 1 || type === 9);
};

var init = function (selector) {
  if (!selector) {
    return this;
  }

  var i, match, list;

  if ( isSomething(selector) ) {
    list = [selector];
  } else if ( isString(selector) ) {
    list = selector.charAt(0) == "<" ?
      parseHTML(selector) : !( match = RE_SIMPLE_SELECTOR.exec(selector) ) ?
      document.querySelectorAll(selector) : match[1] ?
      [document.getElementById(match[1])] : match[2] ?
      document.getElementsByTagName(match[2]) : support.getElementsByClassName ?
      document.getElementsByClassName(match[3]) : document.querySelectorAll(selector);
  } else if ( isArrayLike(selector) ) {
    list = selector;
  } else if ( isFunction(selector) ) {
    return new init(document).ready(selector);
  }

  if (!list || !list[0]) {
    return this;
  }

  i = ( this.length = list.length >>> 0 ) - 1;

  for ( ; i >= 0; --i) {
    this[i] = list[i];
  }
};

var _ = _mixin(function (selector) {
  return new init(selector);
}, {
  isNumber: isNumber,
  isString: isString,
  isBoolean: isBoolean,
  isUndefined: isUndefined,
  isFunction: isFunction,
  isObject: isObject,
  isPrimitive: isPrimitive,
  isNaN: isNaN,
  isFinite: isFinite,
  isSafeInteger: isSafeInteger,
  isArray: isArray,
  isArrayLike: isArrayLike,
  isHTMLElement: isHTMLElement,
  isPlainObject: isPlainObject,
  type: _type,
  noConflict: _noConflict,
  clone: _clone,
  mixin: _mixin,
  clamp: _clamp,
  toArray: _toArray,
  random: _random,
  get: _get,
  include: _include,
  findValue: _findValue,
  slice: _slice,
  times: _times,
  each: _each,
  values: _values,
  invert: _invert,
  takeValue: _takeValue,
  bind: _bind,
  indexOf: _indexOf,
  lastIndexOf: _lastIndexOf,
  every: _every,
  some: _some,
  forEach: _forEach,
  map: _map,
  filter: _filter,
  reduce: _reduce,
  reduceRight: _reduceRight,
  fill: _fill,
  shuffle: _shuffle,
  merge: _merge,
  compact: _compact,
  unique: _unique,
  without: _without,
  reverse: _reverse,
  defineProperty: _defineProperty,
  defineProperties: _defineProperties,
  create: _create,
  keys: _keys,
  getPrototypeOf: _getPrototypeOf,
  setPrototypeOf: _setPrototypeOf,
  assign: _assign,
  trim: _trim,
  trimStart: _trimStart,
  trimEnd: _trimEnd,
  now: _now,
  requestAnimationFrame: animation.request,
  cancelAnimationFrame: animation.cancel,
  parseHTML: parseHTML
});

var _fn = init.prototype = _.prototype = _.fn = {
  constructor: _,
  length: 0,

  get: function (i) {
    return arguments.length ?
      this[i < 0 ? this.length + i : i] : _toArray(this);
  },

  eq: function (i) {
    return this.pushStack( arguments.length ?
      [ this[i < 0 ? this.length + i : i] ] : [] );
  },

  each: function (callback) {
    return _each(this, callback);
  },

  style: function (a, b) {
    var i = this.length - 1,
        element, names, name, j, k;

    if ( isString(a) ) {
      if (arguments.length < 2) {
        return ( element = this[0] ) && element.nodeType === 1 ?
          getComputedStyle(element).getPropertyValue(a) : null;
      }

      b += "";

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          element.style[a] = b;
        }
      }
    } else if ( isObject(a) ) {
      k = ( names = _keys(a) ).length;

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          for (j = 0; j < k; ++j) {
            element.style[name = names[j]] = "" + a[name];
          }
        }
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return this;
  },

  attr: function (key, value) {
    var i, j, k, element, isFunction, keys;

    if ( isString(key) ) {
      if (arguments.length < 2) {
        return ( element = this[i] ) && element.nodeType === 1 ?
          element.getAttribute(key) : null;
      }

      i = this.length - 1;
      isFunction = typeof value == "function";

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          element.setAttribute( key, isFunction ? value( i, element.getAttribute(key) ) : value );
        }
      }
    } else if ( isObject(key) ) {
      i = this.length - 1;
      k = ( keys = _keys(key) ).length;

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          for (j = 0; j < k; ++j) {
            element.setAttribute(keys[j], key[keys[j]]);
          }
        }
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return this;
  },

  removeAttr: function (keys) {
    if ( !isString(keys) ) {
      throw TypeError(ERR_NOT_STRING);
    }

    if ( !( keys = keys.match(RE_NOT_WHITESPACES) ) ) {
      return this;
    }

    var i = this.length - 1,
        k = keys.length - 1,
        j, element;

    for ( ; i >= 0; --i) {
      if ( ( element = this[i] ).nodeType === 1 ) {
        for (j = k; j >= 0; --j) {
          element.removeAttribute(keys[j]);
        }
      }
    }

    return this;
  },

  addClass: function (value) {
    var i = this.length - 1,
        j, k, className, element;

    if (typeof value == "function") {
      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          new init(element).addClass( value.call(element, i, element.className) );
        }
      }
    } else if ( isString(value) ) {
      if ( !( value = value.match(RE_NOT_WHITESPACES) ) ) {
        return this;
      }

      k = value.length;

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType !== 1 ) {
          continue;
        }

        className = " " + ( element.className.match(RE_NOT_WHITESPACES) || [] ).join(" ") + " ";

        for (j = 0; j < k; ++j) {
          if ( !~className.indexOf(" " + value[j] + " ") ) {
            className += value[j] + " ";
          }
        }

        element.className = _trim(className);
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return this;
  },

  removeClass: function (value) {
    var i = this.length - 1,
        j, k, className, element;

    if (!arguments.length) {
      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          element.className = "";
        }
      }
    } else if (typeof value == "function") {
      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          new init(element).removeClass( value.call(element, i, element.className) );
        }
      }
    } else if ( isString(value) ) {
      if ( !( value = value.match(RE_NOT_WHITESPACES) ) ) {
        return this;
      }

      for (j = k = value.length - 1; j >= 0; --j) {
        value[j] = RegExp(" " + value[j] + " ", "gi");
      }

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType !== 1 ) {
          continue;
        }

        className = " " + (element.className.match(RE_NOT_WHITESPACES) || []).join(" ") + " ";
        j = k;

        for ( ; j >= 0; --j) {
          className = className.replace(value[j], " ");
        }

        element.className = _trim(className);
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return this;
  },

  toggleClass: function (value, state) {
    if ( isBoolean(state) ) {
      return this[state ? "addClass" : "removeClass"](value);
    }

    var i = this.length - 1,
        j, k, className, element, _element;

    if (typeof value == "function") {
      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          new init(element).toggleClass( value.call(element, i, element.className) );
        }
      }
    } else if ( isString(value) ) {
      if ( !( value = value.match(RE_NOT_WHITESPACES) ) ) {
        return this;
      }

      for (j = ( k = value.length ) - 1; j >= 0; --j) {
        value[j] = " " + value[j] + " ";
      }

      // k = ( value = _map(value, function (n) { return " " + n + " "; }) ).length;

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType !== 1 ) {
          continue;
        }

        _element = new init(element);
        className = " " + (element.className.match(RE_NOT_WHITESPACES) || []).join(" ") + " ";

        for (j = 0; j < k; ++j) {
          _element[~className.indexOf(value[j]) ? "removeClass" : "addClass"](value[j]);
        }
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return this;
  },

  hasClass: function (value) {
    if ( !isString(value) ) {
      throw TypeError(ERR_NOT_STRING);
    }

    if ( !( value = value.match(RE_NOT_WHITESPACES) ) ) {
      return false;
    }

    var i = this.length - 1,
        k = value.length - 1,
        j = k,
        element, className;

    for ( ; j >= 0; --j) {
      value[j] = " " + value[j] + " ";
    }

    for ( ; i >= 0; --i) {
      if ( ( element = this[i] ).nodeType !== 1 ) {
        continue;
      }

      className = " " + (element.className.match(RE_NOT_WHITESPACES) || []).join(" ") + " ";

      for (j = k; j >= 0; --j) {
        if ( ~className.indexOf(value[j]) ) {
          return true;
        }
      }
    }

    return false;
  },

  offset: function (options) {
    var offset, document, root, body, isFn, style, i, element;

    if (!arguments.length) {
      if ( !( element = this[0] ) ) {
        return null;
      }

      if (element.nodeType !== 1) {
        return { top: 0, left: 0 };
      }

      document = element.ownerDocument;
      root = document.documentElement;
      body = document.body;
      offset = element.getBoundingClientRect();

      return {
        top: offset.top + (document.defaultView.pageYOffset || root.scrollTop || body.scrollTop) - (root.clientTop || body.clientTop || 0),
        left: offset.left + (document.defaultView.pageXOffset || root.scrollLeft || body.scrollLeft) - (root.clientLeft || body.clientLeft || 0)
      };
    } else if ( !isPrimitive(options) ) {
      isFn = typeof options == "function";
      i = this.length - 1;

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType !== 1 ) {
          continue;
        }

        style = element.style;

        offset = isFn ?
          options( i, new init(element).offset() ) : options;

        style.top = offset.top + "px";
        style.left = offset.left + "px";

        if (style.position === "static" || getComputedStyle(element).position === "static") {
          style.position = "relative";
        }
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return this;
  },

  is: function (selector) {
    var i = this.length - 1,
        j, k, element;

    if (typeof selector == "function") {
      for ( ; i >= 0; --i) {
        element = this[i];

        if ( selector.call(element, i, element) ) {
          return true;
        }
      }
    } else if ( isString(selector) ) {
      for ( ; i >= 0; --i) {
        element = this[i];

        if ( element.nodeType === 1 &&
          matches.call(element, selector) ) {

          return true;
        }
      }
    } else if ( isSomething(selector) ) {
      for ( ; i >= 0; --i) {
        if (this[i] === selector) {
          return true;
        }
      }
    } else if (selector instanceof init) {
      j = selector.length - 1;

      for ( ; j >= 0; --j) {
        element = selector[j];
        k = i;

        for ( ; k >= 0; --k) {
          if (this[k] === element) {
            return true;
          }
        }
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return false;
  },

  closest: function (selector) {
    var i = 0,
        length = this.length,
        list = [],
        element, temp;

    for ( ; i < length; ++i) {
      temp = ( element = this[i] ).nodeType === 1 &&
        closest.call(element, selector);

      if ( temp && !~_indexOf(list, temp) ) {
        list.push(temp);
      }
    }

    return this.pushStack(list);
  },

  parent: function (selector) {
    var select = !!arguments.length,
        i = 0,
        length = this.length,
        list = [],
        element, parent;

    for ( ; i < length; ++i) {
      parent = ( element = this[i] ).nodeType === 1 &&
        element.parentElement;

      if ( parent && !~_indexOf(list, parent) && ( !select || matches.call(parent, selector) ) ) {
        list.push(parent);
      }
    }

    return this.pushStack(list);
  },

  siblings: function (selector) {
    var select = !!arguments.length,
        i = 0,
        length = this.length,
        list = [],
        element, siblings, sibling, j, k;

    for ( ; i < length; ++i) {
      siblings = ( element = this[i] ).nodeType === 1 &&
        element.parentElement.children;

      if (siblings) {
        j = 0;
        k = siblings.length;

        for ( ; j < k; ++j) {
          sibling = siblings[j];

          if ( sibling !== element &&
            sibling.nodeType === 1 &&
            !~_indexOf(list, sibling) &&
            ( !select || matches.call(sibling, selector) ) ) {

            list.push(sibling);
          }
        }
      }
    }

    return this.pushStack(list);
  },

  children: function (selector) {
    var select = !!arguments.length,
        i = 0,
        length = this.length,
        list = [],
        element, children, child, j, k;

    for ( ; i < length; ++i) {
      children = ( element = this[i] ).nodeType === 1 &&
        element.children;

      if (children) for (j = 0, k = children.length; j < k; ++j) {
        child = children[j];

        if ( child.nodeType === 1 && ( !select || matches.call(child, selector) ) ) {
          list.push(child);
        }
      }
    }

    return this.pushStack(list);
  },

  find: function (selector) {
    if ( !isString(selector) ) {
      throw TypeError(ERR_NOT_STRING);
    }

    var i = 0,
        length = this.length,
        list = [],
        element, temp, j, k;

    for ( ; i < length; ++i) {
      temp = ( element = this[i] ).nodeType === 1 &&
        element.querySelectorAll(selector);

      if (temp) for (j = 0, k = temp.length; j < k; ++j) {
        if ( !~_lastIndexOf(list, element = temp[j]) ) {
          list.push(element);
        }
      }
    }

    return this.pushStack(list);
  },

  not: function (selector) {
    var i = 0,
        length = this.length,
        list = [],
        element;

    for ( ; i < length; ++i) {
      element = this[i];

      if ( !new init(element).is(selector) ) {
        list.push(element);
      }
    }

    return this.pushStack(list);
  },

  offsetParent: function () {
    var i = 0,
        length = this.length,
        list = [],
        element, offsetParent;

    for ( ; i < length; ++i) {
      if ( ( element = this[i] ).nodeType !== 1 ) {
        continue;
      }

      offsetParent = element.offsetParent;

      while (offsetParent && (offsetParent.style.position || getComputedStyle(offsetParent).position) === "static") {
        offsetParent = offsetParent.offsetParent;
      }

      ~_indexOf( list, offsetParent || ( offsetParent = element.ownerDocument.documentElement ) ) ||
        list.push(offsetParent);
    }

    return this.pushStack(list);
  },

  position: function () {
    var element = this[0],
        offset, style, offsetParent, offsetParentElement, offsetParentElementStyle, parentOffset;

    if (!element || element.nodeType !== 1) {
      return null;
    }

    style = getComputedStyle(element);
    parentOffset = { top: 0, left: 0 };

    if (style.position === "fixed") {
      offset = element.getBoundingClientRect();
    } else {
      if ( !( offsetParentElement = ( offsetParent = this.offsetParent() )[0] ) || offsetParentElement.nodeType !== 1 ) {
        return null;
      }

      offset = this.offset();

      if (offsetParentElement.nodeName !== "HTML") {
        parentOffset = offsetParent.offset();
      }

      offsetParentElementStyle = getComputedStyle(offsetParentElement);

      parentOffset.top += window.parseInt(offsetParentElementStyle.borderTopWidth, 10);
      parentOffset.left += window.parseInt(offsetParentElementStyle.borderLeftWidth, 10);
    }

    return {
      top: offset.top - parentOffset.top - window.parseInt(style.marginTop, 10),
      left: offset.left - parentOffset.left - window.parseInt(style.marginLeft, 10)
    };
  },

  // BUG: .off() will not work if set listener by that
  one: function (types, listener, useCapture) {
    return this.on(types, function wrapper (event) {
      new init(this).off(event.type, wrapper, useCapture);
      listener.call(this, event);
    }, useCapture);
  },

  remove: function (selector) {
    var select = !!arguments.length;

    return this.each(function () {
      if ( this.nodeType === 1 && ( !select || matches.call(this, selector) ) ) {
        this.parentNode.removeChild(this);
      }
    });
  },

  ready: function (callback) {
    var document = this[0];

    if (!document || document.nodeType !== 9) {
      return this;
    }

    if (document.attachEvent ? document.readyState === "complete" : document.readyState !== "loading") {
      callback(_);
    } else {
      EventListener.add(document, "DOMContentLoaded", function ready (event) {
        EventListener.remove(this, event.type, ready, false);
        callback(_);
      }, false);
    }

    return this;
  },

  pushStack: function (elements) {
    var set = _merge(new init(), elements);

    return set.prevObject = this, set;
  },

  end: function () {
    return this.prevObject || new init();
  }
};

_each({
  value: "value",
  text: "textContent" in body ? "textContent" : "innerText",
  html: "innerHTML"
}, function (method, name) {
  var set = function (element) {
    if (element.nodeType === 1) {
      element[name] = this;
    }
  };

  _fn[method] = function (value) {
    var element;

    return arguments.length ?
      ( _forEach(this, set, value), this ) : ( element = this[0] ) && element.nodeType === 1 ?
      element[name] : null;
  };
});

_each({
  on: "add",
  off: "remove"
}, function (method, name) {
  _fn[method] = function (types, callback, useCapture) {
    if ( !isString(types) ) {
      throw TypeError(ERR_NOT_STRING);
    }

    if ( !( types = types.match(RE_NOT_WHITESPACES) ) ) {
      return this;
    }

    if (useCapture == null) {
      useCapture = false;
    }

    var i = this.length - 1,
        k = types.length - 1,
        j, element;

    for ( ; i >= 0; --i) for (element = this[i], j = k; j >= 0; --j) {
      EventListener[name](this[i], types[j], callback, useCapture);
    }

    return this;
  };
});

_each({
  width: "Width",
  height: "Height"
}, function (method, name) {
  _fn[method] = function (n) {
    var element, body, root;

    return arguments.length ?
      this.style(method, isNumber(n) ? n + "px" : n) : ( element = this[0] ) ?
      element.window === element ?
        max(
          element.document.documentElement["client" + name],
          element["inner" + name] || 0
        ) : element.nodeType === 9 ?
        ( body = element.body, root = element.documentElement, max(
          body["scroll" + name],
          root["scroll" + name],
          body["offset" + name],
          root["offset" + name],
          root["client" + name]
        ) ) : element["client" + name] : null;
  };
});

var getWindow = function (element) {
  return element.window === element ?
    element : element.nodeType == 9 ?
    element.defaultView : false;
};

_each({
  scrollTop: "pageYOffset",
  scrollLeft: "pageXOffset"
}, function (method, name) {
  var top = method === "scrollTop",

  set = function (element) {
    var value = this,
        window = getWindow(element);

    if (window) {
      window.scrollTo(
        top ? window.pageXOffset : value,
        top ? value : window.pageYOffset
      );
    } else {
      element[method] = value;
    }
  };

  _fn[method] = function (value) {
    var element, window;

    return arguments.length ?
      ( _forEach(this, set, value), this ) : ( element = this[0] ) ?
      ( window = getWindow(element) ) ?
        window[name] : element[method] : null;
  };
});

var getDefaultStyle = function ( target ) {
  return getComputedStyle( document.createElement( target.nodeName ) );
};

_each({
  hide: function () {
    this.nodeType === 1 && ( this.style.display = "none" );
  },

  show: function () {
    if (this.nodeType === 1) {
      var style = this.style;

      if (style.display === "none") {
        style.display = "";
      }

      if (getComputedStyle(this).display === "none") {
        style.display = getDefaultStyle( this ).display;
      }
    }
  },

  toggle: function () {
    this.nodeType === 1 &&
      new init(this)[this.style.display === "none" ||
        getComputedStyle(this).display === "none" ?
          "show" : "hide"]();
  }
}, function (name, method) {
  _fn[name] = function () {
    return this.each(method);
  };
});

window.Scotch = window._ = _;

})(window);
