/**
 * ScotchJS (c) 2017 SILENT.
 * Released under the MIT License.
 */
;( function ( window, undefined ) {

'use strict';

var noop = function () {},
    document = window.document,

    // Если страница находится в процессе загрузки body может не быть.
    // If the page is in the process of loading the body may not be.
    body = document.body || document.createElement( 'body' ),

    // Короткие ссылки на нужные прототипы.
    // Short references to the necessary prototypes.
    obj = Object.prototype,
    str = String.prototype,
    arr = Array.prototype,
    fn = Function.prototype,

    // Часто используемые методы.
    // Frequently used methods.
    hasOwnProperty = obj.hasOwnProperty,
    toString = obj.toString,
    concat = arr.concat,
    slice = arr.slice,
    push = arr.push,
    sort = arr.sort,
    call = fn.call,
    floor = Math.floor,
    round = Math.round,
    rand = Math.random,
    ceil = Math.ceil,
    max = Math.max,
    min = Math.min,

    RE_NOT_WHITESPACES = /[^\s\uFEFF\xA0]+/g,

    // Часто используемые сообщения об исключении.
    // Frequently used exception messages.
    ERR_INVALID_ARGS = 'Invalid arguments',
    ERR_NOT_FUNCTION = 'Expected a function',
    ERR_NOT_OBJECT = 'Expected an object',
    ERR_NOT_STRING = 'Expected a string',
    ERR_NULLABLE_PASSED = 'Cannot convert undefined or null to object';

var support = {
  HTMLElement: toString.call( body ).indexOf( 'HTML' ) > 0,
  getElementsByClassName: !!document.getElementsByClassName,
  addEventListener: !!window.addEventListener,
  defineGetter: !!obj.defineGetter,

  defineProperty: function () {
    var test = function ( target ) {
      try {
        return '' in Object.defineProperty( target, '', {} ) ? 1 : 0;
      } catch ( e ) {}

      return 0;
    };

    return test( document.createElement( 'span' ) ) + test( {} );
  }(),

  getAttribute: function () {
    var temp = document.createElement( 'span' ),
        name = 'something';

    try {
      return temp.setAttribute( name, name ), temp.getAttribute( name ) === name;
    } catch ( e ) {}

    return false;
  }()
};

var isNumber = function ( target ) {
  return target != null && (
    typeof target == 'number' ||
    toString.call( target ) == '[object Number]'
  );
};

var isString = function ( target ) {
  return target != null && (
    typeof target == 'string' ||
    toString.call( target ) == '[object String]'
  );
};

var isBoolean = function ( target ) {
  return target != null && (
    target === true ||
    target === false ||
    toString.call( target ) == '[object Boolean]'
  );
};

var isUndefined = function ( target ) {
  return target === undefined;
};

var isFunction = function ( target, onlyFunction ) {
  return !!target &&
    typeof target == 'function' && (
      !onlyFunction || toString.call( target ) == '[object Function]'
    );
};

var isObject = function ( target, onlyObject ) {
  return !!target &&
    typeof target == 'object' && (
      !onlyObject || toString.call( target ) == '[object Object]'
    );
};

var isPrimitive = function ( target ) {
  if ( !target ) {
    return true;
  }

  var type = typeof target;

  return type != 'object' && type != 'function';
};

var isNaN = function ( target ) {
  return target != target;
};

var isFinite = function ( target ) {
  return isNumber( target ) && window.isFinite( target );
};

var MAX_SAFE_INT = 9007199254740991,
    MIN_SAFE_INT = -MAX_SAFE_INT;

var isSafeInteger = function ( target ) {
  return isFinite( target ) &&
    target <= MAX_SAFE_INT &&
    target >= MIN_SAFE_INT &&
    target % 1 == 0;
};

var isArray = Array.isArray || function ( target ) {
  return isObject( target, false ) &&
    typeof target.length == 'number' &&
    toString.call( target ) == '[object Array]';
};

var MAX_LENGTH = 4294967295;

var isArrayLike = function ( target, acceptString, notLimitLength ) {
  var length;

  return ( acceptString && typeof target == 'string' ) ||
    isObject( target, false ) &&
    !isWindow( target, false ) &&
    typeof ( length = target.length ) == 'number' &&
    length >= 0 &&
    ( !!notLimitLength || length <= MAX_LENGTH ) &&
    length % 1 == 0;
};

var isHTMLElement = function ( target, useForce ) {
  if ( !isObject( target, false ) || target.nodeType !== 1 ) {
    return false;
  }

  if ( useForce ) {
    if ( support.HTMLElement ) {
      var temp = toString.call( target );

      return temp.indexOf( 'HTML' ) > 0 &&
        temp.indexOf( 'Element' ) > 0;
    } else {
      var nodeName = target.nodeName,
          tagName;

      return !!nodeName &&
        typeof nodeName == 'string' &&
        /^[A-Z]+$/.test( nodeName ) && (
          !( 'tagName' in target ) ||
          typeof ( tagName = target.tagName ) == 'string' &&
          tagName.toUpperCase() === nodeName
        );
    }
  }

  return typeof target.nodeName == 'string';
};

var fnToString = fn.toString,
    fnObject = fnToString.call( Object );

var isPlainObject = function ( target ) {
  if ( getType( target ) != 'object' ) {
    return false;
  }

  var prototype = getPrototypeOf( target );

  return prototype === null ||
    hasOwnProperty.call( prototype, 'constructor' ) &&
    fnToString.call( prototype.constructor ) == fnObject;
};

var isWindow = function ( target, onlyWindow ) {
  return isObject( target, false ) &&
    target.window === target && (
      !onlyWindow || toString.call( target ) == '[object Window]'
    );
};

var isSomething = function ( target ) {
  var nodeType;

  return isObject( target, false ) && (
    isWindow( target, false ) ||
    !!( nodeType = target.nodeType ) && (
      nodeType === 1 || // ELEMENT_NODE
      nodeType === 3 || // TEXT_NODE
      nodeType === 8 || // COMMENT_NODE
      nodeType === 9 || // DOCUMENT_NODE
      nodeType === 11 // DOCUMENT_FRAGMENT_NODE
    )
  );
};

var types = {};

var getType = function ( target ) {
  var type;

  return target === null ?
    'null' : target === undefined ?
    'undefined' : ( type = typeof target ) == 'object' || type == 'function' ?
    types[ type = toString.call( target ) ] ||
      ( types[ type ] = type.slice( 8, -1 ).toLowerCase() ) : type;
};

var lastType = 'undefined',
    lastTarget;

var getTypeCached = function ( target ) {
  return lastTarget === target ?
    lastType : ( lastType = getType( lastTarget = target ) );
};

var __ = window._,
    _Scotch = window.Scotch;

var noConflict = function ( returnAll ) {
  if ( window._ === this ) {
    window._ = __;
  }

  if ( returnAll && window.Scotch === this ) {
    window.Scotch = _Scotch;
  }

  return this;
};

var makeClone = function ( deep, target ) {
  if ( !isBoolean( deep ) ) {
    target = deep;
    deep = true;
  }

  var clone = createObject( target = toObject( target ) );

  each( target, function ( key, value ) {
    if ( deep && value !== target && isObject( value, false ) ) {
      clone[ key ] = makeClone( deep, value );
    } else {
      clone[ key ] = value;
    }
  } );

  return clone;
};

var mixin = function ( deep, target ) {
  var nowArray = false,
      i = 2,
      length = arguments.length,
      expander, source, keys, key, value, j, k;

  if ( !isBoolean( deep ) ) {
    target = deep;
    deep = true;
    i = 1;
  }

  target = toObject( target );

  for ( ; i < length; ++i ) {
    expander = toObject( arguments[ i ] );
    keys = getKeys( expander );

    for ( j = 0, k = keys.length; j < k; ++j ) {
      key = keys[ j ];
      value = expander[ key ];

      if ( deep && value !== expander &&
        ( isPlainObject( value ) || ( nowArray = isArray( value ) ) ) ) {

        source = target[ key ];

        if ( nowArray ) {
          nowArray = false;

          if ( !isArray( source ) ) {
            source = [];
          }
        } else if ( !isPlainObject( source ) ) {
          source = {};
        }

        target[ key ] = mixin( deep, source, value );
      } else {
        target[ key ] = value;
      }
    }
  }

  return target;
};

var baseClamp = function ( value, lower, upper ) {
  return value > upper ?
    upper : value < lower ?
    lower : value;
};

var clamp = function ( value, lower, upper ) {
  if ( upper === undefined ) {
    upper = lower;
    lower = value;
  }

  return baseClamp( value, lower, upper );
};

var toArray = function ( target ) {
  if ( !isArrayLike( target, true, true ) ) {
    return [ target ];
  }

  var i = target.length,
      array = Array( i-- );

  for ( ; i >= 0; --i ) {
    if ( i in target ) {
      array[ i ] = target[ i ];
    }
  }

  return array;
};

var random = function ( floating, lower, upper ) {
  if ( !isBoolean( floating ) ) {
    upper = lower;
    lower = floating;
    floating = false;
  }

  if ( upper == null ) {
    upper = lower == null ? 1 : lower;
    lower = 0;
  }

  var temp = lower + rand() * ( upper - lower );

  return floating ? temp : round( temp );
};

var findValue = function ( target, search ) {
  if ( isPrimitive( target ) ) {
    throw TypeError( ERR_NOT_OBJECT );
  }

  var isCallable = isFunction( search ),
      keys = getKeys( target ),
      i = 0,
      length = keys.length,
      key, value;

  for ( ; i < length; --i ) {
    value = target[ key = keys[ i ] ];

    if ( isCallable ?
      search.call( target, key, value, search ) : key === search ) {

      return [ true, value ];
    }

    if ( value !== target && !isPrimitive( value ) && ( value = findValue( value, search ) )[ 0 ] ) {
      return value;
    }
  }

  return [ false ];
};

var times = function ( times, callback ) {
  var i = 0,

  results = Array( times = callback === undefined ?
    ( callback = times, 1 ) : floor( times ) || 1 );

  for ( ; i < times; ++i ) {
    results[ i ] = callback( i );
  }

  return results;
};

var each = function ( target, callback, context ) {
  target = toObject( target );

  var keys, key, value,
      arrayPassed = isArrayLike( target, false, true ),
      i = 0,
      length = ( arrayPassed ? target : keys = getKeys( target ) ).length;

  for ( ; i < length; ++i ) {
    if ( arrayPassed && !( i in target ) ) {
      continue;
    }

    key = arrayPassed ? i : keys[ i ];
    value = target[ key ];

    if ( callback.call( value, key, value ) === false ) {
      break;
    }
  }

  return target;
};

var invert = function ( target ) {
  var inverted = {};

  each( target, function ( key, value ) {
    inverted[ value ] = key;
  } );

  return inverted;
};

var bindFast = function ( target, context ) {
  return function ( a, b, c, d ) {
    return target.call( context, a, b, c, d );
  };
};

var fill = function ( target, value, start, end ) {
  if ( !isObject( target, false ) ) {
    throw TypeError( ERR_NOT_OBJECT );
  }

  if ( isArrayLike( target, false, true ) ) {
    var length = target.length;

    start = start === undefined ?
      0 : ( start = floor( start ) ) < 0 ?
      max( 0, length + start ) : start;

    end = end === undefined ?
      length : min( length, ( end = floor( end ) ) < 0 ? length + end : end );

    for ( ; start < end; ++start ) {
      target[ start ] = value;
    }
  } else {
    each( target, function ( key ) {
      target[ key ] = value;
    } );
  }

  return target;
};

var getSize = function ( value ) {
  var stack = [ value ],
      checked = [],
      size = 0;

  while ( stack.length ) {
    value = stack.pop();

    switch ( typeof value ) {
      case 'boolean':
        size += 4;
        break;

      case 'number':
        size += 8;
        break;

      case 'string':
        size += value.length * 2;
        break;

      case 'object':
      case 'function':
        if ( value !== null && indexOf( checked, value ) < 0 ) {
          checked.push( value );

          stack = concat.apply( stack, getEntries( value ) );
        }
    }
  }

  //? stack = checked = null;

  return size;
};

var getFileSize = function ( path, useAsync, callback ) {
  var request = new XMLHttpRequest(),
      size = null;

  request.onreadystatechange = function () {
    if ( this.readyState === this.DONE ) {
      callback( size = window.parseInt( this.getResponseHeader( 'Content-Length' ) ) );
    }
  };

  // Notice "HEAD" instead of "GET",
  // to get only the header
  request.open( 'HEAD', path, useAsync );

  request.send();

  return size;
};

var getFile = function ( path, useAsync, options ) {
  if ( isObject( path, true ) ) {
    options = path;
    path = options.path;
    useAsync = options.useAsync;
  }

  options = options || {};
  useAsync = useAsync !== undefined && useAsync;

  var request = new XMLHttpRequest(),
      data = null,
      id;

  request.onreadystatechange = function () {
    var readyState = this.readyState;

    if ( readyState < 3 ) {
      return;
    } else if ( readyState === 3 ) {
      if ( options.onloading ) {
        options.onloading.call( this, this.responseText, options, this.status, this.statusText );
      }

      return;
    } else if ( readyState === 4 ) {
      if ( this.status !== 200 ) {
        if ( options.onerror ) {
          options.onerror.call( this, options, this.status, this.statusText );
        }

        return;
      }

      if ( id ) {
        window.clearTimeout( id );
      }

      data = this.responseText;

      if ( options.onload ) {
        options.onload.call( this, data, options );
      }
    }
  };

  request.open( 'GET', path, useAsync );

  if ( useAsync ) {
    id = window.setTimeout( function () {
      request.abort();
    }, 'timeout' in options ? options.timeout : 60000 );
  }

  request.send();

  return data;
};

var toObject = function ( target ) {
  if ( target == null ) {
    throw TypeError( ERR_NULLABLE_PASSED );
  }

  return Object( target );
};

var bind = fn.bind ?
  bindFast( call, fn.bind ) :

function ( target, context ) {
  if ( !isFunction( target, false ) ) {
    throw TypeError( ERR_NOT_FUNCTION );
  }

  var args = slice.call( arguments, 2 );

  return function () {
    return target.apply( context, args.concat( slice.call( arguments ) ) );
  };
};

var makeSlice = function ( target, start, end ) {
  if ( !isArrayLike( target, true, true ) ) {
    throw TypeError( ERR_INVALID_ARGS );
  }

  var length = target.length,
      i, array;

  start = start === undefined ?
    0 : ( start = floor( start ) ) < 0 ?
    max( 0, length + start ) : start;

  end = end === undefined ?
    length : min( length, ( end = floor( end ) ) < 0 ? length + end : end );

  i = end - start;
  array = Array( i-- );

  for ( ; i >= 0; --i ) {
    if ( i in target ) {
      array[ i ] = target[ start + i ];
    }
  }

  return array;
};

var baseRange = function ( reverse, start, end, step ) {
  var i = -1,
      j = ceil( ( end - start ) / step ),
      temp = Array( j-- );

  for ( ; j >= 0; --j ) {
    temp[ reverse ? j : ++i ] = start;
    start += step;
  }

  return temp;
};

var createRange = function ( reverse ) {
  return function ( start, end, step ) {
    if ( step === undefined ) {
      step = 1;

      if ( end === undefined ) {
        end = start;
        start = 0;
      }
    }

    // ???
    if ( end < start && step > 0 ) {
      step = -step;
    }

    return baseRange( reverse, start, end, step );
  };
};

var range = createRange( false ),
    rangeRight = createRange( true );

var baseFind = function ( useCallback, returnIndex, reverse, iterable, search, context ) {
  var i = -1,
      j = ( iterable.length >>> 0 ) - 1,
      index, value;

  for ( ; j >= 0; --j ) {
    if ( !( ( index = reverse ? j : ++i ) in iterable ) ) {
      continue;
    }

    value = iterable[ index ];

    if ( useCallback ?
      search.call( context, value, index, iterable ) : value === search ) {

      return returnIndex ?
        index : value;
    }
  }

  if ( returnIndex ) {
    return j;
  }
};

var createFind = function ( useCallback, returnIndex, reverse ) {
  return function ( iterable, search, context ) {
    return baseFind( useCallback, returnIndex, reverse, toObject( iterable ), search, context );
  };
};

var find = arr.find ? bindFast( call, arr.find ) : createFind( true, false, false ),
    findLast = createFind( true, false, true ),
    findIndex = arr.findIndex ? bindFast( call, arr.findIndex ) : createFind( true, true, false ),
    findLastIndex = createFind( true, true, true ),
    indexOf = arr.indexOf ? bindFast( call, arr.indexOf ) : createFind( false, true, false ),
    lastIndexOf = arr.lastIndexOf ? bindFast( call, arr.lastIndexOf ) : createFind( false, true, true );

var baseSomeEvery = function ( some, target, callback, context ) {
  var i = 0,
      length = target.length >>> 0;

  for ( ; i < length; ++i ) {
    if ( i in target && !!callback.call( context, target[ i ], i, target ) === some ) {
      return some;
    }
  }

  return !some;
};

var createSomeEvery = function ( some ) {
  return function ( target, callback, context ) {
    return baseSomeEvery( some, toObject( target ), callback, context );
  };
};

var some = arr.some ? bindFast( call, arr.some ) : createSomeEvery( true ),
    every = arr.every ? bindFast( call, arr.every ) : createSomeEvery( false );

var baseForEach = function ( reverse, target, callback, context ) {
  var i = -1,
      j = ( target.length >>> 0 ) - 1,
      index;

  for ( ; j >= 0; --j ) {
    index = reverse ? j : ++i;

    if ( index in target ) {
      callback.call( context, target[ index ], index, target );
    }
  }
};

var createForEach = function ( reverse ) {
  return function ( target, callback, context ) {
    return baseForEach( reverse, toObject( target ), callback, context );
  };
};

var forEach = arr.forEach ? bindFast( call, arr.forEach ) : createForEach( false ),
    forEachRight = createForEach( true );

var map = arr.map ?
  bindFast( call, arr.map ) :

function ( iterable, callback, context ) {
  iterable = toObject( iterable );

  var i = 0,
      length = iterable.length >>> 0,
      mapped = [];

  for ( ; i < length; ++i ) {
    if ( i in iterable ) {
      mapped[ i ] = callback.call( context, iterable[ i ], i, iterable );
    }
  }

  return mapped;
};

var baseFilter = function ( not, iterable, callback, context ) {
  var i = 0,
      length = iterable.length >>> 0,
      filtered = [],
      value;

  for ( ; i < length; ++i ) {
    if ( i in iterable &&
      !callback.call( context, value = iterable[ i ], i, iterable ) === not ) {

      filtered.push( value );
    }
  }

  return filtered;
};

var filter = arr.filter ?
  bindFast( call, arr.filter ) :

function ( iterable, callback, context ) {
  return baseFilter( false, toObject( iterable ), callback, context );
};

var reduce = arr.reduce ?
  bindFast( call, arr.reduce ) :

function ( iterable, callback, value ) {
  iterable = toObject( iterable );

  var length = iterable.length >>> 0,
      i = 0;

  if ( arguments.length < 3 ) {
    while ( i < length && !( i in iterable ) ) {
      ++i;
    }

    if ( i == length ) {
      throw TypeError( 'Reduce of empty array with no initial value' );
    }

    value = iterable[ i++ ];
  }

  for ( ; i < length; ++i ) {
    if ( i in iterable ) {
      value = callback( value, iterable[ i ], i, iterable );
    }
  }

  return value;
};

var reduceRight = arr.reduceRight ?
  bindFast( call, arr.reduceRight ) :

function ( iterable, callback, value ) {
  iterable = toObject( iterable );

  var length = iterable.length >>> 0,
      i = length - 1;

  if ( arguments.length < 3 ) {
    while ( i >= 0 && !( i in iterable ) ) {
      ++i;
    }

    if ( i < 0 ) {
      throw TypeError( 'Reduce of empty array with no initial value' );
    }

    value = iterable[ i-- ];
  }

  for ( ; i >= 0; --i ) {
    if ( i in iterable ) {
      value = callback( value, iterable[ i ], i, iterable );
    }
  }

  return value;
};

var shuffle = function () {
  var shuffle = function () {
    return rand() - rand();
  };

  return function ( iterable ) {
    return sort.call( toArray( toObject( iterable ) ), shuffle );
  };
}();

var baseMerge = function ( iterable, expander ) {
  var i = 0,
      length = expander.length;

  for ( ; i < length; ++i ) {
    if ( i in expander ) {
      push.call( iterable, expander[ i ] );
    }
  }

  return iterable;
};

var merge = function ( iterable ) {
  iterable = toObject( iterable );

  var i = 1,
      length = arguments.length,
      expander;

  for ( ; i < length; ++i ) {
    expander = arguments[ i ];

    if ( isArrayLike( expander, false, true ) ) {
      baseMerge( iterable, expander );
    } else {
      push.call( iterable, expander );
    }
  }

  return iterable;
};

var compact = function ( iterable ) {
  // return without.apply.call( without.apply, iterable, [ undefined ] );
  return without( iterable, undefined );
};

var unique = function () {
  var unique = function ( value, i, iterable ) {
    return indexOf( iterable, value ) == i;
  };

  return function ( iterable ) {
    return filter( iterable, unique );
  };
}();

var without = function ( iterable ) {
  iterable = toObject( iterable );

  var i = 0,
      length = iterable.length,
      without = slice.call( arguments, 1 ),
      temp = [],
      value;

  for ( ; i < length; ++i ) {
    value = iterable[ i ];

    if ( indexOf( without, value ) < 0 ) {
      temp.push( value );
    }
  }

  return temp;
};

var reverse = function ( iterable ) {
  return toArray( toObject( iterable ) ).reverse();
};

var baseFlatten = function ( iterable, temp, depth ) {
  var i = 0,
      length = iterable.length,
      value;

  for ( ; i < length; ++i ) {
    value = iterable[ i ];

    if ( depth > 0 && isArrayLike( value, false, true ) ) {
      baseFlatten( value, temp, depth - 1 );
    } else {
      // push.call( temp, value );
      temp.push( value );
    }
  }

  return temp;
};

var flatten = function ( iterable, depth ) {
  if ( depth === undefined ) {
    depth = Infinity;
  }

  return baseFlatten( toObject( iterable ), [], depth );
};

var zip = function () {
  var i = 0,
      length = arguments.length,
      zip = [],
      j, k, iterable;

  for ( ; i < length; ++i ) {
    j = 0;
    k = ( iterable = arguments[ i ] ).length;

    for ( ; j < k; ++j ) {
      ( zip[ j ] || ( zip[ j ] = [] ) )
        .push( iterable[ j ] );
    }
  }

  return zip;
};

var grep = function ( iterable, callback, context, not ) {
  if ( not === undefined ) {
    not = context;
    context = undefined;
  }

  return baseFilter( not, toObject( iterable ), callback, context );
};

var defineProperty = support.defineProperty === 2 ?
  Object.defineProperty :

function () {
  if ( support.defineGetter ) {
    var defineGetter = obj.__defineGetter__,
        defineSetter = obj.__sefineGetter__;
  }

  return function ( object, key, descriptor ) {
    if ( isPrimitive( object ) ) {
      throw TypeError( 'defineProperty called on non-object' );
    }

    if ( isPrimitive( descriptor ) ) {
      throw TypeError( 'Property description must be an object: ' + descriptor );
    }

    if ( support.defineProperty > 0 ) try {
      return Object.defineProperty( object, key, descriptor );
    } catch ( e ) {}

    var hasGetter = 'get' in descriptor,
        hasSetter = 'set' in descriptor,
        get = descriptor.get,
        set = descriptor.set;

    if ( hasGetter || hasSetter ) {
      if ( !isFunction( get, false ) ) {
        throw TypeError( 'Getter must be a function: ' + get );
      }

      if ( !isFunction( set, false ) ) {
        throw TypeError( 'Setter must be a function: ' + set );
      }

      if ( 'writable' in descriptor ) {
        throw TypeError( 'Invalid property descriptor. Cannot both specify accessors and a value or writable attribute, #<Object>' );
      }

      if ( support.defineGetter ) {
        if ( hasGetter ) {
          defineGetter.call( object, key, get );
        }

        if ( hasSetter ) {
          defineSetter.call( object, key, set );
        }
      }
    } else if ( 'value' in descriptor || !( key in object ) ) {
      object[ key ] = descriptor.value;
    }

    return object;
  };
}();

var defineProperties = support.defineProperty === 2 ?
  Object.defineProperties :

function ( object, descriptors ) {
  if ( isPrimitive( object ) ) {
    throw TypeError( 'defineProperties called on non-object' );
  }

  if ( isPrimitive( descriptors ) ) {
    throw TypeError( 'Property description must be an object: ' + descriptors );
  }

  if ( support.defineProperty > 0 ) try {
    return Object.defineProperties( object, descriptors );
  } catch ( e ) {}

  each( descriptors, function ( key, descriptor ) {
    defineProperty( object, key, descriptor );
  } );

  return object;
};

var createObject = Object.create || function () {
  var Constructor = function () {};

  return function ( prototype, descriptors ) {
    if ( prototype !== null && isPrimitive( prototype ) ) {
      throw TypeError( 'Object prototype may only be an Object or null: ' + prototype );
    }

    var object = ( Constructor.prototype = prototype, new Constructor() );

    Constructor.prototype = null;

    if ( prototype === null ) {
      setPrototypeOf( object, prototype );
    }

    return arguments.length > 1 ?
      defineProperties( object, descriptors ) : object;
  };
}();

var getKeys = Object.keys || function () {
  var hasEnumBug = !{ toString: null }.propertyIsEnumerable( 'toString' ),

  nonEnums = [
    'toString',
    //? 'toJSON',
    'toLocaleString',
    'valueOf',
    'hasOwnProperty',
    'isPrototypeOf',
    'propertyIsEnumerable',
    'constructor'
  ];

  return function ( target ) {
    if ( target == null ) {
      throw TypeError( ERR_NULLABLE_PASSED );
    }

    var keys = [],
        key;

    for ( key in target ) {
      if ( hasOwnProperty.call( target, key ) ) {
        keys.push( key );
      }
    }

    return hasEnumBug ?
      keys.concat( filter( nonEnums, function ( key ) {
        return indexOf( keys, key ) < 0 && hasOwnProperty.call( target, key );
      } ) ) : keys;
  };
}();

var getPrototypeOf = Object.getPrototypeOf || function ( target ) {
  if ( target == null ) {
    throw TypeError( ERR_NULLABLE_PASSED );
  }

  var prototype = target.__proto__,
      constructor;

  return prototype !== undefined ?
    prototype : isFunction( constructor = target.constructor, true ) ?
    constructor.prototype : obj;
};

var setPrototypeOf = Object.setPrototypeOf || function ( target, prototype ) {
  if ( target == null ) {
    throw TypeError( 'setPrototypeOf called on null or undefined' );
  }

  if ( prototype !== null && isPrimitive( prototype ) ) {
    throw TypeError( 'Object prototype may only be an Object or null: ' + prototype );
  }

  if ( !isPrimitive( target ) && '__proto__' in target ) {
    target.__proto__ = prototype;
  }

  return target;
};

var assign = Object.assign || function ( target ) {
  if ( target == null) {
    throw TypeError( ERR_NULLABLE_PASSED );
  }

  var i = 1,
      length = arguments.length,
      source, key;

  for ( ; i < length; ++i ) {
    source = arguments[ i ];

    if ( source != null ) {
      for ( key in source ) {
        if ( hasOwnProperty.call( source, key ) ) {
          target[ key ] = source[ key ];
        }
      }
    }
  }

  return target;
};

var getValues = Object.values || function () {
  var values = function ( key ) {
    return this[ key ];
  };

  return function ( target ) {
    return map( getKeys( target ), values, target );
  };
}();

var getEntries = Object.entries || function ( target ) {
  return zip( getKeys( target ), getValues( target ) );
};

var createTrim = function ( regexp ) {
  return function ( target ) {
    if ( target == null ) {
      throw TypeError( ERR_NULLABLE_PASSED );
    }

    return ( '' + target ).replace( regexp, '' );
  };
};

var trim = str.trim ?
  bindFast( call, str.trim ) : createTrim( /^[\s\uFEFF\xA0]+/ );

var trimStart = str.trimStart ?
  bindFast( call, str.trimStart ) : createTrim( /[\s\uFEFF\xA0]+$/ );

var trimEnd = str.trimEnd ?
  bindFast( call, str.trimEnd ) : createTrim( /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/ );

var getTime = Date.now || function () {
  return new Date().getTime();
};

var getDOMHighResTimeStamp = function () {
  var perfomance = window.perfomance || {},
      navigatorStart = ( perfomance.timing && perfomance.timing.navigatorStart ) || getTime();

  return perfomance.now || function () {
    return getTime() - navigatorStart;
  };
}();

var defaultEventProperties = [
  'altKey',
  'bubbles',
  'cancelable',
  'cancelBubble',
  'changedTouches',
  'ctrlKey',
  'currentTarget',
  'detail',
  'eventPhase',
  'metaKey',
  'pageX',
  'pageY',
  'shiftKey',
  'view',
  'char',
  'charCode',
  'key',
  'keyCode',
  'button',
  'buttons',
  'clientX',
  'clientY',
  'offsetX',
  'offsetY',
  'pointerId',
  'pointerType',
  'relatedTarget',
  'returnValue',
  'screenX',
  'screenY',
  'targetTouches',
  'toElement',
  'touches',
  'type',
  'which',
  'isTrusted'
];

var Event = function ( source, options ) {
  if ( source && source.type !== undefined ) {
    var i = defaultEventProperties.length - 1;

    for ( ; i >= 0; --i ) {
      if ( defaultEventProperties[ i ] in source ) {
        this[ defaultEventProperties[ i ] ] = source[ defaultEventProperties[ i ] ];
      }
    }

    this.originalEvent = source;

    this.target = source.target && source.target.nodeType === 3 ?
        source.target.parentNode : source.target;
  } else {
    this.type = source;
  }

  if ( options !== undefined ) {
    assign( this, options );
  }

  this.timeStamp = getDOMHighResTimeStamp();
};

Event.prototype = {
  constructor: Event,
  originalEvent: null,
  type: '',
  target: null,
  currentTarget: null,
  relatedTarget: null,
  timeStamp: 0,
  returnValue: true,
  cancelBubble: false,

  preventDefault: function () {
    var event = this.originalEvent;

    if (event) {
      if (event.preventDefault) {
        event.preventDefault();
      } else {
        event.returnValue = false;
      }
    }

    this.returnValue = event.returnValue;
  },

  stopPropagation: function () {
    var event = this.originalEvent;

    if (event) {
      if (event.stopPropagation) {
        event.stopPropagation();
      } else {
        event.cancelBubble = true;
      }
    }

    this.cancelBubble = event.cancelBubble;
  }
};

var event = new function () {
  var fixType = function ( type ) {

    // В attachEvent нет события DOMContentLoaded,
    // и type должен иметь префикс on.
    // There is no 'DOMContentLoaded' event in 'attachEvent'
    // and 'type' should have the 'on' prefix.
    return type === 'DOMContentLoaded' ?
      'onreadystatechange' : 'on' + type;
  };

  var list = createObject( null );

  var add = this.add = function ( target, type, listener, useCapture, one ) {
    var wrapper;

    if ( useCapture === undefined ) {
      useCapture = false;
    }

    if ( support.addEventListener ) {
      wrapper = one ?
        function ( event ) {
          remove( target, type, listener, useCapture );
          listener.call( target, event );
        } : listener;

      target.addEventListener( type, wrapper, useCapture );
    } else {
      if ( typeof listener != 'function' ) {
        return;
      }

      wrapper = function ( event ) {
        if ( type === 'DOMContentLoaded' && target.readyState !== 'complete' ) {
          return;
        }

        if ( one ) {
          remove( target, type, listener, useCapture );
        }

        event = new Event( event );
        event.type = type;

        if ( event.isTrusted === undefined ) {
          event.isTrusted = true;
        }

        listener.call( target, event );
      };

      target.attachEvent( fixType( type ), wrapper );
    }

    ( list[ type ] || ( list[ type ] = [] ) )
      .push( [ target, listener, useCapture, wrapper, one ] );
  };

  var remove = this.remove = function ( target, type, listener, useCapture ) {
    var i = 0,
        length, types, removeAll, filtered, item;

    if ( type === undefined ) {
      types = getKeys( list );
      i = 0;
      length = types.length;

      for ( ; i < length; ++i ) {
        if ( list[ types[ i ] ].length ) {
          remove( target, types[ i ] );
        }
      }

      return;
    }

    filtered = list[ type ];

    if ( !filtered || !filtered.length ) {
      return;
    }

    if ( useCapture === undefined ) {
      useCapture = false;
    }

    if ( !support.addEventListener ) {
      type = fixType( type );
    }

    removeAll = listener === undefined;

    // Не сохраняем свойство length,
    // потому что оно может быть изменено.
    // Don't cache the length property,
    // 'cause it can be changed.
    for ( ; i < filtered.length; ++i ) {
      item = filtered[ i ];

      if ( item[ 0 ] !== target ||
        !removeAll && ( item[ 1 ] !== listener || item[ 2 ] !== useCapture ) ) {

        continue;
      }

      filtered.splice( i--, 1 );

      if ( support.addEventListener ) {
        target.removeEventListener( type, item[ 3 ], item[ 2 ] );
      } else {
        target.detachEvent( type, item[ 3 ] );
      }/*

      if ( !filtered.length ) {
        delete list[ type ];
      }*/
    }
  };

  this.copy = function ( to, from, deep ) {
    var types = getKeys( list ),
        i = 0,
        length = types.length,
        type, filtered, item, j;

    for ( ; i < length; ++i ) {
      type = types[ i ];
      filtered = list[ type ];

      if ( !filtered || !filtered.length ) {
        continue;
      }

      for ( j = 0; j < filtered.length; ++j ) {
        item = filtered[ j ];

        if ( item[ 0 ] === from ) {
          add( to, type, item[ 1 ], item[ 2 ], item[ 4 ] );
        }
      }
    }

    return to;
  };

  this.dispatch = function ( target, type, data ) {
    var filtered = list[ type ],
        i = 0,
        item, event;

    if ( !filtered || !filtered.length ) {
      return;
    }

    for ( ; i < filtered.length; ++i ) {
      item = filtered[ i ];

      if ( item[ 0 ] !== target ) {
        continue;
      }

      event = new Event( type, data );
      event.target = target;
      event.isTrusted = false;

      item[ 3 ].call( target, event );
    }
  };
}();

/**
 * Jonathan Neal getComputedStyle() polyfill.
 * https://github.com/jonathantneal/polyfill/blob/master/polyfills/getComputedStyle/polyfill.js
 *
 * Small fixes and formatting from ScotchJS.
 */
var getComputedStyle = window.getComputedStyle || function () {
  var toDOMString = function () {
    var toDOMString = function ( l ) {
      return '-' + l.toLowerCase();
    };

    return function ( string ) {
      return string.replace( /[A-Z]/g, toDOMString );
    };
  };

  var getComputedStylePixel = function ( element, name, fontSize ) {
    // Internet Explorer sometimes struggles to read currentStyle until the element's document is accessed.
    var value = element.currentStyle[ name ].match( /([\d.]+)(em|%|cm|in|mm|pc|pt|)/ ) || [ 0, 0, '' ],
        size = value[ 1 ],
        suffix = value[ 2 ],
        rootSize, parent;

    if ( fontSize === undefined ) {
      parent = element.parentElement;

      fontSize = parent && ( suffix === '%' || suffix === 'em' ) ?
        getComputedStylePixel( parent, 'fontSize' ) : 16;
    }

    rootSize = name == 'fontSize' ?
      fontSize : /width/i.test( name ) ?
      element.clientWidth : element.clientHeight;

    return suffix === 'em' ?
      size * fontSize : suffix === '%' ?
      size / 100 * rootSize : suffix === 'cm' ?
      size * 0.3937 * 96 : suffix === 'in' ?
      size * 96 : suffix === 'mm' ?
      size * 0.3937 * 96 / 10 : suffix === 'pc' ?
      size * 12 * 96 / 72 : suffix === 'pt' ?
      size * 96 / 72 : size;
  };

  var setShortStyleProperty = function ( style, name ) {
    var borderSuffix = name == 'border' ? 'Width' : '',
        t = name + 'Top' + borderSuffix,
        r = name + 'Right' + borderSuffix,
        b = name + 'Bottom' + borderSuffix,
        l = name + 'Left' + borderSuffix;

    // style[ name ] = style[ t ] + ' ' + style[ r ] + ' ' + style[ b ] + ' ' + style[ l ];

    style[ name ] = ( style[ t ] == style[ r ] && style[ t ] == style[ b ] && style[ t ] == style[ l ] ?
      [ style[ t ] ] : style[ t ] == style[ b ] && style[ l ] == style[ r ] ?
      [ style[ t ], style[ r ] ] : style[ l ] == style[ r ] ?
      [ style[ t ], style[ r ], style[ b ] ] : [ style[ t ], style[ r ], style[ b ], style[ l ] ] ).join( ' ' );
  };

  var CSSStyleDeclaration = function ( element ) {
    var style = this,
        currentStyle = element.currentStyle,
        fontSize = getComputedStylePixel( element, 'fontSize' ),
        names = getKeys( currentStyle ),
        i = names.length,
        name;

    for ( ; i >= 0; --i ) {
      name = names[ i ];

      push.call( style, name == 'styleFloat' ?
        'float' : toDOMString( name ) );

      if ( name == 'styleFloat' ) {
        style[ 'float' ] = currentStyle[ name ];
      } else if ( name == 'width' ) {
        // clientWidth ?
        style[ name ] = element.offsetWidth + 'px';
      } else if ( name == 'height' ) {
        style[ name ] = element.offsetHeight + 'px';
      } else if ( style[ name ] != 'auto' && /(margin|padding|border).*W/.test( name ) ) {
        style[ name ] = round( getComputedStylePixel( element, name, fontSize ) ) + 'px';
      } else if ( !name.indexOf( 'outline' ) ) {
        try {
          // errors on checking outline
          style[ name ] = currentStyle[ name ];
        } catch ( e ) {
          style.outline =
            ( style.outlineColor = currentStyle.color ) + ' ' +
            ( style.outlineStyle = style.outlineStyle || 'none' ) + ' ' +
            ( style.outlineWidth = style.outlineWidth || '0px' );
        }
      } else {
        style[ name ] = currentStyle[ name ];
      }
    }

    setShortStyleProperty( style, 'margin' );
    setShortStyleProperty( style, 'padding' );
    setShortStyleProperty( style, 'border' );

    style.fontSize = round( fontSize ) + 'px';
  };

  CSSStyleDeclaration.prototype = {
    constructor: CSSStyleDeclaration,

    getPropertyValue: function ( name ) {
      return this[ toCamelCase( name ) ];
    },

    item: function ( i ) {
      return this[ i ];
    },

    getPropertyPriority: noop,
    getPropertyCSSValue: noop,
    removeProperty: noop,
    setProperty: noop
  };

  return function ( element ) {
    return new CSSStyleDeclaration( element );
  };
}();

/**
 * Based on Erik Möller requestAnimationFrame polyfill:
 *
 * Adapted from https://gist.github.com/paulirish/1579671 which derived from
 * http://paulirish.com/2011/requestanimationframe-for-smart-animating/
 * http://my.opera.com/emoller/blog/2011/12/20/requestanimationframe-for-smart-er-animating
 *
 * requestAnimationFrame polyfill by Erik Möller.
 * Fixes from Paul Irish, Tino Zijdel, Andrew Mao, Klemen Slavič, Darius Bacon.
 *
 * MIT license
 */

var requestAnimationFrame, cancelAnimationFrame;

( function () {
  var suffix = 'AnimationFrame',

  request = window[ 'request' + suffix ] ||
    window[ 'webkitRequest' + suffix ] ||
    window[ 'mozRequest' + suffix ],

  cancel = window[ 'cancel' + suffix ] ||
    window[ 'webkitCancel' + suffix ] ||
    window[ 'webkitCancelRequest' + suffix ] ||
    window[ 'mozCancel' + suffix ] ||
    window[ 'mozCancelRequest' + suffix ];

  // iOS6 is buggy
  if ( !/iP(ad|hone|od).*OS\s6/.test( window.navigator.userAgent ) && request && cancel ) {
    requestAnimationFrame = bindFast( request, window );
    cancelAnimationFrame = bindFast( cancel, window );
  } else {
    var lastTime = 0,
        frameDuration = 1000 / 60;

    requestAnimationFrame = function ( callback ) {
      var now = getTime(),
          nextTime = max( lastTime + frameDuration, now );

      return window.setTimeout( function () {
        lastTime = nextTime;

        callback();
      }, nextTime - now );
    };

    cancelAnimationFrame = window.clearTimeout;
  }
} )();

var matches = ( window.Element && (
  Element.prototype.matches ||
  Element.prototype.oMatchesSelector ||
  Element.prototype.msMatchesSelector ||
  Element.prototype.mozMatchesSelector ||
  Element.prototype.webkitMatchesSelector ) ) ||

function ( selector ) {
  if ( !isString( selector ) ) {
    throw TypeError( ERR_NOT_STRING );
  }

  var element = this,
      elements = ( element.document || element.ownerDocument ).querySelectorAll( selector ),
      i = elements.length - 1;

  for ( ; i >= 0 && elements[ i ] !== element; --i ) {}

  return i >= 0;
};

var closest = ( window.Element && Element.prototype.closest ) || function ( selector ) {
  var element = this;

  do {
    if ( matches.call( element, selector ) ) {
      return element;
    }
  } while ( ( element = element.parentElement ) );

  return null;
};

var RE_SINGLE_TAG = /^(<([\w-]+)><\/[\w-]+>|<([\w-]+)(\s*\/)?>)$/;

var parseHTML = function ( data, context ) {
  var match = RE_SINGLE_TAG.exec( data );

  if ( context === undefined ) {
    context = document;
  }

  return match ?
    [ document.createElement( match[ 2 ] || match[ 3 ] ) ] :
    toArray( createFragment( [ data ], context ).childNodes );
};

var RE_SIMPLE_SELECTOR = /^(?:#([\w-]+)|([\w-]+)|\.([\w-]+))$/;

var DOMWrapper = function ( selector ) {
  if ( !selector ) {
    return;
  }

  var i, match, list;

  if ( isSomething( selector ) ) {
    this[ 0 ] = selector;
    this.length = 1;

    return;
  } else if ( isString( selector ) ) {
    if ( selector.charAt( 0 ) == '<' ) {
      list = parseHTML( selector );
    } else if ( !( match = RE_SIMPLE_SELECTOR.exec( selector ) ) || match[ 3 ] && !support.getElementsByClassName ) {
      list = document.querySelectorAll( selector );
    } else if ( match[ 1 ] ) {
      if ( ( list = document.getElementById( match[ 1 ] ) ) ) {
        this[ 0 ] = list;
        this.length = 1;
      }

      return;
    } else if ( match[ 2 ] ) {
      list = document.getElementsByTagName( match[ 2 ] );
    } else if ( support.getElementsByClassName ) {
      list = document.getElementsByClassName( match[ 3 ] );
    }
  } else if ( isArrayLike( selector, false, true ) ) {
    list = selector;
  } else if ( isFunction( selector ) ) {
    return new DOMWrapper( document ).ready( selector );
  }

  if ( list ) {
    for ( i = ( this.length = list.length ) - 1; i >= 0; --i ) {
      this[ i ] = list[ i ];
    }
  }
};

var Scotch = function ( selector ) {
  return new DOMWrapper( selector );
};

DOMWrapper.prototype = Scotch.prototype = Scotch.fn = {
  constructor: Scotch,
  length: 0,

  get: function ( i ) {
    return i === undefined ?
      toArray( this ) : this[ i < 0 ? this.length + i : i ];
  },

  eq: function ( i ) {
    return this.pushStack(
      i === undefined ?
        this : [ this.get( i ) ]
    );
  },

  each: function ( iteratee ) {
    return each( this, iteratee );
  },

  style: function ( name, value ) {
    var addUnit = 0;

    if ( isString( name ) ) {
      name = toCamelCase( name );

      if ( !cssNumbers[ name ] ) {
        if ( typeof value == 'function' ) {
          addUnit = 1;
        } else if ( isNumber( value ) ) {
          value += 'px';
        }
      }
    } else if ( isObject( name, true ) ) {
      addUnit = 2;
    }

    return access( this, function ( element, name, value ) {
      if ( element.nodeType !== 1 ) {
        return null;
      }

      if ( value === undefined ) {
        return getStyle( element, name );
      }

      if ( ( addUnit == 2 ?
        !cssNumbers[ name = toCamelCase( name ) ] : addUnit == 1 ) && isNumber( value ) ) {

        value += 'px';
      }

      element.style[ name ] = value;
    }, name, value, arguments.length > 1, null );
  },

  addClass: function ( classes ) {
    var raw = typeof classes != 'function',
        i = this.length - 1,
        element;

    for ( ; i >= 0; --i ) {
      if ( ( element = this[ i ] ).nodeType === 1 ) {
        classList.add( element, raw ?
          classes : classes.call( element, i, element.className ) );
      }
    }

    return this;
  },

  removeClass: function ( classes ) {
    var mode = !arguments.length ?
          0 : isFunction( classes, false ) ?
          1 : 2,

        i = this.length - 1,
        element;

    for ( ; i >= 0; --i ) {
      if ( ( element = this[ i ] ).nodeType === 1 ) {
        if ( mode ) {
          classList.remove( element, mode === 1 ?
            classes.call( element, i, element.className ) : classes );
        } else {
          element.className = '';
        }
      }
    }

    return this;
  },

  toggleClass: function ( classes ) {
    var raw = typeof classes != 'function',
        i = this.length - 1,
        element;

    for ( ; i >= 0; --i ) {
      if ( ( element = this[ i ] ).nodeType === 1 ) {
        classList.toggle( element, raw ?
          classes : classes.call( element, i, element.className ) );
      }
    }

    return this;
  },

  hasClass: function ( classes ) {
    var i = this.length - 1,
        element;

    for ( ; i >= 0; --i ) {
      if ( ( element = this[ i ] ).nodeType === 1 && classList.has( element, classes ) ) {
        return true;
      }
    }

    return false;
  },

  offset: function ( options ) {
    var element, document, root, body, offset, byCallback, i, style;

    if ( !arguments.length ) {
      element = this[ 0 ];

      if ( !element || element.nodeType !== 1 ) {
        return null;
      }

      document = element.ownerDocument;
      root = document.documentElement;
      body = document.body;
      offset = element.getBoundingClientRect();

      return {
        top: offset.top +
          ( document.defaultView.pageYOffset || root.scrollTop || body.scrollTop ) -
          ( root.clientTop || body.clientTop || 0 ),

        left: offset.left +
          ( document.defaultView.pageXOffset || root.scrollLeft || body.scrollLeft ) -
          ( root.clientLeft || body.clientLeft || 0 )
      };
    }

    if ( isPrimitive( options ) ) {
      throw TypeError( ERR_INVALID_ARGS );
    }

    byCallback = isFunction( options );

    for ( i = this.length - 1; i >= 0; --i ) {
      element = this[ i ];

      if ( element.nodeType !== 1 ) {
        continue;
      }

      offset = byCallback ?
        options.call( element, i, new DOMWrapper( element ).offset() ) : options;

      style = element.style;

      style.top = offset.top + 'px';
      style.left = offset.left +'px';

      if ( getStyle( element, 'position' ) === 'static' ) {
        style.position = 'relative';
      }
    }

    return this;
  },

  is: function ( selector ) {
    var byCallback = isFunction( selector ),
        i = this.length - 1,
        element;

    for ( ; i >= 0; --i ) {
      element = this[ i ];

      if ( byCallback ?
        selector.call( element, i, element ) : is( element, selector ) ) {

        return true;
      }
    }

    return false;
  },

  closest: function ( selector ) {
    var i = 0,
        length = this.length,
        list = [],
        element, temp;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      temp = element.nodeType === 1 &&
        closest.call( element, selector );

      if ( temp && indexOf( list, temp ) < 0 ) {
        list.push( temp );
      }
    }

    return this.pushStack( list );
  },

  parent: function ( selector ) {
    var select = !!arguments.length,
        i = 0,
        length = this.length,
        list = [],
        element, parent;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      parent = element.nodeType === 1 &&
        element.parentElement;

      if ( parent && indexOf( list, parent ) < 0 && ( !select || matches.call( parent, selector ) ) ) {
        list.push( parent );
      }
    }

    return this.pushStack( list );
  },

  siblings: function ( selector ) {
    var select = !!arguments.length,
        i = 0,
        length = this.length,
        list = [],
        element, siblings, sibling, j, k;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      siblings = element.nodeType === 1 &&
        element.parentElement.children;

      if ( !siblings ) {
        continue;
      }

      for ( j = 0, k = siblings.length; j < k; ++j ) {
        sibling = siblings[ j ];

        if ( sibling !== element &&
          sibling.nodeType === 1 &&
          indexOf( list, sibling ) < 0 &&
          ( !select || matches.call( sibling, selector ) ) ) {

          list.push( sibling );
        }
      }
    }

    return this.pushStack( list );
  },

  children: function ( selector ) {
    var select = !!arguments.length,
        i = 0,
        length = this.length,
        list = [],
        element, children, child, j, k;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      children = element.nodeType === 1 &&
        element.children;

      if ( !children ) {
        continue;
      }

      for ( j = 0, k = children.length; j < k; ++j ) {
        child = children[ j ];

        if ( child.nodeType === 1 && ( !select || matches.call( child, selector ) ) ) {
          list.push( child );
        }
      }
    }

    return this.pushStack( list );
  },

  find: function ( selector ) {
    var i = 0,
        length = this.length,
        list = [],
        element, temp, j, k;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      temp = element.nodeType === 1 &&
        element.querySelectorAll( selector );

      if ( !temp ) {
        continue;
      }

      for ( j = 0, k = temp.length; j < k; ++j ) {
        element = temp[ j ];

        if ( lastIndexOf( list, element ) < 0 ) {
          list.push( element );
        }
      }
    }

    return this.pushStack( list );
  },

  not: function ( selector ) {
    var byCallback = isFunction( selector ),
        i = 0,
        length = this.length,
        list = [],
        element;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      if ( !( byCallback ? selector.call( element, i, element ) : is( element, selector ) ) ) {
        list.push( element );
      }
    }

    return this.pushStack( list );
  },

  offsetParent: function () {
    var i = 0,
        length = this.length,
        list = [],
        element, offsetParent;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      if ( element.nodeType !== 1 ) {
        continue;
      }

      offsetParent = element.offsetParent;

      while ( offsetParent && getStyle( offsetParent, 'position' ) === 'static' ) {
        offsetParent = offsetParent.offsetParent;
      }

      if ( indexOf( list, offsetParent || ( offsetParent = element.ownerDocument.documentElement ) ) < 0 ) {
        list.push( offsetParent );
      }
    }

    return this.pushStack( list );
  },

  position: function () {
    var element = this[ 0 ],
        offset, style, offsetParent, offsetParentElement, offsetParentElementStyle, parentOffset;

    if ( !element || element.nodeType !== 1 ) {
      return null;
    }

    style = getComputedStyle( element );
    parentOffset = { top: 0, left: 0 };

    if ( style.position === 'fixed' ) {
      offset = element.getBoundingClientRect();
    } else {
      offsetParent = this.offsetParent();
      offsetParentElement = offsetParent[ 0 ];

      if ( !offsetParentElement || offsetParentElement.nodeType !== 1 ) {
        return null;
      }

      offset = this.offset();

      if ( offsetParentElement.nodeName !== 'HTML' ) {
        parentOffset = offsetParent.offset();
      }

      offsetParentElementStyle = getComputedStyle( offsetParentElement );

      parentOffset.top += window.parseInt( offsetParentElementStyle.borderTopWidth, 10 );
      parentOffset.left += window.parseInt( offsetParentElementStyle.borderLeftWidth, 10 );
    }

    return {
      top: offset.top - parentOffset.top - window.parseInt( style.marginTop, 10 ),
      left: offset.left - parentOffset.left - window.parseInt( style.marginLeft, 10 )
    };
  },

  remove: function () {
    return this.each( function () {
      var nodeType = this.nodeType,
          parentNode;

      if ( (
        nodeType === 1 ||
        nodeType === 3 ||
        nodeType === 8 ||
        nodeType === 9 ||
        nodeType === 11
      ) && ( parentNode = this.parentNode ) ) {

        parentNode.removeChild( this );
        // event.remove( this );
      }
    } );
  },

  ready: function ( callback ) {
    var document = this[ 0 ],
        readyState;

    if ( !document || document.nodeType !== 9 ) {
      return this;
    }

    readyState = document.readyState;

    if ( document.attachEvent ?
      readyState === 'complete' : readyState !== 'loading' ) {

      callback( Scotch );
    } else {
      event.add( document, 'DOMContentLoaded', function () {
        callback( Scotch );
      }, false, true );
    }

    return this;
  },

  pushStack: function ( elements ) {
    var set = baseMerge( new DOMWrapper(), elements );

    set.prevObject = this;

    return set;
  },

  end: function () {
    return this.prevObject || new DOMWrapper();
  },

  filter: function ( selector ) {
    var byCallback = isFunction( selector ),
        filtered = [];

    return this.each( function ( i, element ) {
      if ( byCallback ? selector.call( element, i, element ) : is( element, selector ) ) {
        filtered.push( element );
      }
    } ).pushStack( filtered );
  },

  first: function () {
    return this.eq( 0 );
  },

  last: function () {
    return this.eq( -1 );
  },

  map: function ( callback ) {
    var i = 0,
        length = this.length,
        temp = new DOMWrapper(),
        element;

    temp.length = this.length;

    for ( ; i < length; ++i ) {
      temp[ i ] = callback.call( element = this[ i ], i, element );
    }

    return temp;
  },

  clone: function ( deep ) {
    if ( !arguments.length ) {
      deep = true;
    }

    return this.map( function ( element ) {
      return element.nodeType === 1 ?
        cloneNode( element, deep ) : element;
    } );
  },

  append: function () {
    return manipulation( this, function ( i, element, content ) {
      element.appendChild( content );
    }, arguments );
  },

  prepend: function () {
    return manipulation( this, function ( i, element, content ) {
      var firstChild = element.firstChild;

      if ( firstChild ) {
        element.insertBefore( content, firstChild );
      } else {
        element.appendChild( content );
      }
    }, arguments );
  },

  after: function () {
    return manipulation( this, function ( i, element, content ) {
      var parentNode = element.parentNode,
          nextSibling;

      if ( parentNode ) {
        nextSibling = element.nextSibling;

        if ( nextSibling ) {
          parentNode.insertBefore( content, nextSibling );
        } else {
          parentNode.appendChild( content );
        }
      }
    }, arguments );
  },

  before: function () {
    return manipulation( this, function ( i, element, content ) {
      var parentNode = element.parentNode;

      if ( parentNode ) {
        parentNode.insertBefore( content, element );
      }
    }, arguments );
  },

  slice: function ( start, end ) {
    return this.pushStack( makeSlice( this, start, end ) );
  },

  toggle: function ( state ) {
    return this.each( function () {
      if ( this.nodeType === 1 ) {
        if ( state === undefined ?
          getStyle( this, 'display' ) === 'none' : state ) {

          show.call( this );
        } else {
          hide.call( this );
        }
      }
    } );
  }
};

each( {
  value: 'value',
  text: 'textContent' in body ? 'textContent' : 'innerText',
  html: 'innerHTML'
}, function ( methodName, name ) {
  Scotch.fn[ methodName ] = function ( value ) {
    var chainable = !!arguments.length;

    return access( this, function ( element, name, value ) {
      if ( element.nodeType !== 1 ) {
        return null;
      }

      if ( chainable ) {
        element[ name ] = value;
      } else {
        return element[ name ];
      }
    }, name, value, chainable, null );
  };
} );

each( {
  on: 'add',
  one: 'add',
  off: 'remove',
  trigger: 'dispatch'
}, function ( methodName, name ) {
  var one = methodName === 'one',
      off = methodName === 'off';

  Scotch.fn[ methodName ] = function ( types, listener, useCapture ) {
    var removeAll = off && !arguments.length,
        i = this.length - 1,
        element, j, k;

    if ( !removeAll ) {
      if ( !isString( types ) ) {
        throw TypeError( ERR_NOT_STRING );
      }

      types = types.match( RE_NOT_WHITESPACES );

      if ( !types ) {
        return this;
      }

      k = types.length;
    }

    for ( ; i >= 0; --i ) {
      element = this[ i ];

      if ( removeAll ) {
        event[ name ]( element );
      } else for ( j = 0; j < k; ++j ) {
        event[ name ]( element, types[ j ], listener, useCapture, one );
      }
    }

    return this;
  };
} );

each( {
  width: 'Width',
  height: 'Height'
}, function ( methodName, name ) {
  Scotch.fn[ methodName ] = function ( value ) {
    var element, body, root;

    if ( arguments.length ) {
      return this.style( methodName, value );
    }

    element = this[ 0 ];

    if ( !element ) {
      value = null;
    } else if ( element.window === element ) {
      value = max(
        element.document.documentElement[ 'client' + name ],
        element[ 'inner' + name ] || 0
      );
    } else if ( element.nodeType === 9 ) {
      body = element.body;
      root = element.documentElement;

      value = max(
        body[ 'scroll' + name ],
        root[ 'scroll' + name ],
        body[ 'offset' + name ],
        root[ 'offset' + name ],
        body[ 'client' + name ],
        root[ 'client' + name ]
      );
    } else {
      value = element[ 'client' + name ];
    }

    return value;
  };
} );

var getWindow = function ( element ) {
  return element.window === element ?
    element : element.nodeType == 9 ?
    element.defaultView : false;
};

each( {
  scrollTop: 'pageYOffset',
  scrollLeft: 'pageXOffset'
}, function ( methodName, name ) {
  var top = methodName === 'scrollTop';

  Scotch.fn[ methodName ] = function ( value ) {
    var i, element, window;

    if ( arguments.length ) {
      for ( i = this.length - 1; i >= 0; --i ) {
        element = this[ i ];
        window = getWindow( element );

        if ( window ) {
          window.scrollTo(
            top ? window.pageXOffset || window.document.body.scrollLeft || 0 : value,
            top ? value : window.pageYOffset || window.document.body.scrollTop || 0
          );
        } else {
          element[ methodName ] = value;
        }
      }

      return this;
    }

    element = this[ 0 ];

    if ( element ) {
      window = getWindow( element );

      if ( window ) {
        value = window[ name ] || window.document.body[ methodName ] || 0;
      } else {
        value = element[ methodName ];
      }
    } else {
      value = null;
    }

    return value;
  };
} );

var hide = function () {
  if ( this.nodeType === 1 ) {
    this.style.display = 'none';
  }
};

var show = function () {
  if ( this.nodeType !== 1 ) {
    return;
  }

  var style = this.style;

  if ( style.display === 'none' ) {
    style.display = "";
  }

  if ( getComputedStyle( this ).display === 'none' ) {
    style.display = getDefaultVisibleDisplay( this );
  }
};

each( {
  hide: hide,
  show: show
}, function ( methodName, method ) {
  Scotch.fn[ methodName ] = function () {
    return this.each( method );
  };
} );

var toggle = function ( element, name, state ) {
  if ( element.nodeType === 1 ) {
    if ( state !== undefined ) {
      element[ name ] = state;
    } else {
      return element[ name ];
    }
  }

  return null;
};

forEach( [ 'checked', 'disabled' ], function ( methodName ) {
  Scotch.fn[ methodName ] = function ( state ) {
    return access( this, toggle, methodName, state, arguments.length > 0, null );
  };
});

var cloneNode = function ( element, deep ) {
  return event.copy( element.cloneNode( deep ), element, deep );
};

var wrapMap = new function () {
  var wrapMap = this;

  wrapMap.optgroup = wrapMap.option = [ 1, '<select multiple="multiple">', '</select>' ];
  wrapMap.tbody = wrapMap.tfoot = wrapMap.colgroup = wrapMap.caption = wrapMap.thead = [ 1, '<table>', '</table>' ];
  wrapMap.col = [ 2, '<table><colgroup>', '</colgroup></table>' ];
  wrapMap.tr = [ 2, '<table><tbody>', '</tbody></table>' ];
  wrapMap.th = wrapMap.td = [ 3, '<table><tbody><tr>', '</tr></tbody></table>' ];

  wrapMap.defaults = [ 0, '', '' ];
}();

var RE_HTML = /<|&#?\w+;/,
    RE_TAG_NAME = /<([a-z][^\s>]*)/;

var createFragment = function ( elements, context ) {
  var i = 0,
      length = elements.length,
      fragment = context.createDocumentFragment(),
      nodes = [],
      element, temp, tag, wrap, j;

  for ( ; i < length; ++i ) {
    if ( isObject( ( element = elements[ i ] ), false ) ) {
      baseMerge( nodes, 'nodeType' in element ? [ element ] : element );
    } else if ( !RE_HTML.test( element ) ) {
      nodes.push( context.createTextNode( element ) );
    } else {
      if ( !temp ) {
        temp = context.createElement( 'div' );
      }

      wrap = wrapMap[ ( tag = RE_TAG_NAME.exec( element ) ) ?
        tag[ 1 ].toLowerCase() : '' ] || wrapMap.defaults;

      temp.innerHTML = wrap[ 1 ] + element + wrap[ 2 ];

      for ( j = wrap[ 0 ]; j > 0; --j ) {
        temp = temp.lastChild;
      }

      baseMerge( nodes, temp.childNodes );

      temp.innerHTML = '';
    }
  }

  for ( i = 0, length = nodes.length; i < length; ++i ) {
    fragment.appendChild( nodes[ i ] );
  }

  return fragment;
};

var manipulation = function ( collection, callback, args ) {
  args = concat.apply( [], args );

  var i = 0,
      length = collection.length,
      last = length - 1,
      fragment, element, context;

  if ( length ) {
    if ( typeof args[ 0 ] == 'function' ) {
      for ( ; i < length; ++i ) {
        element = collection[ i ];

        manipulation( new DOMWrapper( element ), callback, [
          args[ 0 ].call( element, i, element )
        ] );
      }
    } else if ( ( context = collection[ 0 ].ownerDocument ) ) {
      fragment = createFragment( args, context );

      for ( ; i < length; ++i ) {
        element = collection[ i ];

        callback.call( element, i, element, i == last ?
          fragment : cloneNode( fragment, true ) );
      }
    }
  }

  return collection;
};

// Получается, что почти то же самое. Прости, Джон.
// It turns out that almost the same thing. I'm sorry, John.
var access = function ( collection, callback, key, value, chainable, empty, raw ) {
  var bulk = key == null,
      i = 0,
      length = collection.length,
      element;

  if ( !bulk && getType( key ) == 'object' ) {
    chainable = true;

    each( key, function ( name ) {
      access( collection, callback, name, key[ name ], chainable, empty, raw );
    } );
  } else if ( value !== undefined ) {
    chainable = true;

    if ( typeof value != 'function' ) {
      raw = true;
    }

    if ( bulk ) {
      if ( raw ) {
        callback.call( collection, value );
        callback = null;
      } else {
        bulk = callback;

        callback = function ( element, key, value ) {
          return bulk.call( new DOMWrapper( element ), value );
        };
      }
    }

    if ( callback ) {
      for ( ; i < length; ++i ) {
        callback( ( element = collection[ i ] ), key, raw ?
          value : value.call( element, i, callback( element, key ) ) );
      }
    }
  }

  return chainable ?
    collection : bulk ?
    callback.call( collection ) : length ?
    callback( collection[ 0 ], key ) : empty;
};

var toCamelCase = function () {
  var toCamelCase = function ( a ) {
    return a.charAt( 1 ).toUpperCase();
  };

  return function ( string ) {
    return ~string.indexOf( '-' ) ?
      string.replace( /-\w/g, toCamelCase ) : string;
  };
}();

// jQuery 3.2.1
var cssNumbers = {
  "animationIterationCount": true,
  "columnCount": true,
  "fillOpacity": true,
  "flexGrow": true,
  "flexShrink": true,
  "fontWeight": true,
  "lineHeight": true,
  "opacity": true,
  "order": true,
  "orphans": true,
  "widows": true,
  "zIndex": true,
  "zoom": true
};

var is = function ( element, selector ) {
  if ( selector instanceof DOMWrapper ) {
    var i = selector.length - 1;

    for ( ; i >= 0; --i ) {
      if ( element === selector[ i ] ) {
        return true;
      }
    }

    return false;
  } else if ( isString( selector ) ) {
    return element.nodeType === 1 && matches.call( element, selector );
  } else {
    return element === selector;
  }
};

var defaultStyleMap = {};

var getDefaultStyle = function ( target ) {
  var document, element,
      nodeName = target.nodeName,
      defaultStyle = defaultStyleMap[ nodeName ];

  if ( defaultStyle ) {
    return defaultStyle;
  }

  document = target.ownerDocument;

  element = document.body.appendChild(
    document.createElement( nodeName )
  );

  defaultStyle = defaultStyleMap[ nodeName ] =

    // Используем clone потому что после удаления
    // элемента стили становятся пустыми.
    // Use "clone" 'cause after removing
    // an element, the styles become empty.
    makeClone( false, getComputedStyle( element ) );

  element.parentNode.removeChild( element );

  return defaultStyle;
};

var defaultVisibleDisplayMap = {};

var getDefaultVisibleDisplay = function ( target ) {
  var nodeName = target.nodeName,
      display = defaultVisibleDisplayMap[ nodeName ];

  if ( display ) {
    return display;
  }

  display = getDefaultStyle( target ).display;

  return ( defaultVisibleDisplayMap[ nodeName ] = display === 'none' ?
    'block' : display );
};

var propNames = {
  'for': 'htmlFor',
  'class': 'className'
};

var attr = function ( element, name, value ) {
  if ( element.nodeType !== 1 ) {
    return null;
  }

  if ( propNames[ name ] || !support.getAttribute ) {
    return prop( element, propNames[ name ] || name, value );
  }

  if ( value === undefined ) {
    return element.getAttribute( name );
  }

  element.setAttribute( name, value );
};

var prop = function ( element, name, value ) {
  if ( value === undefined ) {
    return element[ name ];
  }

  element[ name ] = value;
};

var removeAttr = function ( element, names ) {
  if ( element.nodeType !== 1 ) {
    return;
  }

  names = listByWhitespaces( names );

  for ( var i = names.length - 1; i >= 0; --i ) {
    if ( support.getAttribute ) {
      element.removeAttribute( names[ i ] );
    } else {
      delete element[ propNames[ names[ i ] ] || names[ i ] ];
    }
  }
};

var removeProp = function ( element, names ) {
  var i = ( names = listByWhitespaces( names ) ).length - 1;

  for ( ; i >= 0; --i ) {
    delete element[ names[ i ] ];
  }
};

each( {
  attr: attr,
  prop: prop
}, function ( methodName, method ) {
  Scotch.fn[ methodName ] = function ( name, value ) {
    return access( this, method, name, value, arguments.length > 1, null );
  };
} );

each( {
  removeAttr: removeAttr,
  removeProp: removeProp
}, function ( methodName, remove ) {
  Scotch.fn[ methodName ] = function ( names ) {
    return this.each( function () {
      remove( this, names );
    } );
  };
} );

var getStyle = function ( element, name ) {
  return element.style[ name ] ||
    getComputedStyle( element ).getPropertyValue( name );
};

var listByWhitespaces = function ( string ) {
  if ( !isString( string ) ) {
    throw TypeError( ERR_NOT_STRING );
  }

  return string.match( RE_NOT_WHITESPACES ) || [];
};

var classList = {
  add: function ( element, classes ) {
    if ( !( classes = listByWhitespaces( classes ) ).length ) {
      return;
    }

    var i = 0,
        length = classes.length,
        className = ' ' + this.get( element ) + ' ',
        value;

    for ( ; i < length; ++i ) {
      value = classes[ i ] + ' ';

      if ( className.indexOf( ' ' + value ) < 0 ) {
        className += value;
      }
    }

    element.className = trim( className );
  },

  remove: function ( element, classes ) {
    if ( !( classes = listByWhitespaces( classes ) ).length ) {
      return;
    }

    var i = classes.length - 1,
        className = ' ' + this.get( element ) + ' ',
        value;

    for ( ; i >= 0; --i ) {
      value = ' ' + classes[ i ] + ' ';

      while ( ~className.indexOf( value ) ) {
        className = className.replace( value, ' ' );
      }
    }

    element.className = trim( className );
  },

  toggle: function ( element, classes ) {
    if ( !( classes = listByWhitespaces( classes ) ).length ) {
      return;
    }

    var i = 0,
        length = classes.length,
        className = ' ' + this.get( element ) + ' ',
        value;

    for ( ; i < length; ++i ) {
      value = ' ' + classes[ i ] + ' ';

      this[ ~className.indexOf( value ) ?
        'remove' : 'add' ]( element, value );
    }
  },

  has: function ( element, classes ) {
    if ( !( classes = listByWhitespaces( classes ) ).length ) {
      return false;
    }

    var i = classes.length - 1,
        className = ' ' + this.get( element ) + ' ';

    for ( ; i >= 0; --i ) {
      if ( className.indexOf( ' ' + classes[ i ] + ' ' ) < 0 ) {
        return false;
      }
    }

    return true;
  },

  get: function ( element ) {
    var className = element.className,
        match;

    return className.length && ( match = className.match( RE_NOT_WHITESPACES ) ) ?
      match.length > 1 ?
        match.join( ' ' ) : match[ 0 ] : '';
  }
};

/**
 * Based on Taylor Hakes Promise() polyfill.
 * https://github.com/taylorhakes/promise-polyfill
 */
var Promise = window.Promise || function () {
  var Promise = function ( executor ) {
    if ( !isObject( this, false ) || !( this instanceof Promise ) ) {
      throw TypeError( this + ' is not a promise' );
    }

    if ( typeof executor != 'function' ) {
      throw TypeError( 'Promise resolver ' + executor + ' is not a function' );
    }

    execute( executor, addWrapper( this ) );
  };

  Promise.prototype = {
    constructor: Promise,

    then: function ( onFulfilled, onRejected ) {
      var promise = new this.constructor( noop );

      handle( getWrapper( this ), new Deferred( onFulfilled, onRejected, getWrapper( promise ) ) );

      return promise;
    },

    'catch': function ( onRejected ) {
      return this.then( null, onRejected );
    }
  };

  mixin( Promise, {
    all: function ( iterable ) {
      var args = slice.call( iterable ),
          remaining = args.length;

      return new Promise( function ( resolve, reject ) {
        if ( !remaining ) {
          return resolve( args );
        }

        var res = function ( value, args ) {
          try {
            if ( isPrimitive( value ) || typeof value.then != 'function' ) {
              if ( !--remaining ) {
                resolve( args );
              }
            } else {
              value.then( function ( value ) {
                res( value, args );
              }, reject );
            }
          } catch ( error ) {
            reject( error );
          }
        };

        var i = 0,
            length = remaining;

        for ( ; i < length; ++i ) {
          res( args[ i ], args );
        }
      } );
    },

    resolve: function ( value ) {
      return isObject( value, false ) && value instanceof Promise ?
        value : new Promise( function ( resolve ) {
          resolve( value );
        } );
    },

    reject: function ( value ) {
      return new Promise( function ( resolve, reject ) {
        reject( value );
      } );
    },

    race: function ( values ) {
      return new Promise( function ( resolve, reject ) {
        var i = 0,
            length = values.length;
  
        for ( ; i < length; ++i ) {
          values[ i ].then( resolve, reject );
        }
      } );
    }
  } );

  var Wrapper = function ( promise ) {
    this.promise = promise;
    this.deferreds = [];
  };

  Wrapper.prototype = {
    constructor: Wrapper,
    state: 0,
    isHandled: false,
    value: undefined
  };

  var Deferred = function ( onFulfilled, onRejected, promise ) {
    if ( typeof onFulfilled == 'function' ) {
      this.onFulfilled = onFulfilled;
    }

    if ( typeof onRejected == 'function' ) {
      this.onRejected = onRejected;
    }

    this.promise = promise;
  };

  Deferred.prototype = {
    constructor: Deferred,
    onFulfilled: null,
    onRejected: null
  };

  // Memory leak?
  var promises = [],
      wrappers = [];

  var addWrapper = function ( promise ) {
    var wrapper = promise;

    if ( !( wrapper instanceof Wrapper ) && !getWrapper( promise ) ) {
      promises.push( promise );
      wrappers.push( wrapper = new Wrapper( wrapper ) );
    }
  
    return wrapper;
  };

  var getWrapper = function ( promise ) {
    return ~( promise = indexOf( promises, promise ) ) ?
      wrappers[ promise ] : null;
  };

  var execute = function ( executor, wrapper ) {
    var done = false;

    try {
      executor( function ( value ) {
        if ( !done ) {
          done = true, resolve( wrapper, value );
        }
      }, function ( reason ) {
        if ( !done ) {
          done = true, reject( wrapper, reason );
        }
      } );
    } catch ( error ) {
      if ( !done ) {
        done = true, reject( wrapper, error );
      }
    }
  };

  var resolve = function ( wrapper, value ) {
    try {
      if ( value === wrapper.promise ) {
        throw TypeError( 'A promise can\'t be resolved with itself' );
      }

      if ( isPrimitive( value ) ) {
        wrapper.state = 1;
        wrapper.value = value;

        finale( wrapper );
      } else if ( value instanceof Promise ) {
        wrapper.state = 3;
        wrapper.value = getWrapper( value );

        finale( wrapper );
      } else if ( typeof value.then == 'function' ) {
        execute( function ( resolve, reject ) {
          value.then( resolve, reject );
        }, wrapper );
      }
    } catch ( error ) {
      reject( wrapper, error );
    }
  };

  var reject = function ( wrapper, value ) {
    wrapper.state = 2;
    wrapper.value = value;

    finale( wrapper );
  };

  var finale = function ( wrapper ) {
    if ( wrapper.state === 2 && !wrapper.deferreds.length ) {
      setImmediate( function () {
        if ( !wrapper.isHandled ) {
          unhandledRejection( wrapper.value );
        }
      } );
    }

    var i = 0,
        length = wrapper.deferreds.length;

    for ( ; i < length; ++i ) {
      handle( wrapper, wrapper.deferreds[ i ] );
    }

    delete wrapper.deferreds;
  };

  var handle = function ( wrapper, deferred ) {
    while ( wrapper.state === 3 ) {
      wrapper = wrapper.value;
    }

    if ( wrapper.state === 0 ) {
      wrapper.deferreds.push( deferred );

      return;
    }

    wrapper.isHandled = true;

    setImmediate( function () {
      var temp,
          containsValue = wrapper.state === 1,

      callback = containsValue ?
        deferred.onFulfilled : deferred.onRejected;

      if ( !callback ) {
        ( containsValue ?
          resolve : reject )( deferred.promise, wrapper.value );

        return;
      }

      try {
        temp = callback( wrapper.value );
      } catch ( error ) {
        reject( deferred.promise, error );

        return;
      }

      resolve( deferred.promise, temp );
    } );
  };

  var setImmediate = window.setImmediate || function ( callback ) {
    window.setTimeout( callback, 0 );
  };

  var unhandledRejection = function ( error ) {
    if ( window.console && typeof window.console.warn == 'function' ) {
      window.console.warn( 'Possible Unhandled Promise Rejection: ', error );
    }
  };

  return Promise;
}();

forEachRight( ( 'blur focus focusin focusout resize scroll click' +
  ' dblclick mousedown mouseup mousemove mouseover mouseout' +
  ' mouseenter mouseleave change select submit keydown keypress' +
  ' keyup contextmenu touchstart touchmove touchend touchstop' ).split( ' ' ),

function ( type ) {
  this[ type ] = function ( argument ) {
    return this[ isFunction( argument, false ) ? 'on' : 'trigger' ]( type, argument, false );
  };
}, Scotch.fn );

window.Scotch = window._ = mixin( Scotch, {
  DOMWrapper: DOMWrapper,
  Promise: Promise,
  Event: Event,
  cssNumbers: cssNumbers,
  propNames: propNames,
  classList: classList,
  support: support,
  event: event,
  noop: noop,
  isNumber: isNumber,
  isString: isString,
  isBoolean: isBoolean,
  isUndefined: isUndefined,
  isFunction: isFunction,
  isObject: isObject,
  isPrimitive: isPrimitive,
  isNaN: isNaN,
  isFinite: isFinite,
  isSafeInteger: isSafeInteger,
  isArray: isArray,
  isArrayLike: isArrayLike,
  isHTMLElement: isHTMLElement,
  isPlainObject: isPlainObject,
  isWindow: isWindow,
  isSomething: isSomething,
  type: getType,
  __type: getTypeCached,
  noConflict: noConflict,
  clone: makeClone,
  mixin: mixin,
  clamp: clamp,
  toArray: toArray,
  random: random,
  findValue: findValue,
  times: times,
  each: each,
  invert: invert,
  bindFast: bindFast,
  fill: fill,
  size: getSize,
  getFileSize: getFileSize,
  getFile: getFile,
  toObject: toObject,
  bind: bind,
  slice: makeSlice,
  range: range,
  rangeRight: rangeRight,
  find: find,
  findLast: findLast,
  findIndex: findIndex,
  findLastIndex: findLastIndex,
  indexOf: indexOf,
  lastIndexOf: lastIndexOf,
  some: some,
  every: every,
  forEach: forEach,
  forEachRight: forEachRight,
  map: map,
  filter: filter,
  reduce: reduce,
  reduceRight: reduceRight,
  shuffle: shuffle,
  merge: merge,
  compact: compact,
  unique: unique,
  without: without,
  reverse: reverse,
  flatten: flatten,
  zip: zip,
  grep: grep,
  defineProperty: defineProperty,
  defineProperties: defineProperties,
  create: createObject,
  keys: getKeys,
  getPrototypeOf: getPrototypeOf,
  setPrototypeOf: setPrototypeOf,
  assign: assign,
  values: getValues,
  entries: getEntries,
  trim: trim,
  trimStart: trimStart,
  trimEnd: trimEnd,
  now: getTime,
  getDOMHighResTimeStamp: getDOMHighResTimeStamp,
  requestAnimationFrame: requestAnimationFrame,
  cancelAnimationFrame: cancelAnimationFrame,
  parseHTML: parseHTML,
  listByWhitespaces: listByWhitespaces,
  getComputedStyle: getComputedStyle,
  getStyle: getStyle
} );

} )( window );