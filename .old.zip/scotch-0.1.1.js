/**
 * ScotchJS (c) 2017 SILENT.
 * Released under the MIT License.
 */
;( function ( window, undefined ) {

'use strict';

var document = window.document,
    console = window.console,
    body = document.body || document.createElement( 'body' ),
    obj = Object.prototype,
    str = String.prototype,
    arr = Array.prototype,
    fn = Function.prototype,
    hasOwnProperty = obj.hasOwnProperty,
    toString = obj.toString,
    concat = arr.concat,
    slice = arr.slice,
    push = arr.push,
    call = fn.call,
    floor = Math.floor,
    round = Math.round,
    rand = Math.random,
    ceil = Math.ceil,
    max = Math.max,
    min = Math.min,
    power = Math.pow,
    RE_NOT_WHITESPACES = /[^\s\uFEFF\xA0]+/g,
    RE_PROPERTY = /(^|\.)\s*([_a-z]\w*)\s*|\[\s*(\d+|\d*\.\d+|"(([^\\]\\(\\\\)*"|[^"])*)"|'(([^\\]\\(\\\\)*'|[^'])*)')\s*\]/gi,
    RE_DEEP_KEY = /(^|[^\\])(\\\\)*(\.|\[)/,
    ERR_INVALID_ARGS = 'Invalid arguments',
    ERR_FUNCTION_EXPECTED = 'Expected a function',
    ERR_STRING_EXPECTED = 'Expected a string',
    ERR_UNDEFINED_OR_NULL = 'Cannot convert undefined or null to object',
    ERR_REDUCE_OF_EMPTY_ARRAY = 'Reduce of empty array with no initial value',
    ERR_INVALID_PROPERTY_DESCRIPTOR = 'Invalid property descriptor. Cannot both specify accessors and a value or writable attribute, #<Object>';

var support = {
  HTMLElement: toString.call( body ).indexOf( 'HTML' ) > 0,
  getElementsByClassName: !!document.getElementsByClassName,
  addEventListener: !!window.addEventListener,
  defineGetter: !!obj.__defineGetter__,

  defineProperty: function () {
    var test = function ( target ) {
      try {
        if ( '' in Object.defineProperty( target, '', {} ) ) {
          return 1;
        }
      } catch ( e ) {}

      return 0;
    };

    return test( document.createElement( 'span' ) ) + test( {} );
  }(),

  getAttribute: function () {
    var temp = document.createElement( 'span' ),
        name = 'name';

    try {
      return temp.setAttribute( name, name ),
        temp.getAttribute( name ) === name;
    } catch ( e ) {}

    return false;
  }()
};

var cached = function ( getOutput, lastInput, lastOutput ) {
  return function ( input ) {
    return input === lastInput ?
      lastOutput : ( lastOutput = getOutput( lastInput = input ) );
  };
};

var bindFast = function ( target, context ) {
  if ( !isFunction( target ) ) {
    throw TypeError( ERR_FUNCTION_EXPECTED );
  }

  return function ( a, b, c, d, e, f, g, h ) {
    switch ( arguments.length ) {
      case 0: return target.call( context );
      case 1: return target.call( context, a );
      case 2: return target.call( context, a, b );
      case 3: return target.call( context, a, b, c );
      case 4: return target.call( context, a, b, c, d );
      case 5: return target.call( context, a, b, c, d, e );
      case 6: return target.call( context, a, b, c, d, e, f );
      case 7: return target.call( context, a, b, c, d, e, f, g );
      case 8: return target.call( context, a, b, c, d, e, f, g, h );
    }

    return target.apply( context, arguments );
  };
};

/** 'is' methods */

var isArray = Array.isArray || function ( value ) {
  return isObject( value ) &&
    isLength( value.length ) &&
    toString.call( value ) == '[object Array]';
};

var isArrayLike = function ( value, string, guard ) {
  return ( !guard && !!string && typeof value == 'string' ) ||
    isObject( value ) && isLength( value.length ) && !isWindow( value );
};

var isBoolean = function ( value ) {
  return value ?
    value === true || typeof value == 'object' && toString.call( value ) == '[object Boolean]' :
    value === false;
};

var isFinite = function ( value ) {
  return isNumber( value ) && window.isFinite( value );
};

var isFunction = function ( value, byType, guard ) {
  return !!value &&
    typeof value == 'function' &&
    ( !!guard || !byType || toString.call( value ) == '[object Function]' );
};

var isHTMLElement = function ( value, partial, guard ) {

  if ( !isObject( value, !support.HTMLElement ) || value.nodeType !== 1 ) {
    return false;
  }

  if ( partial && !guard ) {
    return typeof value.nodeName == 'string';
  }

  if ( support.HTMLElement ) {
    return /\[object HTML\w*Element\]/.test( toString.call( value ) );
  }

  return typeof ( value = value.nodeName ) == 'string' &&
    /^[A-Z]+$/.test( value );

};

var isIndex = function ( value, length, guard ) {
  if ( guard || length === undefined ) {
    length = MAX_SAFE_INT;
  }

  return !!length &&
    typeof value == 'number' &&
    value > -1 &&
    value < length &&
    value % 1 == 0;
};

var MAX_ARRAY_LENGTH = 4294967295;

var isLength = function ( value ) {
  return typeof value == 'number' &&
    value >= 0 &&
    value <= MAX_ARRAY_LENGTH &&
    value % 1 == 0;
};

var isNaN = function ( value ) {
  return isNumber( value ) && value != +value;
};

var isNumber = function ( value ) {
  return value != null && (
    typeof value == 'number' ||
    typeof value == 'object' &&
    toString.call( value ) == '[object Number]'
  );
};

var isObject = function ( value, byType, guard ) {
  return !!value &&
    typeof value == 'object' &&
    ( !!guard || !byType || toString.call( value ) == '[object Object]' );
};

var fnToString = fn.toString,
    fnObject = fnToString.call( Object );

var isPlainObject = function ( value ) {
  if ( getType( value ) != 'object' ) {
    return false;
  }

  var prototype = getPrototypeOf( value );

  return prototype === null ||
    hasOwnProperty.call( prototype, 'constructor' ) &&
    fnToString.call( prototype.constructor ) == fnObject; // Weird statement
};

var isPrimitive = function ( value ) {

  if ( !value ) {
    return true;
  }

  var type = typeof value;

  return type != 'object' && type != 'function';

};

var MAX_SAFE_INT = 9007199254740991,
    MIN_SAFE_INT = -MAX_SAFE_INT;

var isSafeInteger = function ( value ) {
  return isFinite( value ) &&
    value <= MAX_SAFE_INT &&
    value >= MIN_SAFE_INT &&
    value % 1 == 0;
};

var isSomething = function ( value ) {
  if ( !isObject( value ) ) {
    return false;
  }

  if ( isWindow( value ) ) {
    return true;
  }

  var nodeType = value.nodeType;

  return nodeType === 1 || // ELEMENT_NODE
    nodeType === 3 || // TEXT_NODE
    nodeType === 8 || // COMMENT_NODE
    nodeType === 9 || // DOCUMENT_NODE
    nodeType === 11; // DOCUMENT_FRAGMENT_NODE
};

var isString = function ( value ) {
  return value != null && (
    typeof value == 'string' ||
    typeof value == 'object' &&
    toString.call( value ) == '[object String]'
  );
};

var isSymbol = function ( value ) {
  return !!value && (
    typeof value == 'symbol' ||
    typeof value == 'object' &&
    toString.call( value ) == '[object Symbol]'
  );
};

var isUndefined = function ( value ) {
  return value === undefined;
};

var isWindow = function ( value, byType, guard ) {
  return isObject( value ) &&
    value.window === value &&
    ( !!guard || !byType || toString.call( value ) == '[object Window]' );
};

/** private 'base' methods */

var baseAssign = function ( object, expander, keys ) {
  var i = 0,
      length = keys.length;

  for ( ; i < length; ++i ) {
    object[ keys[ i ] ] = expander[ keys[ i ] ];
  }

  return object;
};

var baseBind = fn.bind ?
  bindFast( call, fn.bind ) :

function ( target, context ) {
  var partials = arguments.length > 2 &&
    slice.call( arguments, 2 );

  return function () {
    return apply( target, context, partials ? partials.concat( slice.call( arguments ) ) : arguments );
  };
};

var baseCloneArray = function ( iterable ) {
  var i = iterable.length,
      clone = Array( i-- );

  for ( ; i >= 0; --i ) {
    if ( has( i, iterable ) ) {
      clone[ i ] = iterable[ i ];
    }
  }

  return clone;
};

if ( support.defineGetter ) {
  // OUT OF SCOPE!!
  var defineGetter = obj.__defineGetter__,
      defineSetter = obj.__defineSetter__;
}

var baseDefineProperty = function ( object, key, descriptor ) {
  var hasGetter = has( 'get', descriptor ),
      hasSetter = has( 'set', descriptor ),
      get = hasGetter && descriptor.get,
      set = hasSetter && descriptor.set;

  if ( hasGetter || hasSetter ) {
    if ( !isFunction( get, false ) ) {
      throw TypeError( 'Getter must be a function: ' + get );
    }

    if ( !isFunction( set, false ) ) {
      throw TypeError( 'Setter must be a function: ' + set );
    }

    if ( has( 'writable', descriptor ) ) {
      throw TypeError( ERR_INVALID_PROPERTY_DESCRIPTOR );
    }

    if ( support.defineGetter ) {
      if ( hasGetter ) {
        defineGetter.call( object, key, get );
      }

      if ( hasSetter ) {
        defineSetter.call( object, key, set );
      }
    }
  } else if ( has( 'value', descriptor ) || !has( key, object ) ) {
    object[ key ] = descriptor.value;
  }

  return object;
};

var baseFilter = function ( not, iterable, iteratee, context ) {
  var i = 0,
      length = getLength( iterable ),
      filtered = [],
      value;

  for ( ; i < length; ++i ) {
    value = iterable[ i ];

    if ( has( i, iterable ) && iteratee.call( context, value, i, iterable ) != not ) {
      filtered.push( value );
    }
  }

  return filtered;
};

var baseFlatten = function ( iterable, temp, depth ) {
  var i = 0,
      length = iterable.length,
      value;

  for ( ; i < length; ++i ) {
    if ( !has( i, iterable ) ) {
      continue;
    }

    value = iterable[ i ];

    if ( depth > 0 && isArrayLike( value ) ) {
      baseFlatten( value, temp, depth - 1 );
    } else {
      temp.push( value );
    }
  }

  return temp;
};

var baseForEach = function ( iterable, iteratee, context, fromRight ) {
  var i = -1,
      j = getLength( iterable ) + i,
      index;

  for ( ; j >= 0; --j ) {
    index = fromRight ? j : ++i;

    if ( has( index, iterable ) && iteratee.call( context, iterable[ index ], index, iterable ) === false ) {
      break;
    }
  }

  return iterable;
};

var baseForIn = function ( object, iteratee, context, keys, fromRight ) {
  var i = -1,
      j = keys.length + i,
      key;

  for ( ; j >= 0; --j ) {
    key = keys[ fromRight ? j : ++i ];

    if ( iteratee.call( context, object[ key ], key, object ) === false ) {
      break;
    }
  }

  return object;
};

var baseAccessProp = function ( object, path, value, set ) {
  var i = 0,
      length = path.length,
      key, haspath;

  for ( ; i < length; ++i ) {
    // Думаю перед baseAccessProp прогонять path
    // через toKey, чтобы при частом вызове
    // baseAccessProp не надо было вызывать toKey.
    // key = path[ i ];
    key = toKey( path[ i ] );
    haspath = has( key, object );

    if ( set ) {
      object = i === length - 1 ?
        object[ key ] = value : haspath ?
        object[ key ] : object[ key ] = {};
    } else {
      if ( !haspath ) {
        return;
      }

      object = object[ key ];
    }
  }

  return object;
};

var baseIndexOf = function ( iterable, search, fromIndex, fromRight ) {
  var length = getLength( iterable ),
      i = -1,
      j = length + i,
      index, value;

  if ( !length ) {
    return j;
  }

  if ( fromIndex !== undefined ) {
    fromIndex = baseToIndex( fromIndex, length );

    i += j = fromRight ?
      min( j, fromIndex ) : max( 0, fromIndex );
  }

  for ( ; j >= 0; --j ) {
    index = fromRight ? j : ++i;
    value = iterable[ index ];

    if ( value === search ? has( index, iterable ) : value !== value && search !== search ) {
      return index;
    }
  }

  return -1;
};

var baseInvert = function ( object ) {
  var inverted = {};

  baseForIn( true, object, function ( value, key ) {
    this[ value ] = key;
  }, inverted, getKeys( object ) );

  return inverted;
};

var baseKeys = function () {
  var hasEnumBug = !{ toString: null }.propertyIsEnumerable( 'toString' ),
      nonEnums;

  if ( hasEnumBug ) {
    nonEnums = [
      'toString',
      'toLocaleString',
      'valueOf',
      'hasOwnProperty',
      'isPrototypeOf',
      'propertyIsEnumerable',
      'constructor'
    ];
  }

  return function ( object ) {
    var keys = [],
        key;

    for ( key in object ) {
      if ( hasOwnProperty.call( object, key ) ) {
        keys.push( key );
      }
    }

    return hasEnumBug ?
      keys.concat(
        filter( nonEnums, function ( key ) {
          return indexOf( keys, key ) < 0 &&
            hasOwnProperty.call( this, key );
        }, object )
      ) : keys;
  };
}();

var baseMap = function ( iterable, iteratee, context, fromRight ) {
  var length = getLength( iterable ),
      mapped = Array( length ),
      j = length,
      i = 0;

  for ( ; i < length; ++i ) {
    if ( has( i, iterable ) ) {
      mapped[ fromRight ? --j : i ] = iteratee.call( context, iterable[ i ], i, iterable );
    }
  }

  return mapped;
};

var baseMerge = function ( iterable, expander ) {
  var i = 0,
      length = expander.length;

  for ( ; i < length; ++i ) {
    if ( has( i, expander ) ) {
      push.call( iterable, expander[ i ] );
    }
  }

  return iterable;
};

var baseMethod = function ( key, args ) {
  return function ( object ) {
    return object == null ? undefined : apply( object[ key ], object, args );
  };
};

var baseMethodDeep = function ( path, args ) {
  var key = toKey( last( path ) );

  return function ( object ) {
    object = parent( object, path );
    return object == null ? undefined : apply( object[ key ], object, args );
  };
};

var baseProp = function ( key, value, set ) {
  return function ( object ) {
    if ( object == null ) {
      if ( !set ) {
        return;
      }

      object = {};
    }

    return set ? object[ key ] = value : object[ key ];
  };
};

var basePropDeep = function ( path, value, set ) {
  return function ( object ) {
    if ( object == null ) {
      if ( !set ) {
        return;
      }

      object = {};
    }

    return baseAccessProp( object, path, value, set );
  };
};

var baseRandom = function ( floating, lower, upper ) {
  var random = lower + rand() * ( upper - lower );
  return floating ? random : round( random );
};

var baseRange = function ( reverse, start, end, step ) {
  var i = -1,
      j = ceil( ( end - start ) / step ),
      temp = Array( j-- );

  for ( ; j >= 0; --j ) {
    temp[ reverse ? j : ++i ] = start;
    start += step;
  }

  return temp;
};

var baseSample = function ( iterable ) {
  var length = getLength( iterable );

  if ( length ) {
    return iterable[ length === 1 ? 0 : baseRandom( false, 0, length - 1 ) ];
  }
};

var baseShuffle = function ( iterable, size ) {
  var i = 0,
      length = getLength( iterable ),
      last = length - 1,
      shuffled;

  if ( size === undefined ) {
    size = length;
  }

  shuffled = Array( size );

  for ( ; i < size; ++i ) {
    shuffled[ i ] = iterable[ baseRandom( false, i, last ) ];
  }

  return shuffled;
};

var baseTimes = function ( times, callback ) {
  var i = 0,
      results = Array( times );

  for ( ; i < times; ++i ) {
    results[ i ] = callback( i );
  }

  return results;
};

var baseToIndex = function ( value, length ) {
  if ( !length || !value || !( value = floor( value ) ) ) {
    return 0;
  }

  if ( value < 0 ) {
    value += length;
  }

  return value || 0;
};

var baseToPairs = function ( object, keys ) {
  var i = keys.length,
      pairs = Array( i-- );

  for ( ; i >= 0; --i ) {
    pairs[ i ] = [ keys[ i ], object[ keys[ i ] ] ];
  }

  return pairs;
};

var baseValues = function ( object, keys ) {
  var i = keys.length,
      values = Array( i-- );

  for ( ; i >= 0; --i ) {
    values[ i ] = object[ keys[ i ] ];
  }

  return values;
};

/** private 'create' methods */

var createAssign = function ( getKeys ) {
  return function ( object ) {
    if ( object == null ) {
      if ( strict ) {
        throw TypeError( ERR_UNDEFINED_OR_NULL );
      }

      object = {};
    }

    var i = 1,
        length = arguments.length,
        expander;

    for ( ; i < length; ++i ) {
      expander = arguments[ i ];

      if ( expander != null ) {
        baseAssign( object, expander, getKeys( expander ) );
      }
    }

    return object;
  };
};

var createDeepFind = function ( by, each ) {
  return function find ( object, search ) {
    var returnValue = [ false ];

    each( object, function ( value, key ) {
      if ( by ? search( value, key, this ) : key === search ) {
        return ( returnValue = [ true, value ] ), false;
      }

      if ( value !== this && !isPrimitive( value ) ) {
        value = find( value, search );

        if ( value[ 0 ] ) {
          return ( returnValue = value ), false;
        }
      }
    }, object );

    return returnValue;
  };
};

var createEach = function ( fromRight ) {
  return function ( iterable, iteratee, context ) {
    iterable = toObject( iterable );
    iteratee = getIteratee( iteratee );

    return isArrayLike( iterable ) ?
      baseForEach( iterable, iteratee, context, fromRight ) :
      baseForIn( iterable, iteratee, context, getKeys( iterable ), fromRight );
  };
};

var createEverySome = function ( every ) {
  return function ( iterable, iteratee, context ) {
    iterable = getIterable( toObject( iterable ) );
    iteratee = getIteratee( iteratee );

    var i = 0,
        length = getLength( iterable );

    for ( ; i < length; ++i ) {
      if ( has( i, iterable ) && iteratee.call( context, iterable[ i ], i, iterable ) != every ) {
        return !every;
      }
    }

    return every;
  };
};

var createFilter = function ( not ) {
  return function ( iterable, iteratee, context ) {
    iterable = getIterable( toObject( iterable ) );
    iteratee = getIteratee( iteratee );
    return baseFilter( not, iterable, iteratee, context );
  };
};

var createFind = function ( returnIndex, fromRight ) {
  return function ( iterable, iteratee, context ) {
    iterable = toObject( iterable );

    var i = -1,
        j = getLength( iterable ) + i,
        index, value;

    for ( ; j >= 0; --j ) {
      index = fromRight ? j : ++i;
      value = iterable[ index ];

      if ( has( index, iterable ) && iteratee.call( context, value, index, iterable ) ) {
        return returnIndex ? index : value;
      }
    }

    if ( returnIndex ) {
      return -1;
    }
  };
};

var createForEach = function ( fromRight ) {
  return function ( iterable, iteratee, context ) {
    iterable = getIterable( toObject( iterable ) );
    iteratee = getIteratee( iteratee );
    return baseForEach( iterable, iteratee, context, fromRight );
  };
};

var createForIn = function ( getKeys, fromRight ) {
  return function ( object, iteratee, context ) {
    return ( object = toObject( object ) ),
      baseForIn( object, iteratee, context, getKeys( object ), fromRight );
  };
};

var createIndexOf = function ( fromRight ) {
  return function ( iterable, search, fromIndex ) {
    if ( arguments.length < 2 ) {
      return -1;
    }

    return baseIndexOf( toObject( iterable ), search, fromIndex, fromRight );
  };
};

var createMap = function ( fromRight ) {
  return function ( iterable, iteratee, context ) {
    iterable = getIterable( toObject( iterable ) );
    iteratee = getIteratee( iteratee );
    return baseMap( iterable, iteratee, context, fromRight );
  };
};

var createRange = function ( reverse ) {
  return function ( start, end, step ) {
    if ( step === undefined ) {
      step = 1;

      if ( end === undefined ) {
        end = start;
        start = 0;
      }
    }

    if ( end < start && step > 0 ) {
      step = -step;
    }

    return baseRange( reverse, start, end, step );
  };
};

var createToCaseFirst = function ( toCase ) {
  return function ( string ) {
    if ( string == null ) {
      throw TypeError( ERR_UNDEFINED_OR_NULL );
    }

    return ( string += '' ).length > 1 ?
      string.charAt( 0 )[ toCase ]() + string.slice( 1 ) : string[ toCase ]();
  };
};

var createToPairs = function ( getKeys ) {
  return function ( object ) {
    object = toObject( object );
    return baseToPairs( object, getKeys( object ) );
  };
};

var createTrim = function ( regexp ) {
  return function ( target ) {
    if ( target == null ) {
      throw TypeError( ERR_UNDEFINED_OR_NULL );
    }

    return ( '' + target ).replace( regexp, '' );
  };
};

var createValues = function ( getKeys ) {
  return function ( object ) {
    object = toObject( object );
    return baseValues( object, getKeys( object ) );    
  };
};

var createRound = function ( round ) {
  return function ( value, precision ) {
    return precision === undefined ?
      round( value ) :
      round( value * ( precision = power( 10, precision ) ) ) / precision;
  };
};

/** Other methods */

var apply = function ( target, context, args ) {
  switch ( args.length ) {
    case 0: return target.call( context );
    case 1: return target.call( context, args[ 0 ] );
    case 2: return target.call( context, args[ 0 ], args[ 1 ] );
    case 3: return target.call( context, args[ 0 ], args[ 1 ], args[ 2 ] );
  }

  return target.apply( context, args );
};

var getLength = function ( iterable ) {
  return iterable == null ? 0 : iterable.length >>> 0;
};

var notwhite = function ( string ) {
  if ( !isString( string ) ) {
    throw TypeError( ERR_STRING_EXPECTED );
  }

  return string.match( RE_NOT_WHITESPACES ) || [];
};

var toCamelCase = function () {
  var toCamelCase = function ( a ) {
    return a.charAt( 1 ).toUpperCase();
  };

  return function ( string ) {
    return string.indexOf( '-' ) < 0 ?
      string : string.replace( /-\w/g, toCamelCase );
  };
}();

var types = {};

var getType = function ( value ) {
  if ( value === null ) {
    return 'null';
  }

  if ( value === undefined ) {
    return 'undefined';
  }

  var type = typeof value;

  if ( type != 'object' && type != 'function' ) {
    return type;
  }

  return types[ type = toString.call( value ) ] ||
    ( types[ type ] = type.slice( 8, -1 ).toLowerCase() );
};

var castPath = function ( value ) {
  if ( isArray( value ) ) {
    return value;
  }

  return isKey( value ) ? [ value ] : stringToPath( '' + value );
};

var getIteratee = function ( value ) {
  if ( isFunction( value ) ) {
    return value;
  }

  if ( isKey( value ) ) {
    return property( value );
  }

  throw TypeError( ERR_FUNCTION_EXPECTED );
};

var getIterable = function ( value ) {
  return isString( value ) ?
    value.split( '' ) : isArrayLike( value ) ?
    value : baseValues( value, getKeys( value ) );
};

var exec = function ( regexp, string ) {
  var result = [],
      value;

  regexp.lastIndex = 0;

  while ( ( value = regexp.exec( string ) ) ) {
    result.push( value );
  }

  return result;
};

var stringToPath = function ( string ) {
  var path = exec( RE_PROPERTY, string ),
      i = path.length - 1,
      value;

  for ( ; i >= 0; --i ) {
    value = path[ i ];

    path[ i ] = value[ 7 ] !== undefined ?
      value[ 7 ] : value[ 4 ] !== undefined ?
      value[ 4 ] : value[ 2 ] || value[ 3 ];
  }

  return path;
};

var isKey = function ( value, object ) {
  if ( !value ) {
    return true;
  }

  if ( isArray( value ) ) {
    return false;
  }

  var type = typeof value;

  return type == 'number' ||
    type == 'symbol' ||
    type == 'boolean' ||
    ( object != null && has( value, Object( object ) ) ) ||
    !RE_DEEP_KEY.test( value );
};

var unescape = function ( string ) {
  return string.replace( /\\(\\)?/g, '$1' );
};

var toKey = function ( value ) {
  var type = getType( value ),
      key;

  if ( type == 'string' ) {
    return unescape( value );
  }

  if ( type == 'symbol' ) {
    return value;
  }

  key = '' + value;

  return key == '0' && 1 / value == -Infinity ? '-0' : key;
  // return isSymbol( value ) ? value : unescape( getAsString( value ) );
};

/* var getAsString = function ( value ) {
  if ( isSymbol( value ) ) {
    return value;
  }

  return ( value == 0 && 1 / value == -Infinity ? '-' : '' ) + value;
}; */

var parent = function ( object, path ) {
  return object == null ?
    undefined : baseAccessProp( object, path.slice( 0, -1 ) );
};

var getStyle = function ( element, name ) {
  return element.style[ name ] || getComputedStyle( element ).getPropertyValue( name );
};

var has = function ( key, object ) {
  return object != null && ( object[ key ] !== undefined || key in object );
  // return !isPrimitive( object ) && ( object[ key ] !== undefined || key in object );
};

var getTime = Date.now || function () {
  return new Date().getTime();
};

var before = function ( n, target ) {
  if ( !isFunction( target ) ) {
    throw TypeError( ERR_FUNCTION_EXPECTED );
  }

  n = defaultTo( n, 2 );

  var value;

  return function () {
    if ( target ) {
      if ( --n > 0 ) {
        value = apply( target, this, arguments );
      }

      if ( n < 2 ) {
        target = undefined;
      }
    }

    return value;
  };
};

var bind = function () {
  var args = function ( partials, args ) {
    var i = 0,
        j = -1,
        length = partials.length,
        result = [],
        value;

    for ( ; i < length; ++i ) {
      value = partials[ i ];
      result.push( value === Scotch ? args[ ++j ] : value );
    }

    length = args.length;

    for ( ; j < length; ++j ) {
      result.push( args[ i ] );
    }

    return result;
  };

  return function ( target, context ) {
    if ( !isFunction( target ) ) {
      throw TypeError( ERR_FUNCTION_EXPECTED );
    }

    if ( arguments.length < 3 ) {
      return baseBind( target, context );
    }

    var partials = slice.call( arguments, 2 );

    if ( lastIndexOf( partials, Scotch ) < 0 ) {
      return apply( baseBind, undefined, arguments );
    }

    return function () {
      return apply( target, context, args( partials, arguments ) );
    };
  };
}();

var clamp = function ( value, lower, upper ) {
  return upper === undefined ?

    value >= lower ?
      lower : value :

    value >= upper ?
      upper : value <= lower ?
      lower : value;
};

var getClone = function ( deep, target, guard ) {
  if ( guard || target === undefined ) {
    target = deep;
    deep = true;
  }

  target = toObject( target );

  var clone = create( target );

  each( target, function ( value, key, target ) {
    if ( value === target ) {
      this[ key ] = this;
    } else if ( deep && !isPrimitive( value ) ) {
      this[ key ] = getClone( deep, value );
    } else {
      this[ key ] = value;
    }
  }, clone );

  return clone;
};

var cloneArray = function ( iterable ) {
  return iterable ? baseCloneArray( iterable ) : [];
};

var compact = function ( iterable ) {
  return without( iterable, undefined );
};

var constant = function ( value ) {
  return function () {
    return value;
  };
};

var create = Object.create || function () {
  var Constructor = function () {};

  return function ( prototype, descriptors ) {
    if ( prototype !== null && isPrimitive( prototype ) ) {
      throw TypeError( 'Object prototype may only be an Object or null: ' + prototype );
    }

    Constructor.prototype = prototype;

    var object = new Constructor();

    if ( prototype === ( Constructor.prototype = null ) ) {
      setPrototypeOf( object, prototype );
    }

    return arguments.length < 2 ?
      object : defineProperties( object, descriptors );
  };
}();

var defaultTo = function ( value, defaultValue ) {
  return value == null || value !== value ?
    defaultValue : value;
};

var defineProperties = support.defineProperty === 2 ?
  Object.defineProperties :

function ( object, descriptors ) {
  if ( support.defineProperty ) {
    try {
      return Object.defineProperties( object, descriptors );
    } catch ( e ) {}
  }

  if ( isPrimitive( object ) ) {
    throw TypeError( 'defineProperties called on non-object' );
  }

  if ( isPrimitive( descriptors ) ) {
    throw TypeError( 'Property description must be an object: ' + descriptors );
  }

  each( descriptors, function ( descriptor, key ) {
    baseDefineProperty( this, key, descriptor );
  }, object );

  return object;
};

var defineProperty = support.defineProperty === 2 ?
  Object.defineProperty :

function ( object, key, descriptor ) {
  if ( support.defineProperty ) {
    try {
      return Object.defineProperty( object, key, descriptor );
    } catch ( e ) {}
  }

  if ( isPrimitive( object ) ) {
    throw TypeError( 'defineProperty called on non-object' );
  }

  if ( isPrimitive( descriptor ) ) {
    throw TypeError( 'Property description must be an object: ' + descriptor );
  }

  return baseDefineProperty( object, key, descriptor );
};

var equal = function ( a, b ) {
  return a === b || a !== a && b !== b;
};

var globalExec = function ( regexp, string ) {
  if ( getType( regexp ) != 'regexp' ) {
    throw TypeError( 'Expected a regexp' );
  }

  return regexp.global ?
    exec( regexp, '' + string ) :
    regexp.exec( '' + string );
};

var fill = function ( iterable, value, start, end ) {
  iterable = toObject( iterable );

  var length = getLength( iterable );

  start = start === undefined ?
    0 : toIndex( start, length );

  end = end === undefined ?
    length : toIndex( end, length );

  for ( ; start < end; ++start ) {
    iterable[ start ] = value;
  }

  return iterable;
};

var flatten = function ( iterable, depth ) {
  return baseFlatten( toObject( iterable ), [], defaultTo( depth, Infinity ) );
};

var fromPairs = function ( pairs ) {
  var i = 0,
      length = pairs.length,
      object = {};

  for ( ; i < length; ++i ) {
    object[ pairs[ i ][ 0 ] ] = pairs[ i ][ 1 ];
  }

  return object;
};

var timestamp = function () {
  var perfomance = window.perfomance,
      navigatorStart;

  if ( perfomance ) {
    if ( perfomance.now ) {
      return perfomance.now;
    }

    navigatorStart = perfomance.timing &&
      perfomance.timing.navigatorStart;
  }

  if ( !navigatorStart ) {
    navigatorStart = getTime();
  }

  return function () {
    return getTime() - navigatorStart;
  };
}();

var accessProp = function ( object, path, value ) {
  return baseAccessProp( toObject( object ), castPath( path ), value, arguments.length > 2 );
};

var getFile = function ( path, useAsync, options ) {
  if ( isObject( path, true ) ) {
    options = path;
    path = options.path;
    useAsync = options.useAsync;
  } else if ( options === undefined ) {
    options = {};
  }

  useAsync = useAsync !== undefined && useAsync;

  var request = new XMLHttpRequest(),
      data = null,
      id;

  request.onreadystatechange = function () {
    var readyState = this.readyState;

    if ( readyState < 3 ) {
      return;
    }

    if ( readyState === 3 ) {
      if ( options.onloading ) {
        options.onloading.call( this, options, this.responseText );
      }

      return;
    }

    if ( readyState === 4 ) {
      if ( this.status !== 200 ) {
        if ( options.onerror ) {
          options.onerror.call( this, options );
        }

        return;
      }

      if ( id ) {
        window.clearTimeout( id );
      }

      data = this.responseText;

      if ( options.onload ) {
        options.onload.call( this, options, data );
      }
    }
  };

  request.open( 'GET', path, useAsync );

  if ( useAsync ) {
    id = window.setTimeout( function () {
      request.abort();
    }, has( 'timeout', options ) ? options.timeout : 60000 );
  }

  request.send();

  return data;
};

var getPrototypeOf = Object.getPrototypeOf || function ( target ) {
  if ( target == null ) {
    throw TypeError( ERR_UNDEFINED_OR_NULL );
  }

  var prototype = target.__proto__,
      constructor;

  if ( prototype !== undefined ) {
    return prototype;
  }

  constructor = target.constructor;

  return isFunction( constructor, true ) ?
    constructor.prototype : obj;
};

var identity = function ( value ) {
  return value;
};

var includes = function ( object, value ) {
  return ( isString( object ) ? object.indexOf( value ) : lastIndexOf( isArrayLike( object ) ? object : getValues( object ), value ) ) >= 0;
};

var invert = function ( target ) {
  return baseInvert( toObject( target ) );
};

var getKeys = Object.keys || function ( object ) {
  return baseKeys( toObject( object ) );
};

var getKeysIn = function ( target ) {
  target = toObject( target );

  var keys = [],
      key;

  for ( key in target ) {
    keys.push( key );
  }

  return keys;
};

var merge = function ( iterable ) {
  iterable = toObject( iterable );

  var i = 1,
      length = arguments.length,
      expander;

  for ( ; i < length; ++i ) {
    expander = arguments[ i ];

    if ( isArrayLike( expander, false ) ) {
      baseMerge( iterable, expander );
    } else {
      push.call( iterable, expander );
    }
  }

  return iterable;
};

var method = function ( path ) {
  var args = slice.call( arguments, 1 );

  if ( isKey( path ) ) {
    return baseMethod( toKey( path ), args );
  }

  path = castPath( path );

  return !path.length ?
    noop : path.length < 2 ?
    baseMethod( toKey( path[ 0 ] ), args ) : baseMethodDeep( path, args );
};

var mixin = function ( deep, target ) {
  var nowArray = false,
      i = 2,
      length = arguments.length,
      expander, source, keys, key, value, j, k;

  if ( !isBoolean( deep ) ) {
    target = deep;
    deep = true;
    --i;
  }

  if ( i === length ) {
    target = this;
    --i;
  }

  target = toObject( target );

  for ( ; i < length; ++i ) {
    expander = toObject( arguments[ i ] );
    keys = getKeys( expander );

    for ( j = 0, k = keys.length; j < k; ++j ) {
      key = keys[ j ];
      value = expander[ key ];

      if ( deep && value !== expander &&
        ( isPlainObject( value ) || ( nowArray = isArray( value ) ) ) ) {

        source = target[ key ];

        if ( nowArray ) {
          nowArray = false;

          if ( !isArray( source ) ) {
            source = [];
          }
        } else if ( !isPlainObject( source ) ) {
          source = {};
        }

        target[ key ] = mixin( deep, source, value );
      } else {
        target[ key ] = value;
      }
    }
  }

  return target;
};

var __ = window._,
    _Scotch = window.Scotch;

var noConflict = function ( returnAll ) {
  if ( window._ === Scotch ) {
    window._ = __;
  }

  if ( returnAll && window.Scotch === Scotch ) {
    window.Scotch = _Scotch;
  }

  return Scotch;
};

var noop = function () {};

var nth = function ( iterable, index ) {
  var length = getLength( iterable );

  if ( length && isIndex( index = baseToIndex( index, length ), length ) ) {
    return iterable[ index ];
  }
};

var last = function ( iterable ) {
  return nth( iterable, -1 );
};

var nthArg = function ( index ) {
  return function ( argument ) {
    return index ? nth( arguments, index ) : argument;
  };
};

var once = function ( target ) {
  return before( 2, target );
};

var property = function ( path, value, set ) {
  set = !set && arguments.length > 1;
  path = castPath( path );

  return path.length === 1 ?
    baseProp( path[ 0 ], value, set ) :
    basePropDeep( path, value, set );
};

var random = function ( floating, lower, upper ) {
  var length = arguments.length;

  if ( length < 3 ) {
    if ( length < 2 ) {
      upper = length ? floating : 1;
      lower = 0;
    } else {
      upper = lower;
      lower = floating;
    }

    floating = false;
  }

  return baseRandom( floating || lower % 1 || upper % 1, lower, upper );
};

var reduce = function ( iterable, iteratee, value ) {
  iterable = getIterable( toObject( iterable ) );
  iteratee = getIteratee( iteratee );

  var i = 0,
      length = getLength( iterable );

  if ( arguments.length < 3 ) {
    while ( i < length && !has( i, iterable ) ) {
      ++i;
    }

    if ( i === length ) {
      throw TypeError( ERR_REDUCE_OF_EMPTY_ARRAY );
    }

    value = iterable[ i++ ];
  }

  for ( ; i < length; ++i ) {
    if ( has( i, iterable ) ) {
      value = iteratee( value, iterable[ i ], i, iterable );
    }
  }

  return value;
};

var reduceRight = function ( iterable, iteratee, value ) {
  iterable = getIterable( toObject( iterable ) );
  iteratee = getIteratee( iteratee );

  var length = getLength( iterable ),
      i = length - 1;

  if ( arguments.length < 3 ) {
    while ( i >= 0 && !has( i, iterable ) ) {
      --i;
    }

    if ( i < 0 ) {
      throw TypeError( ERR_REDUCE_OF_EMPTY_ARRAY );
    }

    value = iterable[ i-- ];
  }

  for ( ; i >= 0; --i ) {
    if ( has( i, iterable ) ) {
      value = iteratee( value, iterable[ i ], i, iterable );
    }
  }

  return value;
};

var reverse = function ( iterable ) {
  if ( iterable == null ) {
    throw TypeError( ERR_UNDEFINED_OR_NULL );
  }

  return arr.reverse.call( iterable );
};

var sample = function ( object ) {
  return baseSample( getIterable( toObject( object ) ) );
};

var sampleSize = function ( object, size ) {
  return baseShuffle( getIterable( toObject( object ) ), defaultTo( size, 1 ) );
};

var setPrototypeOf = Object.setPrototypeOf || function ( target, prototype ) {
  if ( target == null ) {
    throw TypeError( ERR_UNDEFINED_OR_NULL );
  }

  if ( prototype !== null && isPrimitive( prototype ) ) {
    throw TypeError( 'Object prototype may only be an Object or null: ' + prototype );
  }

  if ( !isPrimitive( target ) && has( '__proto__', target ) ) {
    target.__proto__ = prototype;
  }

  return target;
};

var shuffle = function ( object ) {
  if ( !object ) {
    return object;
  }

  if ( isString( object ) ) {
    return baseShuffle( object.split( '' ) ).join( '' );
  }

  return baseShuffle( getIterable( toObject( object ) ) );
};

var size = function ( value ) {
  var stack = [ value ],
      checked = [],
      size = 0;

  while ( stack.length ) {
    if ( ( value = stack.pop() ) == null ) {
      continue;
    }

    switch ( typeof value ) {
      case 'boolean':
        size += 4;
        break;

      case 'number':
        size += 8;
        break;

      case 'string':
        size += value.length * 2;
        break;

      case 'object':
      case 'function':
        if ( lastIndexOf( checked, value ) < 0 ) {
          checked.push( value );
          stack = apply( concat, stack, baseToPairs( value, getKeys( value ) ) );
        }
    }
  }

  return size;
};

var sleep = function ( ms ) {
  var awakeTime = timestamp() + ms;

  while ( timestamp() < awakeTime ) {
    // Waiting...
    // log( 'keep calm and' );
  }

  // log( 'see you later' );
};

// var log = console && console.log || noop;

var makeSlice = function ( iterable, start, end ) {
  iterable = toObject( iterable );

  var length = getLength( iterable ),
      i, sliced, index;

  start = start === undefined ?
    0 : toIndex( start, length );

  end = end === undefined ?
    length : toIndex( end, length );

  i = end - start;
  sliced = Array( i-- );

  for ( ; i >= 0; --i ) {
    index = start + i;

    if ( has( index, iterable ) ) {
      sliced[ i ] = iterable[ index ];
    }
  }

  return sliced;
};

var times = function ( times, callback ) {
  times = callback === undefined ?
    ( callback = times, 1 ) : floor( times ) || 1;

  if ( !isFunction( callback ) ) {
    throw TypeError( ERR_FUNCTION_EXPECTED );
  }

  return baseTimes( times, callback );
};

var toArray = function ( value ) {
  if ( !value ) {
    return [];
  }

  if ( isString( value ) ) {
    return value.split( '' );
  }

  if ( isArrayLike( value ) ) {
    return baseCloneArray( value );
  }

  return baseValues( value, getKeys( value ) );
};

var toIndex = function ( value, length ) {
  return clamp( baseToIndex( value, length ), 0, length );
};

var toObject = function ( target ) {
  if ( target == null && strict ) {
    throw TypeError( ERR_UNDEFINED_OR_NULL );
  }

  return Object( target );
};

var toPlainObject = function ( target ) {
  return target == null ?
    {} : assignIn( {}, toObject( target ) );
};

var getTypeCached = cached( getType, undefined, 'undefined' );

var unique = function () {
  var unique = function ( value, i, iterable ) {
    return indexOf( iterable, value ) == i;
  };

  return function ( iterable ) {
    return filter( iterable, unique );
  };
}();

var unzip = function ( zip ) {
  var max = 0;

  zip = filter( zip, function ( group ) {
    if ( !isArrayLike( group ) ) {
      return false;
    }

    if ( group.length > max ) {
      max = group.length;
    }

    return true;
  } );

  return baseTimes( max, function ( i ) {
    return baseMap( zip, baseProp( i ) );
  } );
};

var without = function ( iterable ) {
  iterable = toObject( iterable );

  var i = 0,
      length = iterable.length,
      without = slice.call( arguments, 1 ),
      temp = [],
      value;

  for ( ; i < length; ++i ) {
    value = iterable[ i ];

    if ( indexOf( without, value ) < 0 ) {
      temp.push( value );
    }
  }

  return temp;
};

var zip = function () {
  return unzip( arguments );
};

var assign = Object.assign || createAssign( getKeys ),
    assignIn = createAssign( getKeysIn ),
    each = createEach( false ),
    eachRight = createEach( true ),
    ceilNumber = createRound( ceil ),
    deepFind = createDeepFind( false, each ),
    deepFindLast = createDeepFind( false, eachRight ),
    deepFindBy = createDeepFind( true, each ),
    deepFindLastBy = createDeepFind( true, eachRight ),
    every = createEverySome( true ),
    some = createEverySome( false ),
    filter = createFilter( false ),
    reject = createFilter( true ),
    find = arr.find ? bindFast( call, arr.find ) : createFind( false, false ),
    findIndex = arr.findIndex ? bindFast( call, arr.findIndex ) : createFind( true, false ),
    findLast = createFind( false, true ),
    findLastIndex = createFind( true, true ),
    floorNumber = createRound( floor ),
    forEach = createForEach( false ),
    forEachRight = createForEach( true ),
    forIn = createForIn( getKeysIn, false ),
    forInRight = createForIn( getKeysIn, true ),
    forOwn = createForIn( getKeys, false ),
    forOwnRight = createForIn( getKeys, true ),
    indexOf = createIndexOf( false ),
    lastIndexOf = createIndexOf( true ),
    map = createMap( false ),
    mapRight = createMap( true ),
    range = createRange( false ),
    rangeRight = createRange( true ),
    roundNumber = createRound( round ),
    toUpperFirst = createToCaseFirst( 'toUpperCase' ),
    toLowerFirst = createToCaseFirst( 'toLowerCase' ),
    toPairs = Object.entries || createToPairs( getKeys ),
    toPairsIn = createToPairs( getKeysIn ),
    trim = str.trim ? bindFast( call, str.trim ) : createTrim( /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/ ),
    trimStart = str.trimStart ? bindFast( call, str.trimStart ) : createTrim( /^[\s\uFEFF\xA0]+/ ),
    trimEnd = str.trimEnd ? bindFast( call, str.trimEnd ) : createTrim( /[\s\uFEFF\xA0]+$/ ),
    getValues = Object.values || createValues( getKeys ),
    getValuesIn = createValues( getKeysIn );

var hextorgb = function ( hex ) {
  return [ ( hex = window.parseInt( hex, 16 ) ) >> 16 & 255, hex >> 8 & 255, hex & 255 ];
};

var rgbtohex = function () {
  var tohex = function ( decimal ) {
    return ( decimal = decimal.toString( 16 ) ).length < 2 ? '0' + decimal : decimal;
  };

  return function ( rgb ) {
    return tohex( rgb[ 0 ] ) + tohex( rgb[ 1 ] ) + tohex( rgb[ 2 ] );
  };
}();

var strict = true;

var usestrict = function ( state ) {
  return strict = state, this;
};

var eventprops = [
  'altKey',        'bubbles',        'cancelable',
  'cancelBubble',  'changedTouches', 'ctrlKey',
  'currentTarget', 'detail',         'eventPhase',
  'metaKey',       'pageX',          'pageY',
  'shiftKey',      'view',           'char',
  'charCode',      'key',            'keyCode',
  'button',        'buttons',        'clientX',
  'clientY',       'offsetX',        'offsetY',
  'pointerId',     'pointerType',    'relatedTarget',
  'returnValue',   'screenX',        'screenY',
  'targetTouches', 'toElement',      'touches',
  'type',          'which',          'isTrusted'
];

var Event = function ( source, options ) {
  if ( source && source.type !== undefined ) {
    var i = eventprops.length - 1,
        key;

    for ( ; i >= 0; --i ) {
      if ( has( key = eventprops[ i ], source ) ) {
        this[ key ] = source[ key ];
      }
    }

    this.originalEvent = source;

    this.target = source.target && source.target.nodeType === 3 ?
      source.target.parentNode : source.target;
  } else if ( typeof source == 'string' ) {
    this.type = source;
  }

  if ( options !== undefined ) {
    baseAssign( this, options, getKeys( options ) );
  }

  this.timeStamp = timestamp();
};

Event.prototype = {
  constructor: Event,
  originalEvent: null,
  type: '',
  timeStamp: 0,
  returnValue: true,
  cancelBubble: false,

  preventDefault: function () {
    var event = this.originalEvent;

    if ( event ) {
      if ( event.preventDefault ) {
        event.preventDefault();
      } else {
        event.returnValue = false;
      }
    }

    this.returnValue = event.returnValue;
  },

  stopPropagation: function () {
    var event = this.originalEvent;

    if ( event ) {
      if ( event.stopPropagation ) {
        event.stopPropagation();
      } else {
        event.cancelBubble = true;
      }
    }

    this.cancelBubble = event.cancelBubble;
  }
};

var event = function () {
  var ev = {},
      list = ev.list = create( null );

  var fixType = ev.iefixtype = function ( type ) {

    // В attachEvent нет события DOMContentLoaded,
    // и type должен иметь префикс on.
    // There is no 'DOMContentLoaded' event in 'attachEvent'
    // and 'type' should have the 'on' prefix.
    return type === 'DOMContentLoaded' ?
      'onreadystatechange' : 'on' + type;
  };

  var add = ev.add = function ( target, type, listener, useCapture, one ) {
    var wrapper;

    if ( useCapture === undefined ) {
      useCapture = false;
    }

    if ( support.addEventListener ) {
      target.addEventListener( type, ( wrapper = one ?
        function ( event ) {
          remove( target, type, listener, useCapture );
          listener.call( target, event );
        } : listener ), useCapture );
    } else {
      if ( typeof listener != 'function' ) {
        return;
      }

      wrapper = function ( event ) {
        if ( type === 'DOMContentLoaded' && target.readyState !== 'complete' ) {
          return;
        }

        if ( one ) {
          remove( target, type, listener, useCapture );
        }

        event = new Event( event );
        event.type = type;

        listener.call( target, event );
      };

      target.attachEvent( fixType( type ), wrapper );
    }

    ( list[ type ] || ( list[ type ] = [] ) )
      .push( [ target, listener, useCapture, wrapper, one ] );
  };

  var remove = ev.remove = function ( target, type, listener, useCapture ) {
    if ( type === undefined ) {
      baseForIn( list, function ( value, type ) {
        remove( this, type );
      }, target, getKeys( list ) );

      return;
    }

    var i = 0,
        filtered = list[ type ],
        removeAll = listener === undefined,
        fix, item;

    if ( !filtered ) {
      return;
    }

    if ( useCapture === undefined ) {
      useCapture = false;
    }

    if ( !support.addEventListener ) {
      fix = fixType( type );
    }

    for ( ; i < filtered.length; ++i ) {
      item = filtered[ i ];

      if ( item[ 0 ] !== target ||
        !removeAll && (
          item[ 1 ] !== listener ||
          item[ 2 ] !== useCapture
        ) ) {

        continue;
      }

      filtered.splice( i--, 1 );

      if ( !filtered.length ) {
        delete list[ type ];
      }

      if ( support.addEventListener ) {
        target.removeEventListener( type, item[ 3 ], item[ 2 ] );
      } else {
        target.detachEvent( fix, item[ 3 ] );
      }
    }
  };

  var copy = ev.copy = function ( to, from, deep, types ) {
    if ( !types ) {
      types = getKeys( list );
    }

    var i = 0,
        length = types.length,
        type, filtered, item, j, toChildNodes;

    for ( ; i < length; ++i ) {
      filtered = list[ type = types[ i ] ];

      if ( !filtered ) {
        continue;
      }

      for ( j = 0; j < filtered.length; ++j ) {
        item = filtered[ j ];

        if ( item[ 0 ] === from ) {
          add( to, type, item[ 1 ], item[ 2 ], item[ 4 ] );
        }
      }
    }

    if ( deep ) {
      toChildNodes = to.childNodes;
      from = from.childNodes;

      for ( i = 0, length = toChildNodes.length; i < length; ++i ) {
        copy( toChildNodes[ i ], from[ i ], deep, types );
      }
    }

    return to;
  };

  ev.dispatch = function ( target, type, data ) {
    var filtered = list[ type ],
        i = 0,
        item, event;

    if ( !filtered ) {
      return;
    }

    for ( ; i < filtered.length; ++i ) {
      item = filtered[ i ];

      if ( item[ 0 ] !== target ) {
        continue;
      }

      event = new Event( type, data );
      event.target = target;
      event.isTrusted = false;

      item[ 3 ].call( target, event );
    }
  };

  return ev;
}();

/**
 * Jonathan Neal getComputedStyle() polyfill.
 * https://github.com/jonathantneal/polyfill/blob/master/polyfills/getComputedStyle/polyfill.js
 *
 * Small fixes and formatting from ScotchJS.
 */
var getComputedStyle = window.getComputedStyle || function () {
  var toDOMString = function () {
    var toDOMString = function ( letter ) {
      return '-' + letter.toLowerCase();
    };

    return function ( string ) {
      return string.replace( /[A-Z]/g, toDOMString );
    };
  };

  var getComputedStylePixel = function ( element, name, fontSize ) {
    // Internet Explorer sometimes struggles
    // to read currentStyle until the
    // element's document is accessed.
    var value = element.currentStyle[ name ]
      .match( /([\d.]+)(em|%|cm|in|mm|pc|pt|)/ ) || [ 0, 0, '' ],

        size = value[ 1 ],
        suffix = value[ 2 ],
        rootSize, parent;

    if ( fontSize === undefined ) {
      parent = element.parentElement;

      fontSize = parent && ( suffix === '%' || suffix === 'em' ) ?
        getComputedStylePixel( parent, 'fontSize' ) : 16;
    }

    rootSize = name == 'fontSize' ?
      fontSize : /width/i.test( name ) ?
      element.clientWidth : element.clientHeight;

    return suffix === 'em' ?
      size * fontSize : suffix === '%' ?
      size / 100 * rootSize : suffix === 'cm' ?
      size * 0.3937 * 96 : suffix === 'in' ?
      size * 96 : suffix === 'mm' ?
      size * 0.3937 * 96 / 10 : suffix === 'pc' ?
      size * 12 * 96 / 72 : suffix === 'pt' ?
      size * 96 / 72 : size;
  };

  var setShortStyleProperty = function ( style, name ) {
    var borderSuffix = name == 'border' ? 'Width' : '',
        t = name + 'Top' + borderSuffix,
        r = name + 'Right' + borderSuffix,
        b = name + 'Bottom' + borderSuffix,
        l = name + 'Left' + borderSuffix;

    if ( style[ t ] == style[ r ] && style[ t ] == style[ b ] && style[ t ] == style[ l ] ) {
      style[ name ] = style[ t ];
    } else if ( style[ t ] == style[ b ] && style[ l ] == style[ r ] ) {
      style[ name ] = style[ t ] + ' ' + style[ r ];
    } else if ( style[ l ] == style[ r ] ) {
      style[ name ] = style[ t ] + ' ' + style[ r ] + ' ' + style[ b ];
    } else {
      style[ name ] = style[ t ] + ' ' + style[ r ] + ' ' + style[ b ] + ' ' + style[ l ];
    }
  };

  var CSSStyleDeclaration = function ( element ) {
    var style = this,
        currentStyle = element.currentStyle,
        fontSize = getComputedStylePixel( element, 'fontSize' ),
        names = getKeys( currentStyle ),
        i = names.length,
        name;

    for ( ; i >= 0; --i ) {
      name = names[ i ];

      push.call( style, name == 'styleFloat' ?
        'float' : toDOMString( name ) );

      if ( name == 'styleFloat' ) {
        style[ 'float' ] = currentStyle[ name ];
      } else if ( name == 'width' ) {
        // clientWidth?
        style[ name ] = element.offsetWidth + 'px';
      } else if ( name == 'height' ) {
        style[ name ] = element.offsetHeight + 'px';
      } else if ( style[ name ] != 'auto' && /(margin|padding|border).*W/.test( name ) ) {
        style[ name ] = round( getComputedStylePixel( element, name, fontSize ) ) + 'px';
      } else if ( !name.indexOf( 'outline' ) ) {
        try {
          // errors on checking outline
          style[ name ] = currentStyle[ name ];
        } catch ( e ) {
          style.outline =
            ( style.outlineColor = currentStyle.color ) + ' ' +
            ( style.outlineStyle = style.outlineStyle || 'none' ) + ' ' +
            ( style.outlineWidth = style.outlineWidth || '0px' );
        }
      } else {
        style[ name ] = currentStyle[ name ];
      }
    }

    setShortStyleProperty( style, 'margin' );
    setShortStyleProperty( style, 'padding' );
    setShortStyleProperty( style, 'border' );

    style.fontSize = round( fontSize ) + 'px';
  };

  CSSStyleDeclaration.prototype = {
    constructor: CSSStyleDeclaration,

    getPropertyValue: function ( name ) {
      return this[ toCamelCase( name ) ];
    },

    item: function ( i ) {
      return this[ i ];
    },

    getPropertyPriority: noop,
    getPropertyCSSValue: noop,
    removeProperty: noop,
    setProperty: noop
  };

  return function ( element ) {
    return new CSSStyleDeclaration( element );
  };
}();

/**
 * Based on Erik Möller requestAnimationFrame polyfill:
 *
 * Adapted from https://gist.github.com/paulirish/1579671 which derived from
 * http://paulirish.com/2011/requestanimationframe-for-smart-animating/
 * http://my.opera.com/emoller/blog/2011/12/20/requestanimationframe-for-smart-er-animating
 *
 * requestAnimationFrame polyfill by Erik Möller.
 * Fixes from Paul Irish, Tino Zijdel, Andrew Mao, Klemen Slavič, Darius Bacon.
 *
 * MIT license
 */
var frame = function () {
  var frame = {},
      suffix = 'AnimationFrame',

  request = window[ 'request' + suffix ] ||
    window[ 'webkitRequest' + suffix ] ||
    window[ 'mozRequest' + suffix ],

  cancel = window[ 'cancel' + suffix ] ||
    window[ 'webkitCancel' + suffix ] ||
    window[ 'webkitCancelRequest' + suffix ] ||
    window[ 'mozCancel' + suffix ] ||
    window[ 'mozCancelRequest' + suffix ];

  // iOS6 is buggy
  if ( request && cancel && !/iP(ad|hone|od).*OS\s6/.test( window.navigator.userAgent ) ) {
    frame.requestframe = function ( frame ) {
      return request( frame );
    };

    frame.cancelframe = function ( index ) {
      return cancel( index );
    };
  } else {
    var lastTime = 0,
        frameDuration = 1000 / 60;

    frame.requestframe = function ( frame ) {
      var now = getTime(),
          nextTime = max( lastTime + frameDuration, now );

      return window.setTimeout( function () {
        lastTime = nextTime;
        frame( /* what's here? */ );
      }, nextTime - now );
    };

    frame.cancelframe = window.clearTimeout;
  }

  return frame;
}();

var matches = window.Element && (
  Element.prototype.matches ||
  Element.prototype.oMatchesSelector ||
  Element.prototype.msMatchesSelector ||
  Element.prototype.mozMatchesSelector ||
  Element.prototype.webkitMatchesSelector ) ||

function ( selector ) {
  if ( !isString( selector ) ) {
    if ( strict ) {
      throw TypeError( ERR_STRING_EXPECTED );
    }

    return false;
  }

  var element = this,
      elements, i;

  if ( selector.charAt( 0 ) === '#' && !/\s/.test( selector ) ) {
    return '#' + element.id === selector;
  }

  elements = ( element.document || element.ownerDocument )
    .querySelectorAll( selector );

  for ( i = elements.length - 1; i >= 0; --i ) {
    if ( elements[ i ] === element ) {
      return true;
    }
  }

  return false;
};

var closest = window.Element &&
  Element.prototype.closest ||

function ( selector ) {
  var element = this;

  do {
    if ( matches.call( element, selector ) ) {
      return element;
    }
  } while ( ( element = element.parentElement ) );

  return null;
};

var RE_SINGLE_TAG = /^(<([\w-]+)><\/[\w-]+>|<([\w-]+)(\s*\/)?>)$/;

var parseHTML = function ( data, context ) {
  var match = RE_SINGLE_TAG.exec( data );

  if ( context === undefined ) {
    context = document;
  }

  return match ?
    [ document.createElement( match[ 2 ] || match[ 3 ] ) ] :
    baseCloneArray( createFragment( [ data ], context ).childNodes );
};

var RE_SIMPLE_SELECTOR = /^(?:#([\w-]+)|([\w-]+)|\.([\w-]+))$/;

var DOMWrapper = function ( selector ) {
  if ( !selector ) {
    return;
  }

  if ( isSomething( selector ) ) {
    this[ 0 ] = selector;
    this.length = 1;

    return;
  }

  var i, match, list;

  if ( isString( selector ) ) {
    if ( selector.charAt( 0 ) == '<' ) {
      list = parseHTML( selector );
    } else {
      match = RE_SIMPLE_SELECTOR.exec( selector );

      if ( !match || match[ 3 ] && !support.getElementsByClassName ) {
        list = document.querySelectorAll( selector );
      } else if ( match[ 1 ] ) {
        list = document.getElementById( match[ 1 ] );

        if ( list ) {
          this[ 0 ] = list;
          this.length = 1;
        }

        return;
      } else if ( match[ 2 ] ) {
        list = document.getElementsByTagName( match[ 2 ] );
      } else {
        list = document.getElementsByClassName( match[ 3 ] );
      }
    }
  } else if ( isArrayLike( selector ) ) {
    list = selector;
  } else if ( isFunction( selector ) ) {
    return new DOMWrapper( document ).ready( selector );
  }

  if ( list ) {
    for ( i = ( this.length = getLength( list ) ) - 1; i >= 0; --i ) {
      this[ i ] = list[ i ];
    }
  }
};

var Scotch = function ( input ) {
  return new DOMWrapper( input );
};

var prototype = DOMWrapper.prototype = Scotch.prototype = Scotch.fn = {
  constructor: Scotch,
  length: 0,

  get: function ( i ) {
    return i === undefined ?
      baseCloneArray( this ) : this[ i < 0 ? this.length + i : i ];
  },

  eq: function ( i ) {
    return this.pushStack( i === undefined ? this : [ this.get( i ) ] );
  },

  each: function ( iteratee ) {
    var i = 0,
        length = this.length;

    for ( ; i < length; ++i ) {
      if ( iteratee.call( this[ i ], i, this[ i ] ) === false ) {
        break;
      }
    }

    return this;
  },

  style: function ( name, value ) {
    var addUnit = 0;

    if ( isString( name ) ) {
      if ( !cssNumbers[ toCamelCase( name ) ] ) {
        if ( typeof value == 'function' ) {
          addUnit = 1;
        } else if ( isNumber( value ) ) {
          value += 'px';
        }
      }
    } else if ( isObject( name, true ) ) {
      addUnit = 2;
    }

    return access( this, function ( element, name, value, setStyle ) {
      if ( element.nodeType !== 1 ) {
        return null;
      }

      if ( !setStyle ) {
        return getStyle( element, name );
      }

      if ( ( addUnit === 2 ? !cssNumbers[ toCamelCase( name ) ] : addUnit === 1 ) && isNumber( value ) ) {
        value += 'px';
      }

      element.style[ name ] = value;
    }, name, value, arguments.length > 1, null );
  },

  addClass: function ( classes ) {
    var raw = typeof classes != 'function',
        i = this.length - 1,
        element;

    for ( ; i >= 0; --i ) {
      if ( ( element = this[ i ] ).nodeType === 1 ) {
        classList.add( element, raw ?
          classes : classes.call( element, i, element.className ) );
      }
    }

    return this;
  },

  removeClass: function ( classes ) {
    var mode = !arguments.length ?
          0 : isFunction( classes, false ) ?
          1 : 2,

        i = this.length - 1,
        element;

    for ( ; i >= 0; --i ) {
      if ( ( element = this[ i ] ).nodeType === 1 ) {
        if ( mode ) {
          classList.remove( element, mode === 1 ?
            classes.call( element, i, element.className ) : classes );
        } else {
          element.className = '';
        }
      }
    }

    return this;
  },

  toggleClass: function ( classes, state ) {
    if ( state !== undefined ) {
      return this[ state ? 'addClass' : 'removeClass' ]( classes );
    }

    var raw = typeof classes != 'function',
        i = this.length - 1,
        element;

    for ( ; i >= 0; --i ) {
      if ( ( element = this[ i ] ).nodeType === 1 ) {
        classList.toggle( element, raw ?
          classes : classes.call( element, i, element.className ) );
      }
    }

    return this;
  },

  hasClass: function ( classes ) {
    var i = this.length - 1,
        element;

    for ( ; i >= 0; --i ) {
      if ( ( element = this[ i ] ).nodeType === 1 &&
        classList.has( element, classes ) ) {

        return true;
      }
    }

    return false;
  },

  offset: function ( options ) {
    var element, document, root, body,
        offset, byCallback, i, style,
        scrollTop, scrollLeft, clientTop, clientLeft;

    if ( !arguments.length ) {
      element = this[ 0 ];

      if ( !element || element.nodeType !== 1 ) {
        return null;
      }

      document = element.ownerDocument;
      root = document.documentElement;
      body = document.body;
      offset = element.getBoundingClientRect();
      scrollTop = document.defaultView.pageYOffset || root.scrollTop || body.scrollTop;
      scrollLeft = document.defaultView.pageXOffset || root.scrollLeft || body.scrollLeft;
      clientTop = root.clientTop || body.clientTop || 0;
      clientLeft = root.clientLeft || body.clientLeft || 0;

      return {
        top: offset.top + scrollTop - clientTop,
        left: offset.left + scrollLeft - clientLeft
      };
    }

    if ( isPrimitive( options ) ) {
      throw TypeError( ERR_INVALID_ARGS );
    }

    byCallback = isFunction( options );

    for ( i = this.length - 1; i >= 0; --i ) {
      element = this[ i ];

      if ( element.nodeType !== 1 ) {
        continue;
      }

      offset = byCallback ?
        options.call( element, i, new DOMWrapper( element ).offset() ) : options;

      style = element.style;

      style.top = offset.top + 'px';
      style.left = offset.left +'px';

      if ( getStyle( element, 'position' ) === 'static' ) {
        style.position = 'relative';
      }
    }

    return this;
  },

  is: function ( selector ) {
    var byCallback = isFunction( selector ),
        i = this.length - 1,
        element;

    for ( ; i >= 0; --i ) {
      element = this[ i ];

      if ( byCallback ?
        selector.call( element, i, element ) :
        is( element, selector ) ) {

        return true;
      }
    }

    return false;
  },

  closest: function ( selector ) {
    var i = 0,
        length = this.length,
        list = [],
        element, temp;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      temp = element.nodeType === 1 &&
        closest.call( element, selector );

      if ( temp && indexOf( list, temp ) < 0 ) {
        list.push( temp );
      }
    }

    return this.pushStack( list );
  },

  parent: function ( selector ) {
    var select = !!arguments.length,
        i = 0,
        length = this.length,
        list = [],
        element, parent;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      parent = element.nodeType === 1 &&
        element.parentElement;

      if ( parent && indexOf( list, parent ) < 0 &&
        ( !select || matches.call( parent, selector ) ) ) {

        list.push( parent );
      }
    }

    return this.pushStack( list );
  },

  siblings: function ( selector ) {
    var select = !!arguments.length,
        i = 0,
        length = this.length,
        list = [],
        element, siblings, sibling, j, k;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      siblings = element.nodeType === 1 &&
        element.parentElement.children;

      if ( !siblings ) {
        continue;
      }

      for ( j = 0, k = siblings.length; j < k; ++j ) {
        sibling = siblings[ j ];

        if ( sibling !== element &&
          sibling.nodeType === 1 &&
          indexOf( list, sibling ) < 0 &&
          ( !select || matches.call( sibling, selector ) ) ) {
          
          list.push( sibling );
        }
      }
    }

    return this.pushStack( list );
  },

  children: function ( selector ) {
    var select = !!arguments.length,
        i = 0,
        length = getLength( this ),
        list = [],
        element, children, child, j, k;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      children = element.nodeType === 1 &&
        element.children;

      if ( !children ) {
        continue;
      }

      for ( j = 0, k = getLength( children ); j < k; ++j ) {
        child = children[ j ];

        if ( child.nodeType === 1 && ( !select || matches.call( child, selector ) ) ) {
          list.push( child );
        }
      }
    }

    return this.pushStack( list );
  },

  find: function ( selector ) {
    var i = 0,
        length = this.length,
        list = [],
        element, temp, j, k;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      temp = element.nodeType === 1 &&
        element.querySelectorAll( selector );

      if ( !temp ) {
        continue;
      }

      for ( j = 0, k = temp.length; j < k; ++j ) {
        element = temp[ j ];

        if ( lastIndexOf( list, element ) < 0 ) {
          list.push( element );
        }
      }
    }

    return this.pushStack( list );
  },

  not: function ( selector ) {
    var byCallback = isFunction( selector ),
        i = 0,
        length = this.length,
        list = [],
        element;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      if ( !( byCallback ?
        selector.call( element, i, element ) :
        is( element, selector ) ) ) {

        list.push( element );
      }
    }

    return this.pushStack( list );
  },

  offsetParent: function () {
    var i = 0,
        length = this.length,
        list = [],
        element, offsetParent;

    for ( ; i < length; ++i ) {
      element = this[ i ];

      if ( element.nodeType !== 1 ) {
        continue;
      }

      offsetParent = element.offsetParent;

      while ( offsetParent && getStyle( offsetParent, 'position' ) === 'static' ) {
        offsetParent = offsetParent.offsetParent;
      }

      if ( !offsetParent ) {
        offsetParent = element.ownerDocument.documentElement;
      }

      if ( indexOf( list, offsetParent ) < 0 ) {
        list.push( offsetParent );
      }
    }

    return this.pushStack( list );
  },

  position: function () {
    var element = this[ 0 ],
        offset, style, offsetParent, opElement,
        opElementStyle, parentOffset, topWidth, leftWidth;

    if ( !element || element.nodeType !== 1 ) {
      return null;
    }

    style = getComputedStyle( element );
    parentOffset = { top: 0, left: 0 };

    if ( style.position === 'fixed' ) {
      offset = element.getBoundingClientRect();
    } else {
      offsetParent = this.offsetParent();
      opElement = offsetParent[ 0 ];

      if ( !opElement || opElement.nodeType !== 1 ) {
        return null;
      }

      offset = this.offset();

      if ( opElement.nodeName !== 'HTML' ) {
        parentOffset = offsetParent.offset();
      }

      opElementStyle = getComputedStyle( opElement );
      topWidth = opElementStyle.borderTopWidth;
      leftWidth = opElementStyle.borderLeftWidth;
      parentOffset.top += window.parseInt( topWidth, 10 );
      parentOffset.left += window.parseInt( leftWidth, 10 );
    }

    return {
      top: offset.top -
        parentOffset.top -
        window.parseInt( style.marginTop, 10 ),

      left: offset.left -
        parentOffset.left -
        window.parseInt( style.marginLeft, 10 )
    };
  },

  remove: function () {
    return this.each( function () {
      var nodeType = this.nodeType,
          parentNode;

      if ( (
        nodeType === 1 ||
        nodeType === 3 ||
        nodeType === 8 ||
        nodeType === 9 ||
        nodeType === 11
      ) && ( parentNode = this.parentNode ) ) {

        parentNode.removeChild( this );
      }
    } );
  },

  ready: function ( callback ) {
    var document = this[ 0 ],
        readyState;

    if ( !document || document.nodeType !== 9 ) {
      return this;
    }

    readyState = document.readyState;

    if ( document.attachEvent ?
      readyState === 'complete' : readyState !== 'loading' ) {

      callback( Scotch );
    } else {
      event.add( document, 'DOMContentLoaded', function () {
        callback( Scotch );
      }, false, true );
    }

    return this;
  },

  pushStack: function ( elements ) {
    var set = baseMerge( new DOMWrapper(), elements );

    set.prevObject = this;

    return set;
  },

  end: function () {
    return this.prevObject || new DOMWrapper();
  },

  filter: function ( selector ) {
    return this.pushStack( baseFilter( false, this, function ( element, i ) {
      return this ? selector.call( element, i, element ) : is( element, selector );
    }, isFunction( selector ) ) );
  },

  first: function () {
    return this.eq( 0 );
  },

  last: function () {
    return this.eq( -1 );
  },

  map: function ( callback ) {
    var i = 0,
        length = this.length,
        temp = new DOMWrapper(),
        element;

    temp.length = this.length;

    for ( ; i < length; ++i ) {
      temp[ i ] = callback.call( element = this[ i ], i, element );
    }

    return temp;
  },

  clone: function ( deep ) {
    if ( !arguments.length ) {
      deep = true;
    }

    return this.map( function ( element ) {
      return element.nodeType === 1 ?
        cloneNode( element, deep ) : element;
    } );
  },

  append: function () {
    return manipulation( this, function ( element, content ) {
      element.appendChild( content );
    }, arguments );
  },

  prepend: function () {
    return manipulation( this, function ( element, content ) {
      var firstChild = element.firstChild;

      if ( firstChild ) {
        element.insertBefore( content, firstChild );
      } else {
        element.appendChild( content );
      }
    }, arguments );
  },

  after: function () {
    return manipulation( this, function ( element, content ) {
      var parentNode = element.parentNode,
          nextSibling;

      if ( parentNode ) {
        if ( ( nextSibling = element.nextSibling ) ) {
          parentNode.insertBefore( content, nextSibling );
        } else {
          parentNode.appendChild( content );
        }
      }
    }, arguments );
  },

  before: function () {
    return manipulation( this, function ( element, content ) {
      var parentNode = element.parentNode;

      if ( parentNode ) {
        parentNode.insertBefore( content, element );
      }
    }, arguments );
  },

  slice: function ( start, end ) {
    return this.pushStack( makeSlice( this, start, end ) );
  },

  toggle: function ( state ) {
    return this.each( function () {
      if ( this.nodeType === 1 ) {
        if ( state === undefined ?
          getStyle( this, 'display' ) === 'none' : state ) {

          show.call( this );
        } else {
          hide.call( this );
        }
      }
    } );
  },

  longtouch: function ( longtouch, touch, delay ) {
    var ontouch = isFunction( touch ),
        touched = true,
        target, id;

    if ( delay === undefined ) {
      delay = ontouch || touch === undefined ?
        300 : touch;
    }

    return this
      .touchstart( function ( event ) {
        target = this;

        id = window.setTimeout( function () {
          touched = false;
          longtouch.call( target, event );
        }, delay );
      } )
      .touchend( function ( event ) {
        window.clearTimeout( id );

        if ( ontouch && touched ) {
          touch.call( this, event );
        }

        touched = true;
      } );
  }
};

forInRight( {
  value: 'value',
  text: 'textContent' in body ? 'textContent' : 'innerText',
  html: 'innerHTML'
}, function ( name, methodName ) {
  this[ methodName ] = function ( value ) {
    return access( this, function ( element, name, value, chainable ) {
      if ( element.nodeType !== 1 ) {
        return null;
      }

      if ( !chainable ) {
        return element[ name ];
      }

      element[ name ] = value;
    }, name, value, !!arguments.length, null );
  };
}, prototype );

forIn( {
  on: 'add',
  one: 'add',
  off: 'remove',
  trigger: 'dispatch'
}, function ( name, methodName ) {
  var one = methodName === 'one',
      off = methodName === 'off';

  this[ methodName ] = function ( types, listener, useCapture ) {
    var removeAll = off && !arguments.length,
        i = this.length - 1,
        element, j, k;

    if ( !removeAll ) {
      if ( !isString( types ) ) {
        throw TypeError( ERR_STRING_EXPECTED );
      }

      types = types.match( RE_NOT_WHITESPACES );

      if ( !types ) {
        return this;
      }

      k = types.length;
    }

    for ( ; i >= 0; --i ) {
      element = this[ i ];

      if ( removeAll ) {
        event[ name ]( element );
      } else for ( j = 0; j < k; ++j ) {
        event[ name ]( element, types[ j ], listener, useCapture, one );
      }
    }

    return this;
  };
}, Scotch.fn );

forInRight( {
  width: 'Width',
  height: 'Height'
}, function ( name, methodName ) {
  this[ methodName ] = function ( value ) {
    var element, body, root;

    if ( arguments.length ) {
      return this.style( methodName, value );
    }

    element = this[ 0 ];

    if ( !element ) {
      value = null;
    } else if ( element.window === element ) {
      value = max( element.document.documentElement[ 'client' + name ], element[ 'inner' + name ] || 0 );
    } else if ( element.nodeType === 9 ) {
      body = element.body;
      root = element.documentElement;

      value = max(
        body[ 'scroll' + name ],
        root[ 'scroll' + name ],
        body[ 'offset' + name ],
        root[ 'offset' + name ],
        body[ 'client' + name ],
        root[ 'client' + name ]
      );
    } else {
      value = element[ 'client' + name ];
    }

    return value;
  };
}, prototype );

var getWindow = function ( element ) {
  return element.window === element ?
    element : element.nodeType === 9 ?
    element.defaultView : false;
};

forInRight( {
  scrollTop: 'pageYOffset',
  scrollLeft: 'pageXOffset'
}, function ( offset, name ) {
  var top = name === 'scrollTop';

  this[ name ] = function ( value ) {
    var i, element, window, x, y;

    if ( arguments.length ) {
      for ( i = this.length - 1; i >= 0; --i ) {
        element = this[ i ];
        window = getWindow( element );

        if ( window ) {
          if ( top ) {
            x = window.pageXOffset || window.document.body.scrollLeft || 0;
            y = value;
          } else {
            x = value;
            y = window.pageYOffset || window.document.body.scrollTop || 0;
          }

          window.scrollTo( x, y );
        } else {
          element[ name ] = value;
        }
      }

      return this;
    }

    return ( element = this[ 0 ] ) ?
      ( window = getWindow( element ) ) ?
        window[ offset ] || window.document.body[ name ] || 0 : element[ name ] : null;
  };
}, prototype );

var hide = function () {
  if ( this.nodeType === 1 ) {
    this.style.display = 'none';
  }
};

var show = function () {
  if ( this.nodeType !== 1 ) {
    return;
  }

  var style = this.style;

  if ( style.display === 'none' ) {
    style.display = '';
  }

  if ( getComputedStyle( this ).display === 'none' ) {
    style.display = getDefaultVisibleDisplay( this );
  }
};

forInRight( { hide: hide, show: show }, function ( method, name ) {
  this[ name ] = function () {
    return this.each( method );
  };
}, prototype );

var toggle = function ( element, name, state, setState ) {
  if ( element.nodeType === 1 ) {
    if ( !setState ) {
      return element[ name ];
    }

    element[ name ] = state;
  }

  return null;
};

forEachRight( [ 'checked', 'disabled' ], function ( methodName ) {
  this[ methodName ] = function ( state ) {
    return access( this, toggle, methodName, state, arguments.length > 0, null );
  };
}, prototype );

var cloneNode = function ( element, deep ) {
  return event.copy( element.cloneNode( deep ), element, deep );
};

var wrapMap = function () {
  var map = {};

  map.optgroup =
    map.option = [ 1, '<select multiple="multiple">', '</select>' ];

  map.tbody =
    map.tfoot =
    map.colgroup =
    map.caption =
    map.thead = [ 1, '<table>', '</table>' ];

  map.col = [ 2, '<table><colgroup>', '</colgroup></table>' ];
  map.tr = [ 2, '<table><tbody>', '</tbody></table>' ];
  map.th = map.td = [ 3, '<table><tbody><tr>', '</tr></tbody></table>' ];
  map.defaults = [ 0, '', '' ];
  return map;
}();

var RE_HTML = /<|&#?\w+;/,
    RE_TAG_NAME = /<([a-z][^\s>]*)/;

var createFragment = function ( elements, context ) {
  var i = 0,
      length = elements.length,
      fragment = context.createDocumentFragment(),
      nodes = [],
      element, temp, tag, wrap, j;

  for ( ; i < length; ++i ) {
    if ( isObject( ( element = elements[ i ] ), false ) ) {
      baseMerge( nodes, 'nodeType' in element ? [ element ] : element );
    } else if ( !RE_HTML.test( element ) ) {
      nodes.push( context.createTextNode( element ) );
    } else {
      if ( !temp ) {
        temp = context.createElement( 'div' );
      }

      wrap = wrapMap[ ( tag = RE_TAG_NAME.exec( element ) ) ?
        tag[ 1 ].toLowerCase() : '' ] || wrapMap.defaults;

      temp.innerHTML = wrap[ 1 ] + element + wrap[ 2 ];

      for ( j = wrap[ 0 ]; j > 0; --j ) {
        temp = temp.lastChild;
      }

      baseMerge( nodes, temp.childNodes );

      temp.innerHTML = '';
    }
  }

  for ( i = 0, length = nodes.length; i < length; ++i ) {
    fragment.appendChild( nodes[ i ] );
  }

  return fragment;
};

var manipulation = function ( collection, callback, args ) {
  args = apply( concat, [], args );

  var i = 0,
      length = collection.length,
      last = length - 1,
      fragment, element, context;

  if ( length ) {
    if ( typeof args[ 0 ] == 'function' ) {
      for ( ; i < length; ++i ) {
        element = collection[ i ];

        manipulation( new DOMWrapper( element ), callback, [
          args[ 0 ].call( element, i, element )
        ] );
      }
    } else if ( ( context = collection[ 0 ].ownerDocument ) ) {
      fragment = createFragment( args, context );

      for ( ; i < length; ++i ) {

        element = collection[ i ];

        callback( element, i == last ? fragment : cloneNode( fragment, true ) );

      }
    }
  }

  return collection;
};

// jQuery 3.2.1
var access = function ( collection, callback, key, value, chainable, empty, raw ) {
  var bulk = key == null,
      i = 0,
      length = collection.length,
      element;

  if ( !bulk && getType( key ) == 'object' ) {
    chainable = true;

    forIn( key, function ( value, name ) {
      this( collection, callback, name, value, chainable, empty, raw );
    }, access );
  } else if ( value !== undefined ) {
    chainable = true;

    if ( typeof value != 'function' ) {
      raw = true;
    }

    if ( bulk ) {
      if ( raw ) {
        callback.call( collection, value );
        callback = null;
      } else {
        bulk = callback;

        callback = function ( element, key, value ) {
          return bulk.call( new DOMWrapper( element ), value );
        };
      }
    }

    if ( callback ) {
      for ( ; i < length; ++i ) {
        callback( ( element = collection[ i ] ), key, raw ?
          value : value.call( element, i, callback( element, key ) ), chainable );
      }
    }
  }

  return chainable ?
    collection : bulk ?
    callback.call( collection ) : length ?
    callback( collection[ 0 ], key, undefined, chainable ) : empty;
};

// jQuery 3.2.1
var cssNumbers = {
  "animationIterationCount": true,
  "columnCount": true,
  "fillOpacity": true,
  "flexGrow": true,
  "flexShrink": true,
  "fontWeight": true,
  "lineHeight": true,
  "opacity": true,
  "order": true,
  "orphans": true,
  "widows": true,
  "zIndex": true,
  "zoom": true
};

var is = function ( element, selector ) {
  return isString( selector ) ?
    element.nodeType === 1 && matches.call( element, selector ) :

  isArrayLike( selector ) ?
    lastIndexOf( selector, element ) >= 0 :

    element === selector;
};

var defaultStyleMap = {};

var getDefaultStyle = function ( target ) {
  var document, element,
      nodeName = target.nodeName,
      defaultStyle = defaultStyleMap[ nodeName ];

  if ( defaultStyle ) {
    return defaultStyle;
  }

  document = target.ownerDocument;
  element = document.body.appendChild( document.createElement( nodeName ) );

  defaultStyle = defaultStyleMap[ nodeName ] =

    // Используем clone потому что после удаления
    // элемента стили становятся пустыми.
    // Use "clone" 'cause after removing
    // an element, the styles become empty.
    getClone( false, getComputedStyle( element ) );

  element.parentNode.removeChild( element );

  return defaultStyle;
};

var defaultVisibleDisplayMap = {};

var getDefaultVisibleDisplay = function ( target ) {
  var nodeName = target.nodeName,
      display = defaultVisibleDisplayMap[ nodeName ];

  if ( display ) {
    return display;
  }

  display = getDefaultStyle( target ).display;

  if ( display == 'none' ) {
    display = 'block';
  }

  return ( defaultVisibleDisplayMap[ nodeName ] = display );
};

var propNames = {
  'for': 'htmlFor',
  'class': 'className'
};

var attr = function ( element, name, value, setValue ) {
  if ( element.nodeType !== 1 ) {
    return null;
  }

  if ( propNames[ name ] || !support.getAttribute ) {
    return prop( element, propNames[ name ] || name, value, setValue );
  }

  if ( !setValue ) {
    return element.getAttribute( name );
  }

  element.setAttribute( name, value );
};

var prop = function ( element, name, value, setValue ) {
  if ( !setValue ) {
    return element[ name ];
  }

  element[ name ] = value;
};

var removeAttr = function ( element, names ) {
  if ( element.nodeType !== 1 ) {
    return;
  }

  names = notwhite( names );

  for ( var i = names.length - 1; i >= 0; --i ) {
    if ( support.getAttribute ) {
      element.removeAttribute( names[ i ] );
    } else {
      delete element[ propNames[ names[ i ] ] || names[ i ] ];
    }
  }
};

var removeProp = function ( element, names ) {
  var i = ( names = notwhite( names ) ).length - 1;

  for ( ; i >= 0; --i ) {
    delete element[ names[ i ] ];
  }
};

forInRight( { attr: attr, prop: prop }, function ( method, methodName ) {
  this[ methodName ] = function ( name, value ) {
    return access( this, method, name, value, arguments.length > 1, null );
  };
}, prototype );

forInRight( {
  removeAttr: removeAttr,
  removeProp: removeProp
}, function ( method, methodName ) {
  this[ methodName ] = function ( names ) {
    return this.each( function () {
      method( this, names );
    } );
  };
}, prototype );

var classList = {
  add: function ( element, classes ) {
    classes = notwhite( classes );

    if ( !classes.length ) {
      return;
    }

    var i = 0,
        length = classes.length,
        className = ' ' + this.get( element ) + ' ',
        value;

    for ( ; i < length; ++i ) {
      value = classes[ i ] + ' ';

      if ( className.indexOf( ' ' + value ) < 0 ) {
        className += value;
      }
    }

    element.className = trim( className );
  },

  remove: function ( element, classes ) {
    classes = notwhite( classes );

    if ( !classes.length ) {
      return;
    }

    var i = classes.length - 1,
        className = ' ' + this.get( element ) + ' ',
        value;

    for ( ; i >= 0; --i ) {
      value = ' ' + classes[ i ] + ' ';

      while ( className.indexOf( value ) >= 0 ) {
        className = className.replace( value, ' ' );
      }
    }

    element.className = trim( className );
  },

  toggle: function ( element, classes ) {
    classes = notwhite( classes );

    if ( !classes.length ) {
      return;
    }

    var i = 0,
        length = classes.length,
        className = ' ' + this.get( element ) + ' ',
        value;

    for ( ; i < length; ++i ) {
      value = classes[ i ];

      this[ className.indexOf( ' ' + value + ' ' ) < 0 ? 'add' : 'remove' ]( element, value );
    }
  },

  has: function ( element, classes ) {
    classes = notwhite( classes );

    if ( !classes.length ) {
      return false;
    }

    var i = classes.length - 1,
        className = ' ' + this.get( element ) + ' ';

    for ( ; i >= 0; --i ) {
      if ( className.indexOf( ' ' + classes[ i ] + ' ' ) < 0 ) {
        return false;
      }
    }

    return true;
  },

  get: function ( element ) {
    var className = element.className,
        match;

    if ( !className || !( match = className.match( RE_NOT_WHITESPACES ) ) ) {
      return '';
    }

    return match.length > 1 ? match.join( ' ' ) : match[ 0 ];
  }
};

/**
 * Based on Taylor Hakes Promise() polyfill.
 * https://github.com/taylorhakes/promise-polyfill
 */
var Promise = window.Promise || function () {
  var Promise = function ( executor ) {
    if ( !isObject( this, false ) || !( this instanceof Promise ) ) {
      throw TypeError( this + ' is not a promise' );
    }

    if ( typeof executor != 'function' ) {
      throw TypeError( 'Promise resolver ' + executor + ' is not a function' );
    }

    execute( executor, addWrapper( this ) );
  };

  Promise.prototype = {
    constructor: Promise,

    then: function ( onFulfilled, onRejected ) {
      var promise = new Promise( noop ),
          wrapper = getWrapper( promise ),
          deferred = new Deferred( onFulfilled, onRejected, wrapper );

      handle( getWrapper( this ), deferred );
      return promise;
    },

    'catch': function ( onRejected ) {
      return this.then( null, onRejected );
    }
  };

  mixin( Promise, {
    all: function ( iterable ) {
      var args = slice.call( iterable ),
          remaining = args.length;

      return new Promise( function ( resolve, reject ) {
        if ( !remaining ) {
          return resolve( args );
        }

        var res = function ( value, args ) {
          try {
            if ( isPrimitive( value ) || typeof value.then != 'function' ) {
              if ( !--remaining ) {
                resolve( args );
              }
            } else {
              value.then( function ( value ) {
                res( value, args );
              }, reject );
            }
          } catch ( error ) {
            reject( error );
          }
        };

        var i = 0,
            length = remaining;

        for ( ; i < length; ++i ) {
          res( args[ i ], args );
        }
      } );
    },

    resolve: function ( value ) {
      return isObject( value, false ) && value instanceof Promise ?
        value : new Promise( function ( resolve ) {
          resolve( value );
        } );
    },

    reject: function ( value ) {
      return new Promise( function ( resolve, reject ) {
        reject( value );
      } );
    },

    race: function ( values ) {
      return new Promise( function ( resolve, reject ) {
        var i = 0,
            length = values.length;

        for ( ; i < length; ++i ) {
          values[ i ].then( resolve, reject );
        }
      } );
    }
  } );

  var Wrapper = function ( promise ) {
    this.promise = promise;
    this.deferreds = [];
  };

  Wrapper.prototype = {
    constructor: Wrapper,
    state: 0,
    handled: false,
    value: undefined
  };

  var Deferred = function ( onFulfilled, onRejected, promise ) {
    if ( typeof onFulfilled == 'function' ) {
      this.onFulfilled = onFulfilled;
    }

    if ( typeof onRejected == 'function' ) {
      this.onRejected = onRejected;
    }

    this.promise = promise;
  };

  Deferred.prototype = {
    constructor: Deferred,
    onFulfilled: null,
    onRejected: null
  };

  // Memory leak?
  var promises = [],
      wrappers = [];

  var addWrapper = function ( promise ) {
    var wrapper = promise;

    if ( !( wrapper instanceof Wrapper ) && !getWrapper( promise ) ) {
      promises.push( promise );
      wrappers.push( wrapper = new Wrapper( wrapper ) );
    }

    return wrapper;
  };

  var getWrapper = function ( promise ) {
    return ( promise = lastIndexOf( promises, promise ) ) < 0 ?
      null : wrappers[ promise ];
  };

  var execute = function ( executor, wrapper ) {
    var done = false;

    try {
      executor( function ( value ) {
        if ( !done ) {
          done = true;
          resolve( wrapper, value );
        }
      }, function ( reason ) {
        if ( !done ) {
          done = true;
          reject( wrapper, reason );
        }
      } );
    } catch ( error ) {
      if ( !done ) {
        reject( wrapper, error );
      }
    }
  };

  var resolve = function ( wrapper, value ) {
    try {
      if ( value === wrapper.promise ) {
        throw TypeError( 'A promise can\'t be resolved with itself' );
      }

      if ( isPrimitive( value ) ) {
        wrapper.state = 1;
        wrapper.value = value;

        finale( wrapper );
      } else if ( value instanceof Promise ) {
        wrapper.state = 3;
        wrapper.value = getWrapper( value );

        finale( wrapper );
      } else if ( typeof value.then == 'function' ) {
        execute( function ( resolve, reject ) {
          value.then( resolve, reject );
        }, wrapper );
      }
    } catch ( error ) {
      reject( wrapper, error );
    }
  };

  var reject = function ( wrapper, value ) {
    wrapper.state = 2;
    wrapper.value = value;

    finale( wrapper );
  };

  var WARN_UNHANDLED_REJECTION = 'Possible Unhandled Promise Rejection: ';

  var finale = function ( wrapper ) {
    var i = 0,
        length = wrapper.deferreds.length;

    if ( wrapper.state === 2 && !length ) {
      setImmediate( function () {
        if ( !wrapper.handled ) {
          warn( WARN_UNHANDLED_REJECTION, wrapper.value );
        }
      } );
    }

    for ( ; i < length; ++i ) {
      handle( wrapper, wrapper.deferreds[ i ] );
    }

    delete wrapper.deferreds;
  };

  var handle = function ( wrapper, deferred ) {
    while ( wrapper.state === 3 ) {
      wrapper = wrapper.value;
    }

    if ( wrapper.state === 0 ) {

      wrapper.deferreds.push( deferred );

      return;

    }

    wrapper.handled = true;

    setImmediate( function () {
      var temp,
          containsValue = wrapper.state === 1,

      callback = containsValue ?
        deferred.onFulfilled : deferred.onRejected;

      if ( !callback ) {
        ( containsValue ?
          resolve : reject )( deferred.promise, wrapper.value );

        return;
      }

      try {
        temp = callback( wrapper.value );
      } catch ( error ) {

        reject( deferred.promise, error );

        return;

      }

      resolve( deferred.promise, temp );
    } );
  };

  var setImmediate = window.setImmediate || function ( callback ) {
    window.setTimeout( callback, 0 );
  };

  return Promise;
}();

forEachRight( [
  'blur',        'focus',      'focusin',
  'focusout',    'resize',     'scroll',
  'click',       'dblclick',   'mousedown',
  'mouseup',     'mousemove',  'mouseover',
  'mouseout',    'mouseenter', 'mouseleave',
  'change',      'select',     'submit',
  'keydown',     'keypress',   'keyup',
  'contextmenu', 'touchstart', 'touchmove',
  'touchend',    'touchcancel', 'load'
], function ( type ) {
  this[ type ] = function ( argument ) {
    if ( !isFunction( argument ) ) {
      return this.trigger( type, argument );
    }

    baseForEach( arguments, function ( listener ) {
      this.on( type, listener, false );
    }, this );

    return this;
  };
}, prototype );

var get = function ( object, path ) {
  return accessProp( object, path );
};

var set = function ( object, path, value ) {
  return accessProp( object, path, value );
};

var warn = console && console.warn ?
  bindFast( console.warn, console ) : noop;

Scotch.entries = toPairs;
Scotch.entriesIn = toPairsIn;
Scotch.extend = mixin;
Scotch.eq = equal;
Scotch.lowerFirst = toLowerFirst;
Scotch.upperFirst = toUpperFirst;
Scotch.style = getStyle;
Scotch.prop = property;
prototype.css = prototype.style;
prototype.val = prototype.value;

window.scotch = window._ = window.Scotch = assign( Scotch, {
  access: accessProp,
  assign: assign,
  assignIn: assignIn,
  bind: bind,
  bindFast: bindFast,
  ceil: ceilNumber,
  clamp: clamp,
  clone: getClone,
  cloneArray: cloneArray,
  compact: compact,
  constant: constant,
  create: create,
  deepFind: deepFind,
  deepFindBy: deepFindBy,
  deepFindLast: deepFindLast,
  deepFindLastBy: deepFindLastBy,
  defaultTo: defaultTo,
  defineProperties: defineProperties,
  defineProperty: defineProperty,
  each: each,
  eachRight: eachRight,
  equal: equal,
  every: every,
  exec: globalExec,
  file: getFile,
  fill: fill,
  filter: filter,
  find: find,
  findIndex: findIndex,
  findLast: findLast,
  findLastIndex: findLastIndex,
  flatten: flatten,
  floor: floorNumber,
  forEach: forEach,
  forEachRight: forEachRight,
  forIn: forIn,
  forInRight: forInRight,
  forOwn: forOwn,
  forOwnRight: forOwnRight,
  fromPairs: fromPairs,
  get: get,
  getPrototypeOf: getPrototypeOf,
  hextorgb: hextorgb,
  identity: identity,
  includes: includes,
  indexOf: indexOf,
  invert: invert,
  isArray: isArray,
  isArrayLike: isArrayLike,
  isBoolean: isBoolean,
  isFinite: isFinite,
  isFunction: isFunction,
  isHTMLElement: isHTMLElement,
  isLength: isLength,
  isNaN: isNaN,
  isNumber: isNumber,
  isObject: isObject,
  isPlainObject: isPlainObject,
  isPrimitive: isPrimitive,
  isSafeInteger: isSafeInteger,
  isSomething: isSomething,
  isString: isString,
  isSymbol: isSymbol,
  isUndefined: isUndefined,
  isWindow: isWindow,
  keys: getKeys,
  keysIn: getKeysIn,
  last: last,
  lastIndexOf: lastIndexOf,
  map: map,
  mapRight: mapRight,
  merge: merge,
  method: method,
  mixin: mixin,
  noConflict: noConflict,
  noop: noop,
  now: getTime,
  nth: nth,
  nthArg: nthArg,
  once: once,
  parseHTML: parseHTML,
  property: property,
  random: random,
  range: range,
  rangeRight: rangeRight,
  reduce: reduce,
  reduceRight: reduceRight,
  reject: reject,
  reverse: reverse,
  rgbtohex: rgbtohex,
  round: roundNumber,
  sample: sample,
  sampleSize: sampleSize,
  set: set,
  setPrototypeOf: setPrototypeOf,
  shuffle: shuffle,
  size: size,
  sleep: sleep,
  slice: makeSlice,
  some: some,
  times: times,
  timestamp: timestamp,
  toArray: toArray,
  toIndex: toIndex,
  toObject: toObject,
  toPairs: toPairs,
  toPairsIn: toPairsIn,
  toPlainObject: toPlainObject,
  trim: trim,
  trimEnd: trimEnd,
  trimStart: trimStart,
  type: getTypeCached,
  unique: unique,
  unzip: unzip,
  values: getValues,
  valuesIn: getValuesIn,
  without: without,
  zip: zip,
  cssNumbers: cssNumbers,
  defaultEventProperties: eventprops,
  propNames: propNames,
  support: support,
  wrapMap: wrapMap,
  DOMWrapper: DOMWrapper,
  Event: Event,
  Promise: Promise
}, frame );

} )( window );
