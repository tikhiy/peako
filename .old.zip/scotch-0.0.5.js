/**
 * ScotchJS (c) 2017 SILENT.
 * Released under the MIT License.
 */

;(function (window, undefined) {

"use strict";

var document = window.document,
    body = document.createElement("body"),

    obj = Object.prototype,
    str = String.prototype,
    arr = Array.prototype,
    fn = Function.prototype,

    hasOwnProperty = obj.hasOwnProperty,
    toString = obj.toString,

    concat = arr.concat,
    slice = arr.slice,
    push = arr.push,
    sort = arr.sort,

    call = fn.call,

    floor = Math.floor,
    round = Math.round,
    rand = Math.random,
    max = Math.max,
    min = Math.min,

    MAX_SAFE_INT = 9007199254740991,
    MIN_SAFE_INT = -MAX_SAFE_INT,
    MAX_LENGTH = 4294967295,

    RE_SIMPLE_SELECTOR = /^(?:#([\w-]+)|([\w-]+)|\.([\w-]+))$/,
    RE_NOT_WHITESPACES = /[^\s\uFEFF\xA0]+/g,
    RE_HTML_TAG = /^(<([\w-]+)><\/[\w-]+>|<([\w-]+)(\s*\/)?>)$/,

    RE_TRIM_START = /^[\s\uFEFF\xA0]+/,
    RE_TRIM_END = /[\s\uFEFF\xA0]+$/,
    RE_TRIM = RegExp(RE_TRIM_START.source + "|" + RE_TRIM_END.source),

    ERR_INVALID_ARGS = "Invalid arguments",
    ERR_NOT_FUNCTION = "Expected a function",
    ERR_NOT_OBJECT = "Expected an object",
    ERR_NOT_STRING = "Expected a string",
    ERR_CONVERT_TO_OBJECT = "Cannot convert undefined or null to object",

    TAGS = {};

var support = {
  getElementsByClassName: toString.call( document.getElementsByClassName ) == "[object Function]",
  addEventListener: toString.call( window.addEventListener ) == "[object Function]",
  defineGetter: toString.call( obj.defineGetter ) == "[object Function]",

  defineProperty: function () {
    var test = function ( target ) {
      try {
        return "another" in Object.defineProperty( target, "another", {} );
      } catch ( e ) {
        return false;
      }
    };

    return test( document.createElement( "span" ) ) ?
      test( {} ) ?
        2 : 1 : 0;

    // return test( document.createElement( "span" ) ) + test( {} );
  }(),

  getAttribute: function () {
    try {
      var temp = document.createElement( 'span' ),
          name = 'something';

      temp.setAttribute( name, name );

      return temp.getAttribute( name ) === name;
    } catch ( e ) {
      return false;
    }
  }(),

  HTMLElement: !!~toString.call( body ).indexOf( 'HTML' )
};

var isNumber = function (n) {
  return n != null && (
    typeof n == "number" ||
    toString.call(n) == "[object Number]"
  );
};

var isString = function (n) {
  return n != null && (
    typeof n == "string" ||
    toString.call(n) == "[object String]"
  );
};

var isBoolean = function (n) {
  return n != null && (
    n === true ||
    n === false ||
    toString.call(n) == "[object Boolean]"
  );
};

var isUndefined = function (n) {
  return n === undefined;
};

var isFunction = function (n) {
  return !!n &&
    typeof n == "function" &&
    toString.call(n) == "[object Function]";
};

var isObject = function (n) {
  return !!n && typeof n == "object";
};

var isPrimitive = function (n) {
  var type;

  return n == null || ( type = typeof n ) != "object" && type != "function";
};

var isNaN = function (n) {
  return n != n;
};

var isFinite = function (n) {
  return isNumber(n) && window.isFinite(n);
};

var isSafeInteger = function (n) {
  return isFinite(n) &&
    n <= MAX_SAFE_INT &&
    n >= MIN_SAFE_INT &&
    n % 1 == 0;
};

var isArray = Array.isArray || function (n) {
  return isObject(n) &&
    typeof n.length == "number" &&
    toString.call(n) == "[object Array]";
};

var isArrayLike = function (n) {
  var length;

  return isObject(n) &&
    n.window !== n &&
    typeof ( length = n.length ) == "number" &&
    length >= 0 &&
    length <= MAX_LENGTH &&
    length % 1 == 0;
};

var isHTMLElement = support.HTMLElement ?

// With ( <String>.indexOf() x 2 ) faster then <RegExp>.test()
function (n) {
  var type;

  return isObject(n) &&
    ( type = toString.call(n) ).indexOf("HTML") > 0 &&
    type.indexOf("Element") > 0;
} :

function (n) {
  var name;

  return isObject(n) &&
    n.nodeType === 1 &&
    n.nodeName === ( name = n.tagName ) &&
    typeof name == "string";
};

// BUG: In IE8 isPlainObject( <HTMLBodyElement> ) == true
var isPlainObject = function () {
  var fnToString = fn.toString,
      fnObject = fnToString.call(Object);

  return function (n) {
    var prototype;

    return _type(n) == "object" && (
      ( prototype = _getPrototypeOf(n) ) === null ||
      hasOwnProperty.call(prototype, "constructor") &&
      fnToString.call(prototype.constructor) == fnObject);
  };
}();

var _type = function (n) {
  var type, tag;

  return n === null ?
    "null" : n === undefined ?
    "undefined" : ( type = typeof n ) == "object" || type == "function" ?
    TAGS[tag = toString.call(n)] || ( TAGS[tag] = tag.slice(8, -1).toLowerCase() ) : type;
};

var _noConflict = function () {
  var __ = window._,
      _Scotch = window.Scotch;

  return function (full) {
    return window._ === this && ( window._ = __ ),
      full && window.Scotch === this && ( window.Scotch = _Scotch ), this;
  };
}();

var _clone = function (deep, target) {
  if ( !isBoolean(deep) ) {
    target = deep;
    deep = true;
  }

  if (target == null) {
    throw TypeError(ERR_CONVERT_TO_OBJECT);
  }

  var clone = _create( target = Object(target) ),
      keys = _keys(target),
      length = keys.length,
      i = 0,
      value, key;

  for ( ; i < length; ++i) {
    value = target[key = keys[i]];

    clone[key] = deep &&
      value !== target &&
      isObject(value) ?
      _clone(deep, value) : value;
  }

  return clone;
};

var _mixin = function (target) {
  var deep = true,
      length = arguments.length,
      i = 1,
      expander, keys, key, value, source, j, k, a;

  if ( isBoolean(target) ) {
    deep = target;
    target = arguments[i++];
  }

  if (target == null) {
    throw TypeError(ERR_CONVERT_TO_OBJECT);
  }

  target = Object(target);

  for ( ; i < length; ++i) {
    expander = arguments[i];

    if (expander == null) {
      throw TypeError(ERR_CONVERT_TO_OBJECT);
    }

    expander = Object(expander);
    keys = _keys(expander);
    j = 0;
    k = keys.length;

    for ( ; j < k; ++j) {
      key = keys[j];
      value = expander[key];

      if ( deep && value != null && value !== expander && ( ( a = isArray(value) ) || isPlainObject(value) ) ) {
        source = target[key];

        if (a) {
          if ( !isArray(source) ) {
            source = [];
          }
        } else if ( !isPlainObject(source) ) {
          source = {};
        }

        target[key] = _mixin(deep, source, value);
      } else {
        target[key] = value;
      }
    }
  }

  return target;
};

var _clamp = function (n, lower, upper) {
  return arguments.length < 3 ?
    n > lower ? lower : n :
    n > upper ? upper : n < lower ? lower : n;
};

var _toArray = function (n) {
  if ( !isArrayLike(n) ) {
    return [n];
  }

  var i = n.length,
      a = Array(i--);

  for ( ; i >= 0; --i) if (i in n) {
    a[i] = n[i];
  }

  return a;
};

var _random = function (floating, lower, upper) {
  if ( !isBoolean(floating) ) {
    upper = lower;
    lower = floating;
    floating = false;
  }

  if (upper == null) {
    upper = lower == null ? 1 : lower;
    lower = 0;
  }

  var n = lower + rand() * (upper - lower);

  return floating ? n : round(n);
};

var _get = function (path, async) {
  if ( !isString(path) ) {
    throw TypeError(ERR_NOT_STRING);
  }

  var ajax = new XMLHttpRequest(),
      data = null,
      id;

  ajax.open("GET", path, isBoolean(async) && async);

  ajax.onload = function () {
    if (this.readyState === 4 && this.status === 200) {
      window.clearTimeout(id);

      data = this.responseText;
    }
  };

  id = window.setTimeout(function () {
    ajax.abort();
  }, 6e4);

  ajax.send(null);

  ajax = null;

  return data;
};

var _include = function (path) {
  var code = _get(path, false);

  return code !== null &&
    document.body.appendChild(
      new init( document.createElement("script") )
        .attr("type", "text/javascript")
        .text(code)[0] ), true;
};

var _findValue = function (object, key) {
  var k, e,
      isFunction = typeof key == "function";

  if ( isPrimitive(object) ) {
    throw TypeError(ERR_NOT_OBJECT);
  }

  for (k in object) if ( hasOwnProperty.call(object, k) ) {
    e = object[k];

    if (isFunction ? key(e, k) : k === key) {
      return [true, e];
    }

    if ( e !== object && !isPrimitive(e) && ( e = _findValue(e, key) )[0] ) {
      return e;
    }
  }

  return [false];
};

var _slice = function (n, start, end) {
  if ( !isArrayLike(n) ) {
    return [n];
  }

  var length = n.length,
      i = ( end = end == null ? length : min(length, ( end = floor(end) ) < 0 ? length + end : end) ) - ( start == null ? 0 : ( start = floor(start) ) < 0 ? max(0, length + start) : start ),
      a = Array(i--);

  for ( ; i >= 0; --i) if (i in n) {
    a[i] = n[--end];
  }

  return a;
};

var _times = function (n, callback) {
  var i = 0,
      a = Array(n = arguments.length < 2 ? ( callback = n, 1 ) : n >>> 0 || 1);

  for ( ; i < n; ++i) {
    a[i] = callback(i);
  }

  return a;
};

var _each = function (target, callback, context) {
  if (target == null) {
    throw TypeError(ERR_CONVERT_TO_OBJECT);
  }

  var keys, key, element, returned,
      n = isArrayLike( target = Object(target) ),
      i = 0,
      length = n ? target.length : ( keys = _keys(target) ).length;

  for ( ; i < length; ++i) if (!n || i in target) {
    returned = n ?
      callback.call(element = target[i], i, element) : callback.call(element = target[key = keys[i]], key, element);

    if ( isBoolean(returned) && !returned ) {
      break;
    }
  }

  return target;
};

var _invert = function (target) {
  var temp = {},
      value;

  _forEach(_keys(target), function (key) {
    temp["" + value] = key;
  });

  return temp;
};

var _takeValue = function (target, defaultValue, key) {
  var length = arguments.length,
      keys;

  if (length < 3) {
    key = length < 2 ?
      defaultValue : isArrayLike(target) ?
      _random(false, 0, target.length - 1) : ( keys = _keys(target) )[_random(false, 0, keys.length - 1)];

    defaultValue = undefined;
  }

  return length < 2 || key in target ?
    target[key] : defaultValue;
};

var _bindFast = function ( target, context ) {
  return function ( a, b, c, d ) {
    return target.call( context, a, b, c, d );
  };
};

var _find = function ( target, callback ) {
  if ( target == null ) {
    throw TypeError( ERR_CONVERT_TO_OBJECT );
  }

  var i, length, value;

  if ( isArrayLike( target ) ) {
    i = 0;
    length = target.length;

    for ( ; i < length; ++i ) {
      value = target[ i ];

      if ( callback( value, i, target ) ) {
        return value;
      }
    }
  } else {
    for ( i in target ) {
      if ( !hasOwnProperty.call( target, i ) ) {
        continue;
      }

      value = target[ i ];

      if ( callback( value, i, target ) ) {
        return value;
      }
    }
  }
};

// С массивами работает не по спецификации
// With arrays does't work according to the ECMA specification
var _fill = function ( target, value, start, end ) {
  if ( target == null ) {
    throw TypeError( ERR_CONVERT_TO_OBJECT );
  } else if ( isArrayLike( target ) ) {
    var length = target.length;

    start = start == null ?
      0 : ( start = floor( start ) ) < 0 ?
      length + start : start;

    end = end == null ?
      length : ( end = floor( end ) ) < 0 ?
      length + end : end;

    for ( ; start < end; ++start ) {
      target[ start ] = value;
    }
  } else {
    _each( target, function ( key ) {
      target[ key ] = value;
    });
  }

  return target;
};

var _size = function ( value ) {
  if ( value == null ) {
    return 0;
  }

  var size = 0,
      name, temp;

  switch ( typeof value ) {
    case 'boolean': return 4;
    case 'number': return 8;
    case 'string': return value.length * 2;

    case 'object':
    case 'function':
      for ( name in value ) {
        if ( !hasOwnProperty.call( value, name ) ) {
          continue;
        }

        size += _size( name );

        if ( ( temp = value[ name ] ) !== value ) {
          size += _size( temp );
        }
      }
  }

  return size;
};

var _getFileSize = function ( path, useAsync, callback ) {
  var request = new XMLHttpRequest(),
      size = null;

  request.onreadystatechange = function () {
    if ( this.readyState === this.DONE ) {
      callback( size = window.parseInt( this.getResponseHeader( 'Content-Length' ) ) );
    }
  };

  // Notice "HEAD" instead of "GET",
  // to get only the header
  request.open( 'HEAD', path, useAsync );

  request.send();

  return size;
};

var _getFile = function ( path, useAsync, options ) {
  if ( isObject( path ) ) {
    options = path;
    path = options.path;
    useAsync = options.useAsync;
  }

  options = options || {};
  useAsync = useAsync !== undefined && useAsync;

  var request = new XMLHttpRequest(),
      data = null,
      id;

  request.onreadystatechange = function () {
    var readyState = this.readyState,
        status = this.status;

    if ( readyState < 3 ) {
      return;
    } else if ( readyState === 3 ) {
      if ( options.onloading ) {
        options.onloading.call( this, this.responseText, options, status, this.statusText );
      }

      return;
    } else if ( readyState === 4 ) {
      if ( status !== 200 ) {
        if ( options.onerror ) {
          options.onerror.call( this, options, status, this.statusText );
        }

        return;
      }

      data = this.responseText;

      if ( options.onload ) {
        options.onload.call( this, data, options );
      }
    }
  };

  request.open( 'GET', path, useAsync );

  if ( useAsync ) {
    id = window.setTimeout( function () {
      request.abort();
    }, 'timeout' in options ? options.timeout : 60000 );
  }

  request.send();

  return data;
};

var _bind = call.bind ? call.bind(call.bind) : function (target, context) {
  if (typeof target != "function") {
    throw TypeError(ERR_NOT_FUNCTION);
  }

  var args = slice.call(arguments, 2);

  return function () {
    return target.apply( context, args.concat( slice.call(arguments) ) );
  };
};

var _indexOf = arr.indexOf ?
  _bindFast( call, arr.indexOf ) :

function ( target, value, i ) {
  if ( target == null ) {
    throw TypeError( ERR_CONVERT_TO_OBJECT );
  }

  target = Object( target );

  var argsLength = arguments.length,
      length = target.length >>> 0;

  if ( argsLength < 2 || !length ) {
    return -1;
  } else if ( argsLength < 3 ) {
    i = 0;
  } else if ( ( i = floor( i ) ) < 0 ) {
    i = max( 0, length + i );
  }

  for ( ; i < length; ++i ) {
    if ( i in target && target[ i ] === value ) {
      return i;
    }
  }

  return -1;
};

var _lastIndexOf = arr.lastIndexOf ? _bind(call, arr.lastIndexOf) : function (target, element, i) {
  if (target == null) {
    throw TypeError("lastIndexOf called on null or undefined");
  }

  var argsLength = arguments.length,
      length = ( target = Object(target) ).length >>> 0;

  if (argsLength < 2 || length == 0) {
    return -1;
  }

  i = argsLength > 2 ?
    min(length - 1, ( i = floor(i) ) < 0 ? length + i : i) : length - 1;

  for ( ; i >= 0; --i) if (i in target && target[i] === element) {
    return i;
  }

  return -1;
};

var _every = arr.every ? _bind(call, arr.every) : function (target, callback, context) {
  if (target == null) {
    throw TypeError("every called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0,
      i = 0;

  for ( ; i < length; ++i) {
    if ( i in target && !callback.call(context, target[i], i, target) ) {
      return false;
    }
  }

  return true;
};

var _some = arr.some ? _bind(call, arr.some) : function (target, callback, context) {
  if (target == null) {
    throw TypeError("some called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0,
      i = 0;

  for ( ; i < length; ++i) {
    if ( i in target && callback.call(context, target[i], i, target) ) {
      return true;
    }
  }

  return false;
};

var _forEach = arr.forEach ?
  _bindFast( call, arr.forEach ) :

function ( target, callback, context ) {
  if ( target == null ) {
    throw TypeError( ERR_CONVERT_TO_OBJECT );
  }

  target = Object( target );

  var i = 0,
      length = target.length >>> 0;

  for ( ; i < length; ++i ) {
    if ( i in target ) {
      callback.call( context, target[ i ], i, target );
    }
  }
};

var _map = arr.map ? _bind(call, arr.map) : function (target, callback, context) {
  if (target == null) {
    throw TypeError("map called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0,
      i = 0,
      temp = [];

  for ( ; i < length; ++i) if (i in target) {
    temp[i] = callback.call(context, target[i], i, target);
  }

  return temp;
};

var _filter = arr.filter ? _bind(call, arr.filter) : function (target, callback, context) {
  if (target == null) {
    throw TypeError("filter called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0,
      i = 0,
      temp = [],
      element;

  for ( ; i < length; ++i) {
    if ( i in target && callback.call(context, element = target[i], i, target) ) {
      temp.push(element);
    }
  }

  return temp;
};

var _reduce = arr.reduce ? _bind(call, arr.reduce) : function (target, callback, value) {
  if (target == null) {
    throw TypeError("reduce called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0,
      i = 0;

  if (arguments.length < 3) {
    while ( i < length && !(i in target) ) {
      ++i;
    }

    if (i == length) {
      throw TypeError("Reduce of empty array with no initial value");
    }

    value = target[i++];
  }

  for ( ; i < length; ++i) if (i in target) {
    value = callback(value, target[i], i, target);
  }

  return value;
};

var _reduceRight = arr.reduceRight ? _bind(call, arr.reduceRight) : function (target, callback, value) {
  if (target == null) {
    throw TypeError("reduceRight called on null or undefined");
  }

  var length = ( target = Object(target) ).length >>> 0,
      i = length - 1;

  if (arguments.length < 3) {
    while ( i >= 0 && !(i in target) ) {
      --i;
    }

    if (!~i) {
      throw TypeError("Reduce of empty array with no initial value");
    }

    value = target[i--];
  }

  for ( ; i >= 0; --i) if (i in target) {
    value = callback(value, target[i], i, target);
  }

  return value;
};

var _shuffle = function () {
  var shuffle = function () {
    return rand() - rand();
  };

  return function (n) {
    return sort.call( _toArray(n), shuffle );
  };
}();

var baseMerge = function (target, expander) {
  var i = 0,
      length = expander.length;

  for ( ; i < length; ++i) if (i in expander) {
    push.call(target, expander[i]);
  }

  return target;
};

var _merge = function (target) {
  if (target == null) {
    throw TypeError(ERR_CONVERT_TO_OBJECT);
  }

  var i = 1,
      length = arguments.length,
      expander;

  target = Object(target);

  for ( ; i < length; ++i) {
    expander = arguments[i];

    // push[ isArrayLike( expander ) ? 'apply' : 'call' ]( target, expander );

    if ( isArrayLike(expander) ) {
      baseMerge(target, expander);
    } else {
      push.call(target, expander);
    }
  }

  return target;
};

var _compact = function () {
  var compact = function (n) {
    return n !== undefined;
  };

  return function (target) {
    return _filter(target, compact);
  };
}();

var _unique = function () {
  var unique = function (element, i, target) {
    return _indexOf(target, element) == i;
  };

  return function (target) {
    return _filter(target, unique);
  };
}();

var _without = function () {
  var notEqual = function (value) {
    return value !== this;
  };

  var without = function (element) {
    return _every(this, notEqual, element);
  };

  return function (target) {
    return _filter( target, without, slice.call(arguments, 1) );
  };
}();

var _reverse = function (target) {
  return _toArray(target).reverse();
};

var _flatten = function () {
  var flatten = function ( a, b ) {
    return concat.call( a, _toArray( b ) );
  };

  return function ( target, level ) {
    if ( level != null && --level < 0 ) {
      return _toArray( target );
    }

    return _reduce( target, level ? function ( a, b ) {
      return concat.call( a, _flatten( _toArray( b ), level ) );
    } : flatten, [] );
  };
}();

var _zip = function () {
  var i = 0,
      length = arguments.length,
      zip = [],
      j, k, target;

  for ( ; i < length; ++i ) {
    j = 0;
    k = ( target = arguments[ i ] ).length;

    for ( ; j < k; ++j ) {
      ( zip[ j ] || ( zip[ j ] = [] ) )
        .push( target[ j ] );
    }
  }

  return zip;
};

var _grep = function ( target, callback, context, not ) {
  var invert = !not;

  return _filter( target, not ? function () {
    return !callback.apply( this, arguments ) !== invert;
  } : callback, context );
};

var _defineProperty = support.defineProperty === 2 ?
  Object.defineProperty :

function () {
  if (support.defineGetter) {
    var defineGetter = obj.__defineGetter__,
        defineSetter = obj.__sefineGetter__;
  }

  return function (object, key, descriptor) {
    if (support.defineProperty > 0) try {
      return Object.defineProperty(object, key, descriptor);
    } catch (e) {}

    if ( isPrimitive(object) ) {
      throw TypeError("defineProperty called on non-object");
    }

    if ( isPrimitive(descriptor) ) {
      throw TypeError("Property description must be an object: " + descriptor);
    }

    var hasGetter = "get" in descriptor,
        hasSetter = "set" in descriptor,
        get = descriptor.get,
        set = descriptor.set;

    if (hasGetter || hasSetter)  {
      if (typeof get != "function") {
        throw TypeError("Getter must be a function: " + get);
      }

      if (typeof set != "function") {
        throw TypeError("Setter must be a function: " + set);
      }

      if ("writable" in descriptor) {
        throw TypeError("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute, #<Object>");
      }

      if (support.defineGetter) {
        hasGetter && defineGetter.call(object, key, get);
        hasSetter && defineSetter.call(object, key, set);
      }
    } else if ( "value" in descriptor || !(key in object) ) {
      object[key] = descriptor.value;
    }

    return object;
  };
}();

var _defineProperties = support.defineProperty ?
  Object.defineProperties :

function (object, descriptors) {
  if (support.defineProperty > 0) try {
    return Object.defineProperties(object, descriptors);
  } catch (e) {}

  if ( isPrimitive(object) ) {
    throw TypeError("defineProperties called on non-object");
  }

  if ( isPrimitive(descriptors) ) {
    throw TypeError("Property description must be an object: " + descriptors);
  }

  return _each(descriptors, function (key, descriptor) {
    _defineProperty(object, key, descriptor);
  }), object;
};

var _create = Object.create || function () {
  var Constructor = function () {};

  return function (prototype, descriptors) {
    if ( prototype !== null && isPrimitive(prototype) ) {
      throw TypeError("Object prototype may only be an Object or null: " + prototype);
    }

    var object = ( Constructor.prototype = prototype, new Constructor() );

    Constructor.prototype = null;

    if (prototype === null) {
      _setPrototypeOf(object, prototype);
    }

    return arguments.length > 1 ?
      _defineProperties(object, descriptors) : object;
  };
}();

var _keys = Object.keys || function () {
  var hasEnumBug = !{ toString: null }.propertyIsEnumerable("toString"),

  nonEnums = [
    "toString",
    // "toJSON", ?
    "toLocaleString",
    "valueOf",
    "hasOwnProperty",
    "isPrototypeOf",
    "propertyIsEnumerable",
    "constructor"
  ];

  return function (n) {
    if (n == null) {
      throw TypeError(ERR_CONVERT_TO_OBJECT);
    }

    var keys = [],
        key;

    for (key in n) {
      if ( hasOwnProperty.call(n, key) ) {
        keys.push(key);
      }
    }

    return hasEnumBug ?
      keys.concat( _filter(nonEnums, function (key) {
        return !~_indexOf(keys, key) && hasOwnProperty.call(n, key);
      }) ) : keys;
  };
}();

var _getPrototypeOf = Object.getPrototypeOf || function ( target ) {
  if ( target == null ) {
    throw TypeError( ERR_CONVERT_TO_OBJECT );
  }

  var prototype = target.__proto__,
      constructor;

  return prototype !== undefined ?
    prototype : isFunction( constructor = target.constructor ) ?
    constructor.prototype : target instanceof Object ?
    obj : null;
};

var _setPrototypeOf = Object.setPrototypeOf || function ( target, prototype ) {
  if ( target == null ) {
    throw TypeError( "setPrototypeOf called on null or undefined" );
  }

  if ( prototype !== null && isPrimitive( prototype ) ) {
    throw TypeError( "Object prototype may only be an Object or null: " + prototype );
  }

  if ( !isPrimitive( target ) && "__proto__" in target ) {
    target.__proto__ = prototype;
  }

  return target;
};

var _assign = Object.assign || function (target) {
  if (target == null) {
    throw TypeError(ERR_CONVERT_TO_OBJECT);
  }

  var i = 1,
      length = arguments.length,
      source, key;

  for ( ; i < length; ++i) {
    source = arguments[i];

    if (source != null) {
      for (key in source) {
        if ( hasOwnProperty.call(source, key) ) {
          target[key] = source[key];
        }
      }
    }
  }

  return target;
};

var _values = Object.values || function () {
  var values = function ( key ) {
    return this[ key ];
  };

  return function ( target ) {
    return _map( _keys( target ), values, target );
  };
}();

var _entries = Object.entries || function ( target ) {
  return _zip( _keys( target ), _values( target ) );
};

var createReplace = function (regexp, name) {
  name += " called on null or undefined";

  return function (target) {
    if (target == null) {
      throw TypeError(name);
    }

    return ("" + target).replace(regexp, "");
  };
};

var _trim = str.trim ?
  _bind(call, str.trim) : createReplace(RE_TRIM, "trim");

var _trimStart = str.trimStart ?
  _bind(call, str.trimStart) : createReplace(RE_TRIM_START, "trimStart");

var _trimEnd = str.trimEnd ?
  _bind(call, str.trimEnd) : createReplace(RE_TRIM_END, "trimEnd");

var _now = Date.now || function () {
  return new Date().getTime();
};

var Event = function (source, options) {
  if ( isString(source) ) {
    this.type = source;
  } else if ( isObject(source) ) {
    this.originalEvent = source;
    this.type = source.type;

    this.target = source.target &&
      source.target.nodeType === 3 ?
        source.target.parentNode : source.target;

    this.currentTarget = source.currentTarget;
    this.relatedTarget = source.relatedTarget;
  } else {
    throw TypeError(ERR_INVALID_ARGS);
  }

  if ( isObject(options) ) {
    _mixin(this, options);
  }

  this.timeStamp = (source && source.timeStamp) || _now();
};

Event.prototype = {
  constructor: Event,

  preventDefault: function () {
    var event = this.originalEvent;

    if (event) {
      if (event.preventDefault) {
        event.preventDefault();
      } else {
        event.returnValue = false;
      }
    }
  },

  stopPropagation: function () {
    var event = this.originalEvent;

    if (event) {
      if (event.stopPropagation) {
        event.stopPropagation();
      } else {
        event.cancelBubble = true;
      }
    }
  }
};

/**
 * Based on Jonathan Neal addEventListener() polyfill.
 * https://gist.github.com/jonathantneal/3748027
 *
 * Namespace with related to Event methods
 */
var _event = new function () {
  var list = {};

  var add = this.add = support.addEventListener ?

  function ( target, type, listener, useCapture, one ) {
    if ( useCapture == null ) {
      useCapture = false;
    }

    var wrapper = one ? function ( event ) {
      remove( target, type, listener, useCapture );
      listener.call( target, event );
    } : listener;

    ( list[ type ] || ( list[ type ] = [] ) )
      .push( [ target, listener, useCapture, wrapper ] );

    target.addEventListener( type, wrapper, useCapture );
  } :

  function ( target, type, listener, useCapture, one ) {
    if ( typeof listener != "function" ) {
      return;
    }

    if ( useCapture == null ) {
      useCapture = false;
    }

    var wrapper = function ( event ) {
      if ( type === "DOMContentLoaded" && target.readyState !== "complete" ) {
        return;
      }

      if ( one ) {
        remove( target, type, listener, useCapture );
      }

      listener.call( target, ( ( event = new Event( event ) ).type = type, event ) );
    };

    ( list[ type ] || ( list[ type ] = [] ) )
      .push([ target, listener, useCapture, wrapper ]);

    target.attachEvent( type === "DOMContentLoaded" ?
      "onreadystatechange" : "on" + type, wrapper );
  };

  var remove = this.remove = function ( target, type, listener, useCapture ) {
    if ( type === undefined || listener === undefined ) {
      return removeAll( target, type );
    }

    var filtered = list[ type ],
        i = 0,
        length, item;

    if ( !filtered || !( length = filtered.length ) ) {
      return;
    }

    if ( useCapture == null ) {
      useCapture = false;
    }

    if ( !support.addEventListener ) {
      type = type === "DOMContentLoaded" ?
        "onreadystatechange" : "on" + type;
    }

    for ( ; i < length; ++i ) {
      item = filtered[ i ];

      if ( item[ 0 ] === target &&
        item[ 1 ] === listener &&
        item[ 2 ] === useCapture ) {

        filtered.splice( i, i + 1 );

        length = filtered.length;

        if ( support.addEventListener ) {
          target.removeEventListener( type, item[ 3 ], useCapture );
        } else {
          target.detachEvent( type, item[ 3 ] );
        }
      }
    }
  };

  var removeAll = this.removeAll = function ( target, type ) {
    if ( type == null ) {
      _each( list, function ( type ) {
        list[ type ].length &&
          removeAll( target, type );
      });

      return;
    }

    var filtered = list[ type ];

    if ( !filtered || !filtered.length ) {
      return;
    }

    _forEach( filtered, function ( item ) {
      if ( item[ 0 ] === target ) {
        remove( target, type, item[ 1 ], item[ 2 ] );
      }
    });
  };

  var copy = this.copy = function ( target, element, deep ) {
    _each( list, function ( type ) {
      _forEach( list[ type ], function ( item ) {
        if ( item[ 0 ] === element ) {
          add( target, type, item[ 1 ], item[ 2 ] );
        }
      });
    });

    if ( deep ) {
      var children = new init( element ).children();

      new init( target ).children().each(function ( i, element ) {
        copy( element, children[ i ], deep );
      });
    }

    return target;
  };

  this.trigger = function ( target, type ) {
    var filtered = list[ type ],
        i = 0,
        length, item;

    if ( !filtered || !( length = filtered.length ) ) {
      return;
    }

    for ( ; i < length; ++i ) {
      item = filtered[ i ];

      if ( item[ 0 ] === target ) {
        item[ 3 ].call( target/*, new Event()*/ );
      }
    }
  };
}();

/**
 * Jonathan Neal getComputedStyle() polyfill.
 * https://github.com/jonathantneal/polyfill/blob/master/polyfills/getComputedStyle/polyfill.js
 *
 * Small fixes and formatting from ScotchJS.
 */
var getComputedStyle = window.getComputedStyle || function () {
  var noop = function () {},
      camelCase = function (m) { return m.charAt(1).toUpperCase(); },
      unCamelCase = function (m) { return "-" + m.toLowerCase(); };

  var getComputedStylePixel = function (element, property, fontSize) {
    // Internet Explorer sometimes struggles to read currentStyle until the element's document is accessed.
    var value = element.document && element.currentStyle[property].match(/([\d.]+)(em|%|cm|in|mm|pc|pt|)/) || [0, 0, ""],
        size = value[1],
        suffix = value[2],
        rootSize, parent;

    fontSize = fontSize !== null ?
      fontSize : ( parent = element.parentElement ) && /%|em/.test(suffix) ?
      getComputedStylePixel(parent, "fontSize", null) : 16;

    rootSize = property == "fontSize" ?
      fontSize : /width/i.test(property) ?
      element.clientWidth : element.clientHeight;

    return suffix == "em" ?
      size * fontSize : suffix == "%" ?
      size / 100 * rootSize : suffix == "cm" ?
      size * 0.3937 * 96 : suffix == "in" ?
      size * 96 : suffix == "mm" ?
      size * 0.3937 * 96 / 10 : suffix == "pc" ?
      size * 12 * 96 / 72 : suffix == "pt" ?
      size * 96 / 72 : size;
  };

  var setShortStyleProperty = function (style, property) {
    var borderSuffix = property == "border" ? "Width" : "",
        t = property + "Top" + borderSuffix,
        r = property + "Right" + borderSuffix,
        b = property + "Bottom" + borderSuffix,
        l = property + "Left" + borderSuffix;

    style[property] = (style[t] == style[r] && style[t] == style[b] && style[t] == style[l] ?
      [style[t]] : style[t] == style[b] && style[l] == style[r] ?
      [style[t], style[r]] : style[l] == style[r] ?
      [style[t], style[r], style[b]] : [style[t], style[r], style[b], style[l]]).join(" ");
  };

  var CSSStyleDeclaration = function (element) {
    var style = this,
        currentStyle = element.currentStyle,
        fontSize = getComputedStylePixel(element, "fontSize");

    _forEach(_keys(currentStyle), function (property) {
      push.call( style, property == "styleFloat" ? "float" : property.replace(/[A-Z]/, unCamelCase) );

      if (property == "styleFloat") {
        style["float"] = currentStyle[property];
      } else if ( /^outline/.test(property) ) {
        try {
          // errors on checking outline
          style[property] = currentStyle[property];
        } catch (e) {
          style.outline = [
            style.outlineColor = currentStyle.color,
                              // curentStyle?
            style.outlineStyle = style.outlineStyle || "none",
            style.outlineWidth = style.outlineWidth || "0px"
          ].join(" ");
        }
      } else {
        style[property] = property == "width" ?
          element.offsetWidth + "px" : property == "height" ?
          element.offsetHeight + "px" : /* curentStyle? */ style[property] != "auto" && /(margin|padding|border).+W/.test(property) ?
          round( getComputedStylePixel(element, property, fontSize) ) + "px" : currentStyle[property];
      }
    });

    setShortStyleProperty(style, "margin");
    setShortStyleProperty(style, "padding");
    setShortStyleProperty(style, "border");

    style.fontSize = round(fontSize) + "px";
  };

  CSSStyleDeclaration.prototype = {
    constructor: CSSStyleDeclaration,

    getPropertyValue: function (property) {
      return this[~property.indexOf("-") ?
        property.replace(/-\w/g, camelCase) : property] || "";
    },

    item: function (i) {
      return this[i];
    },

    getPropertyPriority: noop,
    getPropertyCSSValue: noop,
    removeProperty: noop,
    setProperty: noop
  };

  return function (element) {
    return new CSSStyleDeclaration(element);
  };
}();

/**
 * Based on Erik Möller requestAnimationFrame polyfill:
 *
 * Adapted from https://gist.github.com/paulirish/1579671 which derived from
 * http://paulirish.com/2011/requestanimationframe-for-smart-animating/
 * http://my.opera.com/emoller/blog/2011/12/20/requestanimationframe-for-smart-er-animating
 *
 * requestAnimationFrame polyfill by Erik Möller.
 * Fixes from Paul Irish, Tino Zijdel, Andrew Mao, Klemen Slavič, Darius Bacon.
 *
 * MIT license
 */
var animation = new function () {
  var suffix = "AnimationFrame",

  request = window["request" + suffix] ||
    window["webkitRequest" + suffix] ||
    window["mozRequest" + suffix],

  cancel = window["cancel" + suffix] ||
    window["webkitCancel" + suffix] ||
    window["webkitCancelRequest" + suffix] ||
    window["mozCancel" + suffix] ||
    window["mozCancelRequest" + suffix];

  // iOS6 is buggy
  if (!/iP(ad|hone|od).*OS\s6/.test(window.navigator.userAgent) && request && cancel) {
    this.request = function (callback) {
      return request.call(window, callback);
    };

    this.cancel = function (id) {
      return cancel.call(window, id);
    };
  } else {
    var lastTime = 0,
        frameDuration = 1000 / 60;

    this.request = function (callback) {
      var now = _now(),
          nextTime = max(lastTime + frameDuration, now);

      return window.setTimeout(function () {
        callback( lastTime = nextTime );
      }, nextTime - now);
    };

    this.cancel = window.clearTimeout;
  }
}();

var matches = ( window.Element && (
  Element.prototype.matches ||
  Element.prototype.oMatchesSelector ||
  Element.prototype.msMatchesSelector ||
  Element.prototype.mozMatchesSelector ||
  Element.prototype.webkitMatchesSelector) ) ||

function (selector) {
  if ( !isString(selector) ) {
    throw TypeError(ERR_NOT_STRING);
  }

  var element = this,
      elements = (element.document || element.ownerDocument).querySelectorAll(selector),
      i = elements.length - 1;

  for ( ; i >= 0 && elements[i] !== element; --i) {}

  return !!~i;
};

var closest = (window.Element && Element.prototype.closest) || function (selector) {
  for (var element = this; element; element = element.parentElement) {
    if ( matches.call(element, selector) ) {
      return element;
    }
  }

  return null;
};

var parseHTML = function (data) {
  var match = RE_HTML_TAG.exec(data),
      temp = match ? match[2] || match[3] : false;

  return temp ?
    [document.createElement(temp)] : ( ( temp = document.createElement("body") ).innerHTML = data, temp.children );
};

var isSomething = function (n) {
  var type;

  return !!n &&
    typeof n == "object" &&
    (n.window === n || ( type = n.nodeType ) === 1 || type === 9);
};

var init = function (selector) {
  if (!selector) {
    return this;
  }

  var i, match, list;

  if ( isSomething(selector) ) {
    list = [selector];
  } else if ( isString(selector) ) {
    list = selector.charAt(0) == "<" ?
      parseHTML(selector) : !( match = RE_SIMPLE_SELECTOR.exec(selector) ) ?
      document.querySelectorAll(selector) : match[1] ?
      [document.getElementById(match[1])] : match[2] ?
      document.getElementsByTagName(match[2]) : support.getElementsByClassName ?
      document.getElementsByClassName(match[3]) : document.querySelectorAll(selector);
  } else if ( isArrayLike(selector) ) {
    list = selector;
  } else if ( isFunction(selector) ) {
    return new init(document).ready(selector);
  }

  if (!list || !list[0]) {
    return this;
  }

  i = ( this.length = list.length >>> 0 ) - 1;

  for ( ; i >= 0; --i) {
    this[i] = list[i];
  }
};

var _ = _mixin(function (selector) {
  return new init(selector);
}, {
  isNumber: isNumber,
  isString: isString,
  isBoolean: isBoolean,
  isUndefined: isUndefined,
  isFunction: isFunction,
  isObject: isObject,
  isPrimitive: isPrimitive,
  isNaN: isNaN,
  isFinite: isFinite,
  isSafeInteger: isSafeInteger,
  isArray: isArray,
  isArrayLike: isArrayLike,
  isHTMLElement: isHTMLElement,
  isPlainObject: isPlainObject,
  type: _type,
  noConflict: _noConflict,
  clone: _clone,
  mixin: _mixin,
  clamp: _clamp,
  toArray: _toArray,
  random: _random,
  get: _get, // TODO: remove
  include: _include,
  findValue: _findValue,
  slice: _slice,
  times: _times,
  each: _each,
  invert: _invert,
  takeValue: _takeValue,
  bindFast: _bindFast,
  find: _find,
  fill: _fill,
  size: _size,
  getFileSize: _getFileSize,
  getFile: _getFile,
  bind: _bind,
  indexOf: _indexOf,
  lastIndexOf: _lastIndexOf,
  every: _every,
  some: _some,
  forEach: _forEach,
  map: _map,
  filter: _filter,
  reduce: _reduce,
  reduceRight: _reduceRight,
  shuffle: _shuffle,
  merge: _merge,
  compact: _compact,
  unique: _unique,
  without: _without,
  reverse: _reverse,
  flatten: _flatten,
  zip: _zip,
  grep: _grep,
  defineProperty: _defineProperty,
  defineProperties: _defineProperties,
  create: _create,
  keys: _keys,
  getPrototypeOf: _getPrototypeOf,
  setPrototypeOf: _setPrototypeOf,
  assign: _assign,
  values: _values,
  entries: _entries,
  trim: _trim,
  trimStart: _trimStart,
  trimEnd: _trimEnd,
  now: _now,
  requestAnimationFrame: animation.request,
  cancelAnimationFrame: animation.cancel,
  parseHTML: parseHTML
});

var _fn = init.prototype = _.prototype = _.fn = {
  constructor: _,
  length: 0,

  get: function ( i ) {
    return arguments.length ?
      this[ i < 0 ? this.length + i : i ] : _toArray( this );
  },

  eq: function ( i ) {
    return this.pushStack( arguments.length ?
      [ this[ i < 0 ? this.length + i : i ] ] : this );
  },

  each: function (callback) {
    return _each(this, callback);
  },

  __style: function (a, b) { // TODO: remove ( old version )
    var i = this.length - 1,
        element, names, name, j, k;

    if ( isString(a) ) {
      if (arguments.length < 2) {
        return ( element = this[0] ) && element.nodeType === 1 ?
          getComputedStyle(element).getPropertyValue(a) : null;
      }

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          element.style[a] = b;
        }
      }
    } else if ( isObject(a) ) {
      k = ( names = _keys(a) ).length;

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          for (j = 0; j < k; ++j) {
            element.style[name = names[j]] = "" + a[name];
          }
        }
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return this;
  },

  style: function ( key, value ) {
    if ( isString( key ) ) {
      key = camelCasePropertyName( key );

      if ( !cssNumbers[ key ] && isNumber( value ) ) {
        value += 'px';
      }
    }

    return access( this, function ( key, value ) {
      return this.nodeType !== 1 ?
        null : value === undefined ?
        getComputedStyle( this )[ key ] : ( this.style[ key ] = value );
    }, key, value, arguments.length > 1, null );
  },

  attr: function (key, value) {
    var i, j, k, element, isFunction, keys;

    if ( isString(key) ) {
      if (arguments.length < 2) {
        return ( element = this[i] ) && element.nodeType === 1 ?
          element.getAttribute(key) : null;
      }

      i = this.length - 1;
      isFunction = typeof value == "function";

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          element.setAttribute( key, isFunction ? value( i, element.getAttribute(key) ) : value );
        }
      }
    } else if ( isObject(key) ) {
      i = this.length - 1;
      k = ( keys = _keys(key) ).length;

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          for (j = 0; j < k; ++j) {
            element.setAttribute(keys[j], key[keys[j]]);
          }
        }
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return this;
  },

  removeAttr: function (keys) {
    if ( !isString(keys) ) {
      throw TypeError(ERR_NOT_STRING);
    }

    if ( !( keys = keys.match(RE_NOT_WHITESPACES) ) ) {
      return this;
    }

    var i = this.length - 1,
        k = keys.length - 1,
        j, element;

    for ( ; i >= 0; --i) {
      if ( ( element = this[i] ).nodeType === 1 ) {
        for (j = k; j >= 0; --j) {
          element.removeAttribute(keys[j]);
        }
      }
    }

    return this;
  },

  addClass: function (value) {
    var i = this.length - 1,
        j, k, className, element;

    if (typeof value == "function") {
      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          new init(element).addClass( value.call(element, i, element.className) );
        }
      }
    } else if ( isString(value) ) {
      if ( !( value = value.match(RE_NOT_WHITESPACES) ) ) {
        return this;
      }

      k = value.length;

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType !== 1 ) {
          continue;
        }

        className = " " + ( element.className.match(RE_NOT_WHITESPACES) || [] ).join(" ") + " ";

        for (j = 0; j < k; ++j) {
          if ( !~className.indexOf(" " + value[j] + " ") ) {
            className += value[j] + " ";
          }
        }

        element.className = _trim(className);
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return this;
  },

  removeClass: function (value) {
    var i = this.length - 1,
        j, k, className, element;

    if (!arguments.length) {
      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          element.className = "";
        }
      }
    } else if (typeof value == "function") {
      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          new init(element).removeClass( value.call(element, i, element.className) );
        }
      }
    } else if ( isString(value) ) {
      if ( !( value = value.match(RE_NOT_WHITESPACES) ) ) {
        return this;
      }

      for (j = k = value.length - 1; j >= 0; --j) {
        value[j] = RegExp(" " + value[j] + " ", "gi");
      }

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType !== 1 ) {
          continue;
        }

        className = " " + (element.className.match(RE_NOT_WHITESPACES) || []).join(" ") + " ";
        j = k;

        for ( ; j >= 0; --j) {
          className = className.replace(value[j], " ");
        }

        element.className = _trim(className);
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return this;
  },

  toggleClass: function (value, state) {
    if ( isBoolean(state) ) {
      return this[state ? "addClass" : "removeClass"](value);
    }

    var i = this.length - 1,
        j, k, className, element, _element;

    if (typeof value == "function") {
      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType === 1 ) {
          new init(element).toggleClass( value.call(element, i, element.className) );
        }
      }
    } else if ( isString(value) ) {
      if ( !( value = value.match(RE_NOT_WHITESPACES) ) ) {
        return this;
      }

      for (j = ( k = value.length ) - 1; j >= 0; --j) {
        value[j] = " " + value[j] + " ";
      }

      // k = ( value = _map(value, function (n) { return " " + n + " "; }) ).length;

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType !== 1 ) {
          continue;
        }

        _element = new init(element);
        className = " " + (element.className.match(RE_NOT_WHITESPACES) || []).join(" ") + " ";

        for (j = 0; j < k; ++j) {
          _element[~className.indexOf(value[j]) ? "removeClass" : "addClass"](value[j]);
        }
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return this;
  },

  hasClass: function (value) {
    if ( !isString(value) ) {
      throw TypeError(ERR_NOT_STRING);
    }

    if ( !( value = value.match(RE_NOT_WHITESPACES) ) ) {
      return false;
    }

    var i = this.length - 1,
        k = value.length - 1,
        j = k,
        element, className;

    for ( ; j >= 0; --j) {
      value[j] = " " + value[j] + " ";
    }

    for ( ; i >= 0; --i) {
      if ( ( element = this[i] ).nodeType !== 1 ) {
        continue;
      }

      className = " " + (element.className.match(RE_NOT_WHITESPACES) || []).join(" ") + " ";

      for (j = k; j >= 0; --j) {
        if ( ~className.indexOf(value[j]) ) {
          return true;
        }
      }
    }

    return false;
  },

  offset: function (options) {
    var offset, document, root, body, isFn, style, i, element;

    if (!arguments.length) {
      if ( !( element = this[0] ) || element.nodeType !== 1 ) {
        return null;
      }

      document = element.ownerDocument;
      root = document.documentElement;
      body = document.body;
      offset = element.getBoundingClientRect();

      return {
        top: offset.top + (document.defaultView.pageYOffset || root.scrollTop || body.scrollTop) - (root.clientTop || body.clientTop || 0),
        left: offset.left + (document.defaultView.pageXOffset || root.scrollLeft || body.scrollLeft) - (root.clientLeft || body.clientLeft || 0)
      };
    } else if ( !isPrimitive(options) ) {
      isFn = typeof options == "function";
      i = this.length - 1;

      for ( ; i >= 0; --i) {
        if ( ( element = this[i] ).nodeType !== 1 ) {
          continue;
        }

        style = element.style;

        offset = isFn ?
          options( i, new init(element).offset() ) : options;

        style.top = offset.top + "px";
        style.left = offset.left + "px";

        if (style.position === "static" || getComputedStyle(element).position === "static") {
          style.position = "relative";
        }
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return this;
  },

  __is: function (selector) { // TODO: remove ( old version )
    var i = this.length - 1,
        j, k, element;

    if (typeof selector == "function") {
      for ( ; i >= 0; --i) {
        element = this[i];

        if ( selector.call(element, i, element) ) {
          return true;
        }
      }
    } else if ( isString(selector) ) {
      for ( ; i >= 0; --i) {
        element = this[i];

        if ( element.nodeType === 1 &&
          matches.call(element, selector) ) {

          return true;
        }
      }
    } else if ( isSomething(selector) ) {
      for ( ; i >= 0; --i) {
        if (this[i] === selector) {
          return true;
        }
      }
    } else if (selector instanceof init) {
      j = selector.length - 1;

      for ( ; j >= 0; --j) {
        element = selector[j];
        k = i;

        for ( ; k >= 0; --k) {
          if (this[k] === element) {
            return true;
          }
        }
      }
    } else {
      throw TypeError(ERR_INVALID_ARGS);
    }

    return false;
  },

  is: function ( selector ) {
    var isFunction = typeof selector == 'function',
        i = this.length - 1,
        element;

    for ( ; i >= 0; --i ) {
      element = this[ i ];

      if ( isFunction ?
        selector.call( element, i, element ) : is( element, selector ) ) {

        return true;
      }
    }

    return false;
  },

  closest: function (selector) {
    var i = 0,
        length = this.length,
        list = [],
        element, temp;

    for ( ; i < length; ++i) {
      temp = ( element = this[i] ).nodeType === 1 &&
        closest.call(element, selector);

      if ( temp && !~_indexOf(list, temp) ) {
        list.push(temp);
      }
    }

    return this.pushStack(list);
  },

  parent: function (selector) {
    var select = !!arguments.length,
        i = 0,
        length = this.length,
        list = [],
        element, parent;

    for ( ; i < length; ++i) {
      parent = ( element = this[i] ).nodeType === 1 &&
        element.parentElement;

      if ( parent && !~_indexOf(list, parent) && ( !select || matches.call(parent, selector) ) ) {
        list.push(parent);
      }
    }

    return this.pushStack(list);
  },

  siblings: function ( selector ) {
    var select = !!arguments.length,
        i = 0,
        length = this.length,
        list = [],
        element, siblings, sibling, j, k;

    for ( ; i < length; ++i ) {
      siblings = ( element = this[ i ] ).nodeType === 1 &&
        element.parentElement.children;

      if ( !siblings ) {
        continue;
      }

      j = 0;
      k = siblings.length;

      for ( ; j < k; ++j ) {
        sibling = siblings[ j ];

        if ( sibling !== element &&
          sibling.nodeType === 1 &&
          !~_indexOf( list, sibling ) &&
          ( !select || matches.call( sibling, selector ) ) ) {

          list.push( sibling );
        }
      }
    }

    return this.pushStack( list );
  },

  children: function (selector) {
    var select = !!arguments.length,
        i = 0,
        length = this.length,
        list = [],
        element, children, child, j, k;

    for ( ; i < length; ++i) {
      children = ( element = this[i] ).nodeType === 1 &&
        element.children;

      if (children) for (j = 0, k = children.length; j < k; ++j) {
        child = children[j];

        if ( child.nodeType === 1 && ( !select || matches.call(child, selector) ) ) {
          list.push(child);
        }
      }
    }

    return this.pushStack(list);
  },

  find: function (selector) {
    if ( !isString(selector) ) {
      throw TypeError(ERR_NOT_STRING);
    }

    var i = 0,
        length = this.length,
        list = [],
        element, temp, j, k;

    for ( ; i < length; ++i) {
      temp = ( element = this[i] ).nodeType === 1 &&
        element.querySelectorAll(selector);

      if (temp) for (j = 0, k = temp.length; j < k; ++j) {
        if ( !~_lastIndexOf(list, element = temp[j]) ) {
          list.push(element);
        }
      }
    }

    return this.pushStack(list);
  },

  not: function (selector) {
    var i = 0,
        length = this.length,
        list = [],
        isFunction = typeof selector == "function",
        element;

    for ( ; i < length; ++i) {
      element = this[i];

      if ( !( isFunction ? selector.call( element, i, element ) : is( element, selector ) ) ) {
        list.push(element);
      }
    }

    return this.pushStack(list);
  },

  offsetParent: function () {
    var i = 0,
        length = this.length,
        list = [],
        element, offsetParent;

    for ( ; i < length; ++i) {
      if ( ( element = this[i] ).nodeType !== 1 ) {
        continue;
      }

      offsetParent = element.offsetParent;

      while (offsetParent && (offsetParent.style.position || getComputedStyle(offsetParent).position) === "static") {
        offsetParent = offsetParent.offsetParent;
      }

      ~_indexOf( list, offsetParent || ( offsetParent = element.ownerDocument.documentElement ) ) ||
        list.push(offsetParent);
    }

    return this.pushStack(list);
  },

  position: function () {
    var element = this[0],
        offset, style, offsetParent, offsetParentElement, offsetParentElementStyle, parentOffset;

    if (!element || element.nodeType !== 1) {
      return null;
    }

    style = getComputedStyle(element);
    parentOffset = { top: 0, left: 0 };

    if (style.position === "fixed") {
      offset = element.getBoundingClientRect();
    } else {
      if ( !( offsetParentElement = ( offsetParent = this.offsetParent() )[0] ) || offsetParentElement.nodeType !== 1 ) {
        return null;
      }

      offset = this.offset();

      if (offsetParentElement.nodeName.toLowerCase() !== "html") {
        parentOffset = offsetParent.offset();
      }

      offsetParentElementStyle = getComputedStyle(offsetParentElement);

      parentOffset.top += window.parseInt(offsetParentElementStyle.borderTopWidth, 10);
      parentOffset.left += window.parseInt(offsetParentElementStyle.borderLeftWidth, 10);
    }

    return {
      top: offset.top - parentOffset.top - window.parseInt(style.marginTop, 10),
      left: offset.left - parentOffset.left - window.parseInt(style.marginLeft, 10)
    };
  },

  remove: function () {
    return this.each(function () {
      var nodeType = this.nodeType,
          parentNode;

      if ( ( nodeType === 1 || nodeType === 9 || nodeType === 11 ) && ( parentNode = this.parentNode ) ) {
        parentNode.removeChild( this );
      }
    });
  },

  ready: function ( callback ) {
    var document = this[ 0 ],
        readyState;

    if ( !document || document.nodeType !== 9 ) {
      return this;
    }

    readyState = document.readyState;

    if ( document.attachEvent ?
      readyState === 'complete' : readyState !== 'loading' ) {

      callback( _ );
    } else {
      _event.add( document, 'DOMContentLoaded', function ( event ) {
        callback( _ );
      }, false, true );
    }

    return this;
  },

  pushStack: function ( elements ) {
    var set = baseMerge( new init(), elements );

    set.prevObject = this;

    return set;
  },

  end: function () {
    return this.prevObject || new init();
  },

  filter: function ( selector ) {
    var isFunction = typeof selector == 'function',
        filtered = [];

    return this.each(function ( i, element ) {
      if ( isFunction ? selector.call( element, i, element ) : is( element, selector ) ) {
        filtered.push( element );
      }
    }).pushStack( filtered );
  },

  first: function () {
    return this.eq( 0 );
  },

  last: function () {
    return this.eq( -1 );
  },

  map: function ( callback ) {
    var i = 0,
        length = this.length,
        temp = new init(),
        element;

    for ( ; i < length; ++i ) {
      temp[ i ] = callback.call( element = this[ i ], i, element );
    }

    return temp;
  },

  clone: function ( deep ) {
    if ( !arguments.length ) {
      deep = true;
    }

    return this.map(function ( element ) {
      return element.nodeType === 1 ?
        cloneNode( element, deep ) : element;
    });
  },

  append: function () {
    return manipulation( this, function ( i, element, content ) {
      element.appendChild( content );
    }, arguments );
  },

  prepend: function () {
    return manipulation( this, function ( i, element, content ) {
      var firstChild = element.firstChild;

      if ( firstChild ) {
        element.insertBefore( content, firstChild );
      } else {
        element.appendChild( content );
      }
    }, arguments );
  },

  after: function () {
    return manipulation( this, function ( i, element, content ) {
      var parentNode = element.parentNode,
          nextSibling;

      if ( parentNode ) {
        if ( nextSibling = element.nextSibling ) {
          parentNode.insertBefore( content, nextSibling );
        } else {
          parentNode.appendChild( content );
        }
      }
    }, arguments );
  },

  before: function () {
    return manipulation( this, function ( i, element, content ) {
      var parentNode = element.parentNode;

      if ( parentNode ) {
        parentNode.insertBefore( content, element );
      }
    }, arguments );
  },

  slice: function ( start, end ) {
    return this.pushStack( _slice( this, start, end ) );
  }
};

_each({
  value: "value",
  text: "textContent" in body ? "textContent" : "innerText",
  html: "innerHTML"
}, function (method, name) {
  var set = function (element) {
    if (element.nodeType === 1) {
      element[name] = this;
    }
  };

  _fn[method] = function (value) {
    var element;

    return arguments.length ?
      ( _forEach(this, set, value), this ) : ( element = this[0] ) && element.nodeType === 1 ?
      element[name] : null;
  };
});

var removeAll = function ( collection, types ) {
  if ( types !== undefined ) {
    if ( !isString( types ) ) {
      throw TypeError( ERR_NOT_STRING );
    }

    if ( !( types = types.match( RE_NOT_WHITESPACES ) ) ) {
      return collection;
    }

    var length = types.length,
        i;
  }

  return collection.each(function () {
    if ( types ) {
      for ( i = 0; i < length; ++i ) {
        _event.removeAll( this, types[ i ] );
      }
    } else {
      _event.removeAll( this );
    }
  });
};

_each({
  on: 'add',
  one: 'add',
  off: 'remove',
  trigger: 'trigger'
}, function ( method, name ) {
  var one = method === 'one',
      off = method === 'off',
      trigger = method === 'trigger';

  _fn[ method ] = function ( types, listener, useCapture ) {
    if ( off && arguments.length < 2 ) {
      return removeAll( this, types );
    }

    if ( !isString( types ) ) {
      throw TypeError( ERR_NOT_STRING );
    }

    if ( !( types = types.match( RE_NOT_WHITESPACES ) ) ) {
      return this;
    }

    var i = this.length - 1,
        k = types.length,
        j, element;

    for ( ; i >= 0; --i ) {
      element = this[ i ];

      for ( j = 0; j < k; ++j ) {
        if ( trigger ) {
          _event[ name ]( element, types[ j ], listener );
        } else {
          _event[ name ]( element, types[ j ], listener, useCapture, one );
        }
      }
    }

    return this;
  };
});

_each({
  width: "Width",
  height: "Height"
}, function (method, name) {
  _fn[method] = function (n) {
    var element, body, root;

    return arguments.length ?
      this.style(method, n) : ( element = this[0] ) ?
      element.window === element ?
        max(
          element.document.documentElement["client" + name],
          element["inner" + name] || 0
        ) : element.nodeType === 9 ?
        ( body = element.body, root = element.documentElement, max(
          body[ "scroll" + name ], root[ "scroll" + name ],
          body[ "offset" + name ], root[ "offset" + name ],
          body[ "client" + name ], root[ "client" + name ]
        ) ) : element["client" + name] : null;
  };
});

var getWindow = function (element) {
  return element.window === element ?
    element : element.nodeType == 9 ?
    element.defaultView : false;
};

_each({
  scrollTop: "pageYOffset",
  scrollLeft: "pageXOffset"
}, function (method, name) {
  var top = method === "scrollTop",

  set = function (element) {
    var value = this,
        window = getWindow(element);

    if (window) {
      window.scrollTo(
        top ? window.pageXOffset || window.document.body.scrollLeft : value,
        top ? value : window.pageYOffset || window.document.body.scrollTop
      );
    } else {
      element[method] = value;
    }
  };

  _fn[method] = function (value) {
    var element, window;

    return arguments.length ?
      ( _forEach(this, set, value), this ) : ( element = this[0] ) ?
      ( window = getWindow(element) ) ?
        window[name] || window.document.body[method] : element[method] : null;
  };
});

var hide = function () {
  this.nodeType === 1 &&
    ( this.style.display = "none" );
};

var show = function () {
  if ( this.nodeType !== 1 ) {
    return;
  }

  var style = this.style;

  if ( style.display === "none" ) {
    style.display = "";
  }

  if ( getComputedStyle( this ).display === "none" ) {
    // style.display = getDefaultStyle( this ).display;
    style.display = "block";
  }
};

_fn.toggle = function ( state ) {
  return this.each(function () {
    if ( this.nodeType !== 1 ) {
      return;
    }

    var style = this.style;

    if ( state != null ?
      state : ( style.display || getComputedStyle( this ).display ) === "none" ) {

      show.call( this );
    } else {
      hide.call( this );
    }
  });
};

_each({
  hide: hide,
  show: show
}, function ( methodName, method ) {
  _fn[ methodName ] = function () {
    return this.each( method );
  };
});

_forEach([
  "checked",
  "disabled"
], function ( method ) {
  var set = function ( element ) {
    if ( element.nodeType === 1 ) {
      element[ method ] = this;
    }
  };

  _fn[ method ] = function ( state ) {
    if ( arguments.length ) {
      return _forEach( this, set, state ), this;
    }

    var element = this[ 0 ];

    return element && element.nodeType === 1 ?
      element[ method ] : null;
  };
});

var cloneNode = function ( element, deep ) {
  var clone = element.cloneNode( deep );

  if ( deep ) {
    _event.copy( clone, element, clone.children.length );
  }

  return clone;
};

var wrapMap = new function () {
  var wrapMap = this;

  wrapMap.optgroup = wrapMap.option = [ 1, '<select multiple="multiple">', '</select>' ];
  wrapMap.tbody = wrapMap.tfoot = wrapMap.colgroup = wrapMap.caption = wrapMap.thead = [ 1, '<table>', '</table>' ];
  wrapMap.col = [ 2, '<table><colgroup>', '</colgroup></table>' ];
  wrapMap.tr = [ 2, '<table><tbody>', '</tbody></table>' ];
  wrapMap.th = wrapMap.td = [ 3, '<table><tbody><tr>', '</tr></tbody></table>' ];

  wrapMap._default = [ 0, '', '' ];
}();

var RE_HTML = /<|&#?\w+;/,
    RE_TAG_NAME = /<([a-z][^\s>]*)/;

var createFragment = function ( elements, context ) {
  var i = 0,
      length = elements.length,
      fragment = context.createDocumentFragment(),
      nodes = [],
      element, temp, tag, wrap, j;

  for ( ; i < length; ++i ) {
    element = elements[ i ];

    if ( isObject( element ) ) {
      baseMerge( nodes, 'nodeType' in element ? [ element ] : element );
    } else if ( !RE_HTML.test( element ) ) {
      nodes.push( context.createTextNode( element ) );
    } else {
      if ( !temp ) {
        temp = context.createElement( 'div' );
      }

      tag = ( tag = RE_TAG_NAME.exec( element ) ) ?
        tag[ 1 ].toLowerCase() : '';

      wrap = wrapMap[ tag ] || wrapMap._default;

      temp.innerHTML = wrap[ 1 ] + element + wrap[ 2 ];

      j = wrap[ 0 ];

      for ( ; j >= 0; --j ) {
        temp = temp.lastChild;
      }

      baseMerge( nodes, temp.childNodes );

      temp.innerHTML = '';
    }
  }

  fragment.innerHTML = '';

  i = 0;
  length = nodes.length;

  for ( ; i < length; ++i ) {
    fragment.appendChild( nodes[ i ] );
  }

  return fragment;
};

var manipulation = function ( collection, callback, args ) {
  args = _flatten( args );

  if ( !args.length ) {
    throw RangeError( 'Given no one arguments' );
  }

  var i = 0,
      length = collection.length,
      last = length - 1,
      fragment, element, context;

  if ( length ) {
    if ( typeof args[ 0 ] == 'function' ) {
      for ( ; i < length; ++i ) {
        element = collection[ i ];

        manipulation( new init( element ), callback, [
          args[ 0 ].call( element, i, element )
        ] );
      }
    } else if ( context = collection[ 0 ].ownerDocument ) {
      fragment = createFragment( args, context );

      for ( ; i < length; ++i ) {
        element = collection[ i ];

        callback.call( element, i, element, i == last ?
          fragment : cloneNode( fragment, true ) );
      }

      // fragment = null;
    }
  }

  return collection;
};

// Получается, что почти то же самое. Прости, Джон.
// It turns out that almost the same thing. I'm sorry, John.
var access = function ( collection, callback, key, value, chainable, empty, raw ) {
  var bulk = key == null,
      i = 0,
      length = collection.length,
      element;

  if ( !bulk && _type( key ) == 'object' ) {
    chainable = true;

    _each( key, function ( name ) {
      access( collection, callback, name, key[ name ], chainable, empty, raw );
    });
  } else if ( value !== undefined ) {
    chainable = true;

    if ( typeof value != 'function' ) {
      raw = true;
    }

    if ( bulk ) {
      if ( raw ) {
        callback.call( collection, value );
        callback = null;
      } else {
        bulk = callback;

        callback = function ( key, value ) {
          return bulk.call( new init( this ), value );
        };
      }
    }

    if ( callback ) {
      for ( ; i < length; ++i ) {
        element = collection[ i ];

        callback.call(
          element,
          key,
          raw ?
            value : value.call( element, i, callback( element, key ) )
        );
      }
    }
  }

  return chainable ?
    collection : bulk ?
    callback.call( collection ) : length ?
    callback.call( collection[ 0 ], key ) : empty;
};

var camelCasePropertyName = function () {
  var camelCase = function ( m ) {
    return m.charAt( 1 ).toUpperCase();
  };

  return function ( name ) {
    return ~name.indexOf( '-' ) ?
      name.replace( /-\w/g, camelCase ) : name;
  };
}();

// jQuery 3.2.1
var cssNumbers = _.cssNumbers = {
  "animationIterationCount": true,
  "columnCount": true,
  "fillOpacity": true,
  "flexGrow": true,
  "flexShrink": true,
  "fontWeight": true,
  "lineHeight": true,
  "opacity": true,
  "order": true,
  "orphans": true,
  "widows": true,
  "zIndex": true,
  "zoom": true
};

_.support = support;

var is = function ( element, selector ) {
  if ( selector instanceof init ) {
    /* return _some( selector, function ( selector ) {
      return is( element, selector );
    }); */

    var i = selector.length - 1;

    for ( ; i >= 0; --i ) {
      if ( element === selector[ i ] ) {
        return true;
      }
    }

    return false;
  } else if ( isString( selector ) ) {
    return element.nodeType === 1 && matches.call( element, selector );
  } else {
    return element === selector;
  }
};

window.Scotch = window._ = _;

})(window);
