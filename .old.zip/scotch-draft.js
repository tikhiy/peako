/**
 * ScotchJS Draft (c) 2017 SILENT.
 * Released under the MIT License.
 */

;(function (window, undefined) {

"use strict";

var document = window.document;

// Date.prototype.toISOString() polyfill
var toISOString = function () {
  var pad = function (n) {
    return (n < 10 ? "0" : "") + n;
  };

  return function (d) {
    return d.getUTCFullYear() +
      "-" + pad( d.getUTCMonth() + 1 ) +
      "-" + pad( d.getUTCDate() ) +
      "T" + pad( d.getUTCHours() ) +
      ":" + pad( d.getUTCMinutes() ) +
      ":" + pad( d.getUTCSeconds() ) +
      "." + ( d.getUTCMilliseconds() / 1000 )
        .toFixed(3).slice(2, 5) + "Z";
  };
}();

fn = {
  hasAttr: function (keys) {
    if ( !isString(keys) ) {
      throw TypeError(ERR_NOT_STRING);
    }

    if ( !( keys = keys.match(RE_NOT_WHITESPACES) ) ) {
      return false;
    }

    var i = this.length - 1,
        k = keys.length - 1,
        j, element;

    for ( ; i >= 0; --i) {

      for (element = this[i], j = k; j >= 0; --j) {

        if ( element.hasAttribute(keys[j]) ) {
          return true;
        }
      }
    }

    return false;
  }
};

var fadeIn = function () {
  var name = "opacity",
      duration = 1000 / 60;

  return function (element) {
    var style = element.style,
        last = _.now(),
        opacity;

    style[name] = 0;

    (function tick () {
      opacity = +(
        style[name] = +style[name] + ( _.now() - last ) / 400
      );

      last = _.now();

      if (opacity < 1) {
        window.setTimeout(tick, duration);
      }
    })();
  };
};

var outerWidth = function ( element, withMargin ) {
  if ( !withMargin ) {
    return element.offsetWidth;
  }

  var style = element.style,
      marginLeft = style.marginLeft ||
        ( style = getComputedStyle( element ) ).marginLeft,
      marginRight = style.marginRight ||
        ( style = getComputedStyle( element ) ).marginRight;

  return element.offsetWidth +
    window.parseInt( marginLeft, 10 ) +
    window.parseInt( marginRight, 10 );
};

var matches = function ( source ) {
  var entries = toPairs( source ),
      length = entries.length;

  return function ( object ) {
    if ( object == null ) {
      return false;
    }

    var i = length - 1,
        entry;

    for ( ; i >= 0; --i ) {
      entry = entries[ i ];

      if ( !has( entry[ 0 ], object ) || !equal( entry[ 1 ], object[ entry[ 0 ] ] ) ) {
        return false;
      }
    }

    return true;
  };
};

// from somewhere with Stack Overflow
var getFileSize = function ( path, useAsync, callback ) {
  var request = new XMLHttpRequest(),
      size = 0;

  request.onreadystatechange = function () {
    if ( this.readyState === 4 ) {
      callback( size = window.parseInt(
        this.getResponseHeader( 'Content-Length' ) ) );
    }
  };

  // Notice "HEAD" instead of "GET",
  // to get only the header
  request.open( 'HEAD', path, useAsync );
  request.send();

  return size;
};

// jQuery 3.2.1
/* forIn( { Width: 'width', Height: 'height' }, function ( type, name ) {
  forIn( { padding: 'inner' + name, content: type, '': 'outer' + name }, function ( methodName, defaultExtra ) {
    var outer = !methodName.indexOf( 'outer' );

    this[ methodName ] = function ( value, margin ) {
      var chainable = arguments.length && ( defaultExtra || !isBoolean( margin ) ),
          extra = defaultExtra || ( margin === true || value === true ? 'margin' : 'border' );

      return access( this, function ( target, type, value, chainable ) {
        if ( target.window === target ) {
          return outer && target[ 'inner' + name ] || target.document.documentElement[ 'client' + name ];
        }

        if ( target.nodeType === 9 ) {
          var body = target.body,
              root = target.documentElement;

          return max(
            body[ 'scroll' + name ],
            root[ 'scroll' + name ],
            body[ 'offset' + name ],
            root[ 'offset' + name ],
            body[ 'client' + name ],
            root[ 'client' + name ] );
        }

        return value === undefined ?
          HOW JQUERY DOES THIS SHIT??
      }, type, chainable ? margin : undefined, chainable, null );
    };
  }, this );
}, prototype ); */

})(window);
